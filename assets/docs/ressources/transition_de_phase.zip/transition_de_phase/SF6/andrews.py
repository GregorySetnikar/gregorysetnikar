# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt

# Reading data
file_path = "andrews.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# Uncomment the following line to filter the DataFrame when R = 33
df_22 = da.filter_df(df=df, column_name="T", value=22)
df_24 = da.filter_df(df=df, column_name="T", value=24)
df_28 = da.filter_df(df=df, column_name="T", value=28)
df_33 = da.filter_df(df=df, column_name="T", value=33)
df_38 = da.filter_df(df=df, column_name="T", value=38)
df_45 = da.filter_df(df=df, column_name="T", value=44.5)
df_50 = da.filter_df(df=df, column_name="T", value=50.5)

# Creating a blank figure with x, y labels
fig, ax = da.make_fig("V (en mL)", "P (en bar)")

da.plot(
    ax=ax,
    x=df_22["V"],
    y=df_22["P"],
    xerr=df_22["V_err"],
    yerr=df_22["P_err"],
    label="T22",
)
da.plot(
    ax=ax,
    x=df_24["V"],
    y=df_24["P"],
    xerr=df_24["V_err"],
    yerr=df_24["P_err"],
    label="T24",
)

da.plot(
    ax=ax,
    x=df_28["V"],
    y=df_28["P"],
    xerr=df_28["V_err"],
    yerr=df_28["P_err"],
    label="T28",
)
da.plot(
    ax=ax,
    x=df_33["V"],
    y=df_33["P"],
    xerr=df_33["V_err"],
    yerr=df_33["P_err"],
    label="T33",
)
da.plot(
    ax=ax,
    x=df_38["V"],
    y=df_38["P"],
    xerr=df_38["V_err"],
    yerr=df_38["P_err"],
    label="T38",
)
da.plot(
    ax=ax,
    x=df_45["V"],
    y=df_45["P"],
    xerr=df_45["V_err"],
    yerr=df_45["P_err"],
    label="T44.5",
)
da.plot(
    ax=ax,
    x=df_50["V"],
    y=df_50["P"],
    xerr=df_50["V_err"],
    yerr=df_50["P_err"],
    label="T50.5",
)

ax.legend()

plt.show()

# Performing regression with uncertainties and plotting raw data
# results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, #color="blue")

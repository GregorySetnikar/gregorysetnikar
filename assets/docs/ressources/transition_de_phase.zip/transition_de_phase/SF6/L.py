# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt


# Reading data
file_path = "L.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# Creating a blank figure with x, y labels
fig2, ax2 = da.make_fig("T (en °C)", "$P_{sat}$ (en bar)")
fit = da.regression(
    ax=ax2,
    x=df["Tsat"],
    y=df["Psat"],
    xerr=df["Tsat_err"],
    yerr=df["Psat_err"],
)

n_mean = 1.68  # en mmol
n_err = 0.10  # en mmol

V_L = da.np2unp(df["V_L"], df["V_L_err"]) * 1e-6
V_G = da.np2unp(df["V_G"], df["V_G_err"]) * 1e-6
n = da.np2unp(n_mean, n_err) * 1e-3

v_l = V_L / n
v_g = V_G / n

T = da.np2unp(df["Tsat"], df["Tsat_err"]) + 273.15

dpdt = fit["a"]
dpdt_err = fit["u_a"]

dpsatdt = da.np2unp(dpdt, dpdt_err) * 1e5

Lu = 1e-3 * dpsatdt * T * (v_g - v_l)

L, Lerr = da.unp2np(Lu)

fig3, ax3 = da.make_fig("T (en °C)", "L (en $kJ.mol^{-1}$)")

da.plot(
    ax=ax3,
    x=df["Tsat"],
    y=L,
    xerr=df["Tsat_err"],
    yerr=Lerr,
)

plt.show()

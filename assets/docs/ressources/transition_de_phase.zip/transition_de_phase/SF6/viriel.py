# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt

# constant
R = 8.3144621  # J/K.mol


# Function definition for linear fit with Monte Carlo
def poly(x, n, B2, B3):
    return n * (1 + (B2 * (n * x)) + (B3 * (n * x) ** 2))


# Reading data
file_path = "andrews.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# Uncomment the following line to filter the DataFrame when R = 33
df_22 = da.filter_df(df=df, column_name="T", value=22)
df_28 = da.filter_df(df=df, column_name="T", value=28)
df_33 = da.filter_df(df=df, column_name="T", value=33)
df_38 = da.filter_df(df=df, column_name="T", value=38)
df_45 = da.filter_df(df=df, column_name="T", value=44.5)
df_50 = da.filter_df(df=df, column_name="T", value=50.5)

# Creating a blank figure with x, y labels
fig, ax = da.make_fig("$V^{-1}$ (en $mL^{-1}$)", "PV/RT (en mmol)")

T = [22, 28, 33, 38, 44.5, 50.5]
T_err = np.ones(len(T)) * 0.5

fit_results = []
fit_error = []

for i in T:
    dff = da.filter_df(df=df, column_name="T", value=i)
    V = da.np2unp(dff["V"], dff["V_err"])
    Tk = da.np2unp(dff["T"], dff["T_err"]) + 273.15
    P = da.np2unp(dff["P"], dff["P_err"]) * 1e5

    x = 1 / V
    y = ((P * V * 1e-6) / (R * Tk)) * 1e3

    x, xerr = da.unp2np(x)
    y, yerr = da.unp2np(y)

    # da.plot(ax=ax, x=x, y=y, xerr=xerr, yerr=yerr, label=f"{i}°C")
    param_mean, param_std = da.monte_carlo_fit(
        x=x, y=y, func=poly, p0=[1, 1e-4, 1e-8], xerr=xerr, yerr=yerr, plot_ax=ax
    )
    fit_results.append(param_mean[0])
    fit_error.append(param_std[0])

ax.legend()

fig2, ax2 = da.make_fig("T (°C)", "n (en mmol)")


T = np.array(T)
n = np.array(fit_results)
n_err = np.array(fit_error)

n_mean = np.mean(n)
n_mean_plot = np.ones(n.shape) * n_mean
n_std_plot = np.ones(n.shape) * n_err

da.plot(ax=ax2, x=T, y=n, xerr=T_err, yerr=n_err)
da.plot(ax=ax2, x=T, y=n_mean_plot, xerr=T_err, yerr=n_std_plot)

print(f"n_mean {n_mean}")
print(f"n_err {np.mean(n_err)}")

n_th = 1.74  # mmol

zscore = np.abs((n_mean - n_th)) / np.mean(n_err)
print(f"zscore = {zscore}")

plt.show()

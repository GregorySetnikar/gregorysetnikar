def monte_carlo_fit(
    x,
    y,
    func,
    p0,
    xerr=None,
    yerr=None,
    n_iter=1000,
    plot_ax=None,
    **kwargs,
):
    """
    Effectue une régression avec une simulation Monte-Carlo et optionnellement trace un snake plot, pour une fonction quelconque donnée en entrée.

    Parameters:
        x (array-like): Données en x.
        y (array-like): Données en y.
        func (callable): Fonction à ajuster.
        p0 (list): Estimations initiales des paramètres.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        n_iter (int): Nombre de simulations Monte-Carlo.
        plot_ax (matplotlib.axes._axes.Axes, optional): Axe matplotlib pour tracer le snake plot.
        **kwargs: Options supplémentaires pour plt.plot.
    Returns:
        tuple: (paramètres ajustés, incertitudes sur les paramètres).
    """
    t0 = time.time()
    if xerr is None:
        xerr = np.zeros_like(x)
    if yerr is None:
        yerr = np.zeros_like(y)

    # print(f"Moyenne de xerr : {np.mean(xerr)}, Moyenne de yerr : {np.mean(yerr)}")
    # print(f"x {x} y {y}")

    # Fit initial
    popt, _ = curve_fit(func, x, y, p0=p0, sigma=yerr, absolute_sigma=True)

    # Monte-Carlo simulations
    param_samples = []
    error_samples = []
    for _ in range(n_iter):
        # Simuler x et y en tenant compte des erreurs
        x_sim = x + np.random.normal(0, xerr, size=x.shape)
        y_sim = y + np.random.normal(0, yerr, size=y.shape)

        try:
            popt_sim, pcov_sim = curve_fit(
                func, x_sim, y_sim, p0=popt, sigma=yerr, absolute_sigma=True
            )
            param_samples.append(popt_sim)
            error_samples.append(pcov_sim)

        except RuntimeError:
            # Si le fit échoue pour une simulation, ignorer cette itération
            continue

    param_samples = np.array(param_samples)
    if param_samples.size == 0:
        raise RuntimeError(
            "Aucune simulation Monte-Carlo n'a réussi. Vérifiez vos données et paramètres initiaux."
        )

    param_mean = []
    param_std = []

    for i in range(len(param_samples[0, :])):
        mean = np.mean(param_samples[:, i])
        std = np.std(param_samples[:, i])
        param_mean.append(mean)
        param_std.append(std)

    # Optionnel : tracer le snake plot
    if plot_ax is not None:
        # Calculer la courbe centrale
        y_fit = func(x, *param_mean)
        param_mean = np.array(param_mean)
        param_std = np.array(param_std)
        param_low = np.subtract(param_mean, param_std)
        param_high = np.subtract(param_mean, -param_std)

        y_low = func(x, *param_low)
        y_high = func(x, *param_high)

        # Tracer les données
        plot_ax.errorbar(x, y, xerr=xerr, yerr=yerr, **kwargs)
        # Trace le fit et l’incertitude sur le fit
        fit_color = kwargs.get("color", "tab:orange")  # Utilise orange par défaut
        plot_ax.plot(x, y_fit, color=fit_color, label="Fit")
        plot_ax.fill_between(
            x, y_low, y_high, alpha=0.5, color=fit_color, label="Incertitude"
        )

    for i in range(0, len(param_mean)):
        print(
            f"Paramètre {i}: Moyenne = {param_mean[i]:.3f}, Ecart-type = {param_std[i]:.3f}"
        )

    t1 = time.time()
    print(f"Temps d'exécution : {t1 - t0:.2f} secondes")

    return param_mean, param_std

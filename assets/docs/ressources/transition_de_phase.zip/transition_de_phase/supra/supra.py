# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt


def mask_elements(tableau, n):
    """
    Supprime les n premiers éléments d'un tableau.

    :param tableau: Liste des éléments à traiter.
    :param n: Nombre d'éléments à supprimer.
    :return: Liste réduite après suppression des n premiers éléments.
    """
    if n < 0:
        raise ValueError("Le nombre d'éléments à supprimer (n) doit être positif.")
    return tableau[n:]


def U_th_to_T(U_temp):
    G_th = 333
    U_th = ((U_temp * 1e3 - 40) / G_th) * 1e3
    T = (
        -3e-25 * U_th**6
        + 4e-20 * U_th**5
        - 2e-15 * U_th**4
        + 7e-11 * U_th**3
        - 9e-7 * U_th**2
        + 0.0278 * U_th
        + 3.578
    ) + 273.15
    return T


def U_signal_to_R(U_signal):
    G = 1000
    I = 1.014

    U_s = U_signal / G
    R = (U_s / I) * 1e3
    return R


# Reading data
file_path = "raw_data.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# Creating a blank figure with x, y labels
fig, ax = da.make_fig("T (K)", "R (m$\\Omega$)")

count = 1
for i in range(1, 11):
    U_temp = df["U_temp_{}".format(i)]
    U_sig = df["U_signal_{}".format(i)]
    if i == 1:
        U_temp = mask_elements(U_temp, 9000)
        U_sig = mask_elements(U_sig, 9000)
    if i == 2:
        continue
        U_temp = mask_elements(U_temp, 4200)
        U_sig = mask_elements(U_sig, 4200)
    if i == 3:
        continue
    if i == 4:
        count += 1
        U_temp = mask_elements(U_temp, 5000)
        U_sig = mask_elements(U_sig, 5000)
    if i == 5:
        count += 1
        U_temp = mask_elements(U_temp, 3000)
        U_sig = mask_elements(U_sig, 3000)
    if i == 6:
        count += 1
        U_temp = mask_elements(U_temp, 5000)
        U_sig = mask_elements(U_sig, 5000)
    if i == 7:
        count += 1
        U_temp = mask_elements(U_temp, 5000)
        U_sig = mask_elements(U_sig, 5000)
    if i == 8:
        continue
    if i == 9:
        count += 1
        U_temp = mask_elements(U_temp, 7000)
        U_sig = mask_elements(U_sig, 7000)
    if i == 10:
        count += 1
        U_temp = mask_elements(U_temp, 7000)
        U_sig = mask_elements(U_sig, 7000)

    x = U_th_to_T(U_temp)
    y = U_signal_to_R(U_sig)
    da.plot(ax=ax, x=x, y=y, label=f"Data {count}")

# Adding legend and displaying the plot
ax.legend()
plt.show()

T = np.array([93.8, 96, 96, 97.8, 98.9, 101.28, 102.43, 80])

Tc = np.mean(T)
Tc_err = np.std(T, ddof=1) / np.sqrt(len(T))

Tc_theo = 93

zscore = (Tc - Tc_theo) / Tc_err

print("Temperature critique: {:.2f} ± {:.2f} K".format(Tc, Tc_err))
print(f"Zscore: {zscore:.2f}")

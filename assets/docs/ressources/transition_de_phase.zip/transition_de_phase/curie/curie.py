# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt


def U_th_to_T(Tension):
    Off = -0.06
    G = 1000 / 3.902
    U_th = ((Tension - Off) / G) * 1e6
    T = (
        -3e-25 * U_th**6
        + 4e-20 * U_th**5
        - 2e-15 * U_th**4
        + 7e-11 * U_th**3
        - 9e-7 * U_th**2
        + 0.0278 * U_th
        + 3.578
    )
    return T


# Reading data
file_path = "curie_data.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# Creating a blank figure with x, y labels
fig, ax = da.make_fig("Temps (en s)", "T (en °C)")


count = 0
for i in range(1, 7):
    count += 1
    U_temp = df["Tension_{}".format(i)]
    x = df["Temps_{}".format(i)]
    y = U_th_to_T(U_temp)

    da.plot(ax=ax, x=x, y=y, label=f"Data {count}", markersize=0.1)

# Adding legend and displaying the plot
ax.legend()
plt.show()

Tc = np.array([769, 817, 860, 800, 705, 715, 830])

Tcurie = np.mean(Tc)
Tc_err = np.std(Tc, ddof=1) / np.sqrt(len(Tc))

Tc_theo = 770

zscore = (Tcurie - Tc_theo) / Tc_err

print("Temperature critique: {:.2f} ± {:.2f} °C".format(Tcurie, Tc_err))
print(f"Zscore: {zscore:.2f}")

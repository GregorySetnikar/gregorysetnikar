﻿xelatex -quiet -synctex=1 --aux-directory="C:\Users\grego\Proton Drive\gregory.setnikar\My files\Greg\Agregation\Cours\Leçon_Physique\template\aux-files" lecon.tex
xelatex -quiet -synctex=1 --aux-directory="C:\Users\grego\Proton Drive\gregory.setnikar\My files\Greg\Agregation\Cours\Leçon_Physique\template\aux-files" lecon.tex

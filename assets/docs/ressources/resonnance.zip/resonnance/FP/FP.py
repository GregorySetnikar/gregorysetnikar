################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


def lire_tableau(fichier):
    data = np.loadtxt(fichier)  # Charge directement le fichier en array NumPy
    colonne1 = data[:, 0]  # Extraction de la première colonne
    colonne2 = data[:, 1]  # Extraction de la deuxième colonne
    return colonne1, colonne2


### Partie qui ne fonctionne pas...

df_profil, units = DAU.loadfile("profil_FP.txt")

centre = 791.5

x = np.array(df_profil["x"])
y = np.array(df_profil["y"])


# interpolation pour plus de précision
x_interp = np.linspace(0, max(x), 3 * len(x))
y_interp = np.interp(x_interp, x, y)

fig, ax = DAU.make_fig("x", "y")
DAU.plot(ax, x_interp, y_interp)


file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

R1 = np.array(df["R1"])
R1_err = np.array(df["R1_err"])

D_R1 = np.array(df["dR1"])
D_R2 = np.array(df["dR2"])

D_R = np.abs(np.array(df["dR"]))
D_R_err = np.array(df["dR_err"])


R1 = R1 - centre
R1 = abs(R1)

k = np.linspace(1, len(R1), len(R1))


## Finesse du Fabry Pérot
Delta_R1 = R1[2:] - R1[:-2]

print(Delta_R1)

fig2, ax2 = DAU.make_fig("$2\delta R_i$ (pixel)", "$R_{i+1}$-$R_{i-1}$ (pixel)")
results_fit1 = DAU.regression(
    x=2 * D_R[1:-1],
    y=Delta_R1,
    xerr=2 * D_R_err[1:-1],
    yerr=R1_err[1:-1] * np.sqrt(2),
    xmax=60,
    ax=ax2,
    color="blue",
    mec="blue",
)

F1 = results_fit1["a"]
F1_err = results_fit1["u_a"]


print(f"F1 = {F1} +/- {F1_err}")

plt.show()

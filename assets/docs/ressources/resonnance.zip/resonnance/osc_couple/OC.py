
################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b

# Reading data
file_path = "test_sample.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("x", "y")

# Performing regression with uncertainties and plotting raw data
if True:
   x    = np.array(df["x"])
   y    = np.array(df["y"])
   xerr = np.array(df["xerr"])
   yerr = np.array(df["yerr"])
   results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

# Quick test of how to use uncertainties package:
if True:
   # Step1: convert the panda dataframe containing raw data + incertainty into uarrays
   x_test = DAU.np2unp(np.array(df["x"]), np.array(df["xerr"]))
   y_test = DAU.np2unp(df["y"], df["yerr"])

   # Test of uncertainty propagation with simple multiplication
   test_x = x_test * y_test
   print(f"test_x {test_x}") 
   #or
   print(f"test_x {unumpy.nominal_values(test_x)} pm {unumpy.std_devs(test_x)}")

   # Raw computation to check if everything is working
   x, xerr = DAU.unp2np(x_test)
   y, yerr = DAU.unp2np(y_test)
   test_x_theo = x * y
   err_theo = np.abs(np.sqrt((xerr / x) ** 2 + (yerr / y) ** 2) * test_x_theo)
   print(f"err_theo{err_theo}")

# Switch from False to True for Monte Carlo regression, smoothing, and additional plots:
if True:
    fit_monte_carlo, fit_monte_carlo_err = DAU.monte_carlo_fit(
        x=df["x"],
        y=df["y"],
        func=linear_func,
        p0=[1, 1],
        xerr=df["xerr"],
        yerr=df["yerr"],
    plot_ax=ax,
        color="green",
        label="Monte Carlo fit",
    )

    # Smoothing the data
    data_smoothed = DAU.smooth(data=[df["x"], df["y"]], smooth_factor=5)

    # Plotting smoothed data
    DAU.plot(ax, data_smoothed[0], data_smoothed[1], color="red", label="Smoothed data")

# Adding legend and displaying the plot
ax.legend()
plt.show()
    
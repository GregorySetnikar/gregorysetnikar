################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


DAU.init_umath()
lambda_0 = 589.3e-9  # nm
lambda_0_err = 0.1e-9  # nm

l_0 = DAU.np2unp(lambda_0, lambda_0_err)
# Reading data
file_path = "sodium.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("p", "xp (en mm)")

x = np.array(df["nb_p"])
y = np.array(df["xp"]) * 0.001
yerr = np.array(df["xp_err"]) * 0.001
results_fit = DAU.regression(x=x, y=y, yerr=yerr, ax=ax, color="blue")

A = DAU.np2unp(results_fit["a"], results_fit["u_a"])

DL = (l_0 * l_0) / (2 * A)
DL_tab = 0.597e-9
delta_L, u_delta_L = DAU.unp2np([DL])

print(f"DL {DL}")

zscore = (delta_L - DL_tab) / u_delta_L
print(f"zscore {zscore}")


# Quick test of how to use uncertainties package:
if False:
    # Step1: convert the panda dataframe containing raw data + incertainty into uarrays
    x_test = DAU.np2unp(np.array(df["x"]), np.array(df["xerr"]))
    y_test = DAU.np2unp(df["y"], df["yerr"])

    # Test of uncertainty propagation with simple multiplication
    test_x = x_test * y_test
    print(f"test_x {test_x}")
    # or
    print(f"test_x {unumpy.nominal_values(test_x)} pm {unumpy.std_devs(test_x)}")

    # Raw computation to check if everything is working
    x, xerr = DAU.unp2np(x_test)
    y, yerr = DAU.unp2np(y_test)
    test_x_theo = x * y
    err_theo = np.abs(np.sqrt((xerr / x) ** 2 + (yerr / y) ** 2) * test_x_theo)
    print(f"err_theo{err_theo}")

# Switch from False to True for Monte Carlo regression, smoothing, and additional plots:
if False:
    fit_monte_carlo, fit_monte_carlo_err = DAU.monte_carlo_fit(
        x=df["x"],
        y=df["y"],
        func=linear_func,
        p0=[1, 1],
        xerr=df["xerr"],
        yerr=df["yerr"],
        plot_ax=ax,
        color="green",
        label="Monte Carlo fit",
    )

    # Smoothing the data
    data_smoothed = DAU.smooth(data=[df["x"], df["y"]], smooth_factor=5)

    # Plotting smoothed data
    DAU.plot(ax, data_smoothed[0], data_smoothed[1], color="red", label="Smoothed data")

# Adding legend and displaying the plot
ax.legend()
plt.show()

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


DAU.init_umath()


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
fig, ax = DAU.make_fig("$sin(\\theta)$", "$\lambda$")

D = 1  #  en m

d = np.array(df["d"])
d_err = np.array(df["d_err"])

du = DAU.np2unp(d, d_err) * 1e-2

theta = unp.arctan(du / D)

t, ut = DAU.unp2np(theta)

sinut = unp.sin(theta)
# Creating a blank figure with x, y labels

y, yerr = DAU.unp2np(sinut)

x = df["lambda"] * 1e-9
xerr = df["lambda_err"] * 1e-9

results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

print(f"theta {np.rad2deg(t)} pm {ut}")

print(f"{np.rad2deg(ut)*60}")

# Adding legend and displaying the plot
ax.legend()
plt.show()

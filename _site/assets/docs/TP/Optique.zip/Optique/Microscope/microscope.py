################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy

# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$\Delta (m)$", "P")

d0 = 191  # cm


A01_v = d0 - np.array(df["AO1"])
A01_err = np.array(df["AO1_err"])
O1Ap_v = d0 - np.array(df["O1Ap"])
O1Ap_err = np.array(df["O1Ap_err"])

# Extract raw data, and convert into unp
AO1 = DAU.np2unp(A01_v, A01_err)
O1Ap = DAU.np2unp(O1Ap_v, O1Ap_err) - AO1
ApBp = DAU.np2unp(np.array(df["ApBp"]), np.array(df["ApBp_err"]))
AppBpp = DAU.np2unp(np.array(df["AppBpp"]), np.array(df["AppBpp_err"]))

# Constants
f1 = 20  # en cm
f2 = 16  # en cm
f3 = 30  #  en cm
AB = DAU.np2unp(1.5, 0.2) * 1e-2  # m
# print(AB)

# Computed values
Delta = (O1Ap - f1) * 1e-2
gamma = ApBp * 1e-2 / AB
alpha = AppBpp / f3
P = alpha / AB

# Performing regression with uncertainties and plotting raw data
x, xerr = DAU.unp2np(Delta)
y, yerr = DAU.unp2np(P)

results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

V1 = 1 / (f1 * 1e-2)
V2 = 1 / (f2 * 1e-2)
C = V1 * V2

print(f"C_exp {results_fit["a"]}  pm {results_fit['u_a']} vs C_theo {C}")

# Creating a blank figure with x, y labels
fig2, ax2 = DAU.make_fig("$\Delta (m)$", "$\gamma$")
# Performing regression with uncertainties and plotting raw data
x, xerr = DAU.unp2np(Delta)
y, yerr = DAU.unp2np(gamma)

results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax2, color="red")

V1 = 1 / (f1 * 1e-2)
print(f"V_exp {results_fit["a"]} pm {results_fit['u_a']} vs V_theo {V1}")

# Adding legend and displaying the plot
ax.legend()
plt.show()

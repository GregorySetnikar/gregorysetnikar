#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utilitaires de traitement de données

Dépendances:

Usage: [pas d'usage direct a priori]

Auteurs: agrégatifs de physique 2024-2025
"""

# Importation des librairies
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as scopt
import scipy.ndimage as scndi
from uncertainties import ufloat, unumpy
import uncertainties.umath as umath
import csv


def detect_delimiter(file_path):
    """
    Détecte automatiquement le délimiteur d'un fichier texte.
    Essaie plusieurs délimiteurs possibles et retourne celui qui fonctionne.
    L’intérêt de cette fonction et de pouvoir ouvrir rapidement les fichiers issu de Regressi, LatisPro, etc

    Parameters:
        file_path (str): Chemin du fichier.

    Returns:
        str: Délimiteur détecté.
    """

    with open(file_path, "r", newline="", encoding="utf-8") as f:
        sample = f.read(1024)  # Lire un échantillon du fichier
        dialect = csv.Sniffer().sniff(
            sample, delimiters="\t;,| "
        )  # Détecter le délimiteur
        print(f"Délimiteur détecté : '{dialect.delimiter}'")
        return dialect.delimiter


def loadfile(file_path):
    """
    Lit un fichier txt et le stocke dans un DataFrame Pandas,
    tout en gérant les unités et les valeurs NaN.
    """

    try:
        # Lire les premières lignes pour détecter le délimiteur et les unités
        with open(file_path, "r") as file:
            lines = [line.rstrip("\t\n") for line in file]

        # Détection du délimiteur
        delimiter = detect_delimiter(file_path=file_path)
        header = lines[0].strip().split(delimiter)
        second_line = lines[1].strip().split(delimiter) if len(lines) > 1 else []

        # Détection des unités sous forme de dictionnaire
        units = {}
        is_units_row = False  # On suppose que la 2e ligne n'est PAS une ligne d'unités

        for col_name, item in zip(header, second_line):
            try:
                float(item)  # Si conversion en nombre OK, ce n'est PAS une unité
                units[col_name] = None
            except ValueError:
                is_units_row = (
                    True  # La deuxième ligne contient du texte → unités détectées
                )
                units[col_name] = item

        # Définir combien de lignes sauter
        skiprows = (
            [1] if is_units_row else []
        )  # Sauter seulement si la 2e ligne contient des unités

        # Fix le problème des tabulations fantomes en fin de lignes
        if delimiter == " " or delimiter == "\t":
            delimiter = r"\s+"

        # Charger les données en DataFrame
        df = pd.read_csv(
            file_path,
            sep=delimiter,
            skiprows=skiprows,
            na_values=["", "NA", "NaN", "NAN", "nan"],
            engine="python",
        )

        print(f"Fichier chargé avec succès : {file_path}")
        return df, units

    except Exception as e:
        print(f"Erreur lors de la lecture du fichier : {e}")
        return None, None


def filter_df(df, column_name, value):
    """
    Extrait/filtre un Pandas.DataFrame en fonction d'une valeur value de la colonne column_name.

    Exemple:
    print(df)
    output>>>
    animal   one  two  three
    mouse     1    2      3
    mouse     4    5      6
    rabbit    4    5      4
    rabbit    7    8      9

    filtered_df = filter_df(df,"animal","mouse")
    print(filtered_df)
    output>>>
    animal  one  two  three
    mouse    1    2      3
    mouse    4    5      6

    L'intérêt est de pouvoir remplir dans un fichier Excel, toutes les mesures par exemple de I et U en fonction de R, pour plusieurs R dans 3 colonnes, d'exporter en csv, puis refiltrer pour chaque valeur de R les datas, et manipuler moins de np.array, avec des noms clairs (pas besoin de faire n tableaux nommés R_n, on a le df pour R=20 etc.)

    Parameters:
        df (pd.DataFrame): The input DataFrame.
        column_name (str): The column name to filter by.
        value: The value to filter for.

    Returns:
        pd.DataFrame: Filtered DataFrame.
    """
    return df[df[column_name] == value]


def format_value_with_uncertainty(value, uncertainty):
    """
    Formate une valeur et son incertitude en écriture scientifique avec deux chiffres significatifs pour l'incertitude.

    Arguments :
        value (float) : la valeur principale.
        uncertainty (float) : l'incertitude associée.

    Retourne :
        str : chaîne de caractères formatée sous la forme "valeur ± incertitude" en notation scientifique.
    """
    # Gestion des cas particuliers
    if uncertainty < 0:
        uncertainty = -uncertainty
    elif uncertainty == 0.0 or uncertainty is None:
        formatted_value = f"{value:.1f}"
        return formatted_value, formatted_value

    # Obtenir l'ordre de grandeur de l'incertitude
    uncertainty_order = np.floor(
        np.log10(uncertainty)
    )  # Exposant de la puissance de 10
    scale = 10**uncertainty_order  # Échelle pour ajuster à l'ordre de grandeur

    # Réduire l'incertitude et la valeur à une base entre 1 et 10
    reduced_uncertainty = uncertainty / scale
    reduced_value = value / scale

    # Arrondir l'incertitude à 2 chiffres significatifs
    rounded_uncertainty = round(reduced_uncertainty, 1)

    # Ajuster la valeur principale en fonction de l'incertitude
    rounded_value = round(reduced_value, 1)

    # Génération de la chaîne formatée en notation scientifique
    formatted_result = (
        f"({rounded_value:.1f} ± {rounded_uncertainty:.1f}) × 10^{uncertainty_order}"
    )
    formatted_value = f"{rounded_value:.1f}× 10^{uncertainty_order}"
    return formatted_result, formatted_value


def plot(ax, x, y, xerr=None, yerr=None, highlight_points=0, **kwargs):
    """
    Trace x, y sur une figure donnée avec ou sans incertitudes.
    Parameters:
        ax (matplotlib.axes.Axes): L'axe sur lequel tracer.
        x (array-like): Données en x.
        y (array-like): Données en y.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        highlight_points (int, optional): Nombre de points à mettre en surbrillance.
        **kwargs: Options supplémentaires pour plt.plot.
    """

    # Permets d’uniformiser la couleur des points avec celui du fit
    if "color" in kwargs:
        color = kwargs["color"]
        kwargs.setdefault("color", color)
        kwargs.setdefault("mec", color)  # Bordure des marqueurs
        kwargs.setdefault("ecolor", color)  # Couleur des barres d'erreur

    line = ax.errorbar(
        x=x,
        y=y,
        xerr=xerr,
        yerr=yerr,
        fmt="+",
        capsize=5,
        **kwargs,
    )

    color = line[0].get_mec()

    # Highlight the last n points if specified
    if highlight_points is not None and highlight_points > 0:
        # Ensure the range doesn't exceed the data size
        highlight_indices = slice(-highlight_points, None)

        # Extract relevant data for highlighting
        x_highlight = x[highlight_indices]
        y_highlight = y[highlight_indices]
        xerr_highlight = xerr[highlight_indices] if xerr is not None else None
        yerr_highlight = yerr[highlight_indices] if yerr is not None else None

        # Plot the highlighted points with error bars if applicable
        ax.errorbar(
            x=x_highlight,
            y=y_highlight,
            xerr=xerr_highlight,
            yerr=yerr_highlight,
            marker="o",
            color="red",
            markersize=10,
            # mec="red",
            ecolor="red",
            capsize=5,
            zorder=5,  # Ensure it's on top
            label=f"Points faits en direct",
        )

    return color


def add_points(arrays, values, err_arrays=None, errors=None):
    """
    Ajoute des points (values) à des np.array (arrays).
    L'objectif est d'ajouter des valeurs pour la prise de points en direct.

    Args:
        arrays (array-like): Tableau contenant les tableaux x et y
        values (array-like): Tableau contenant les valeurs x et y ajoutées en live
        err_arrays (array-like, optional): Idem pour les erreurs. Defaults to None.
        errors (array-like, optional): Idem pour les erreurs. Defaults to None.

    Returns:
        x, y, xerr, yerr (array-like): Tableaux x, y, xerr, yerr complétés
    """
    x = np.append(arrays[0], values[0])
    y = np.append(arrays[1], values[1])

    if errors is not None:
        xerr = np.append(err_arrays[0], errors[0])
        yerr = np.append(err_arrays[1], errors[1])
    else:
        xerr = None
        yerr = None

    return x, y, xerr, yerr


def smooth(data, smooth_factor):
    """
    Fonction de filtrage du signal avec un filtre gaussien.
    Parameters:
        data (array-like): Données à filtrer.
        smooth_factor (float): Facteur de lissage, correspond à l'écart-type de la Gaussienne utilisé par le noyau du filtre. (voir https://docs.scipy.org/doc/scipy/reference/generated/scipy.ndimage.gaussian_filter1d.html pour plus d'informations.)

    Returns:
        array-like: Données filtrées avec un filtre gaussien.

    L'intéret de cette fonction est d'avoir un filtre sans avoir à se souvenir de la fonction scipy, plus facile d'utilisation.
    """
    return scndi.gaussian_filter1d(input=data, sigma=smooth_factor)


def validate_and_shrink(x, y, xerr, yerr, xmin, xmax):
    """
    Extrait un sous-ensemble des données sur l'intervalle [xmin,xmax]
    """
    # Adjust xmin and xmax if needed
    if xmin is None or xmin < min(x):
        xmin = min(x)
    if xmax is None or xmax > max(x):
        xmax = max(x)

    if xmin >= max(x) or xmax <= min(x):
        print("Erreur sur la plage sélectionnée. Ajustement sur tous les points.")
        xmin, xmax = min(x), max(x)

    # Create mask for valid x values within the selected range
    mask = (x >= xmin) & (x <= xmax)

    # Apply mask to x, y, and error arrays, but only if they're not None
    x_filtered = x[mask]
    y_filtered = y[mask]

    # Handle xerr and yerr if they are not None
    if xerr is not None:
        xerr_filtered = xerr[mask]
    else:
        xerr_filtered = None

    if yerr is not None:
        yerr_filtered = yerr[mask]
    else:
        yerr_filtered = None

    return x_filtered, y_filtered, xerr_filtered, yerr_filtered, xmin, xmax


def make_fig(labelx, labely):
    """
    Création d'une figure avec un titre et des labels pour x et y.
    Parameters:
        labelx (str): Label pour l'axe x.
        labely (str): Label pour l'axe y.

    Returns:
        tuple: Une figure matplotlib et son axe ax.

    L'intérêt de cette fonction est de gagner du temps sur la création de figures avec les bons paramètres.
    """
    fig, ax = plt.subplots()
    fig.set_size_inches((8, 7))
    ax.set_xlabel(labelx, fontsize=18)
    ax.set_ylabel(labely, fontsize=18)
    ax.tick_params(axis="both", labelsize=15)
    ax.ticklabel_format(style="sci", axis="both", scilimits=(-3, 3))
    ax.grid()

    return fig, ax


def regression(
    x,
    y,
    xerr=None,
    yerr=None,
    fig=None,
    ax=None,
    model="affine",
    xmin=None,
    xmax=None,
    N=1000,
    highlight_points=0,
    **kwargs,
):
    """
    Fonction de régression linéaire ou affine sur des données avec utilisation d'un algorithme Monte-Carlo pour prendre en compte les incertitudes sur x et y au sein de la régression.

    Parameters:
        x (array-like): Données en x.
        y (array-like): Données en y.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        ax (matplotlib.axes.Axes, optional): Axe sur lequel tracer la régression. Si None, une nouvelle figure est créée.
        model (str, optional): Modèle de régression. Par défaut, "affine".
        xmin (float, optional): Limite inférieure de la plage de valeurs pour x. Si None, la plage est déterminée automatiquement.
        xmax (float, optional): Limite supérieure de la plage de valeurs pour x. Si None, la plage est déterminée automatiquement.
        N (int, optional): Nombre de points pour la simulation Monte-Carlo. Par défaut, 1000.
        highlight_points (int, optional): Nombre de points à surligner en partant de la fin du tableau. Sert pour souligner les points faits en direct pour les montages. Par défaut, 0.
        **kwargs: Options supplémentaires pour plt.plot et plt.errorbar.

    Returns:
        output (dict): Résultats de la régression


    Modèle "affine" : y = ax + b
    Modèle "lineaire" : y = ax
    """

    xerr_p = yerr_p = 0
    if xerr is None:
        xerr_p = None
        xerr = np.zeros_like(x)
    if yerr is None:
        yerr_p = None
        yerr = np.zeros_like(y)

    # On stocke les différents tableaux x,y,xerr et yerr pour pouvoir tracer tout les points, même si on effectue la régression que sur certains point
    x_all, y_all, xerr_all, yerr_all = x, y, xerr, yerr

    # Modification des tableaux pour ne faire l'ajustement que sur la plage de valeurs demandée (x compris entre xmin et xmax)
    x, y, xerr, yerr, xmin, xmax = validate_and_shrink(x, y, xerr, yerr, xmin, xmax)

    # Monte-Carlo simulation
    nbpts = len(x)
    x_samples = np.array([x + xerr * np.random.uniform(-1, 1, nbpts) for _ in range(N)])
    y_samples = np.array([y + yerr * np.random.uniform(-1, 1, nbpts) for _ in range(N)])

    # Calcul des points moyens
    x_mean = np.mean(x_samples, axis=0)
    y_mean = np.mean(y_samples, axis=0)

    # Régression sur les points moyens
    if model == "lineaire":
        a = np.sum(x_mean * y_mean) / np.sum(x_mean**2)
        b = 0
    elif model == "affine":
        a, b = np.polyfit(x_mean, y_mean, 1)
    else:
        raise ValueError("Modèle inconnu. Utilisez 'affine' ou 'lineaire'.")

    # Calcul des incertitudes avec Monte-Carlo
    a_samples = []
    b_samples = [] if model == "affine" else None

    for i in range(N):
        if model == "lineaire":
            a_temp = np.sum(x_samples[i] * y_samples[i]) / np.sum(x_samples[i] ** 2)
            a_samples.append(a_temp)
        elif model == "affine":
            p = np.polyfit(x_samples[i], y_samples[i], 1)
            a_samples.append(p[0])
            b_samples.append(p[1])

    if xerr_p is None and yerr_p is None:
        u_a = u_b = 0
    else:
        u_a = np.std(a_samples)
        u_b = np.std(b_samples) if model == "affine" else 0

    # Affichage des résultats
    if model == "lineaire":
        print(f"Ajustement entre {xmin} et {xmax} : y = ax")
        string2print, value_a = format_value_with_uncertainty(a, u_a)
        fit = f"a = {string2print}"

    elif model == "affine":
        print(f"Ajustement entre {xmin} et {xmax} : y = ax + b")
        string2print_a, value_a = format_value_with_uncertainty(a, u_a)
        string2print_b, value_b = format_value_with_uncertainty(b, u_b)
        fit = f"a = {string2print_a} \n b = {string2print_b}"
        print(fit)

    if xerr_p is not None and yerr_p is not None:
        # Calcul du chi²
        y_pred = a * x + b
        chi2 = np.sum(((y - y_pred) ** 2) / (yerr**2 + (a * xerr) ** 2))
    else:
        chi2 = 1

    chi2_red = chi2 / (len(x) - (1 if model == "lineaire" else 2))

    print(f"chi2 / (N - p) = {chi2_red:.2e}")

    # Affichage des graphiques correspondant
    if ax is not None:
        color = plot(
            ax=ax,
            x=x_all,
            y=y_all,
            xerr=xerr_all,
            yerr=yerr_all,
            label=f"Données brutes",
            highlight_points=highlight_points,
            **kwargs,
        )

        if "color" not in kwargs:
            kwargs["color"] = color

        ax.plot(
            x_all,
            a * x_all + b,
            label=(
                f"Régression {model} : y = ax \n {fit}"
                if model == "lineaire"
                else f"Régression {model} : y = ax+b \n {fit}"
            ),
            **kwargs,
        )

        ax.legend()

    output = {
        "a": a,
        "b": b,
        "u_a": u_a,  # Incertitude de la pente par Monte Carlo
        "u_b": u_b,  # Incertitude de l'ordonnée à l'origine par Monte Carlo
    }

    return output


def monte_carlo_fit(
    x, y, func, p0, xerr=None, yerr=None, n_iter=1000, plot_ax=None, **kwargs
):
    """
    Effectue une régression avec une simulation Monte-Carlo et optionnellement trace un snake plot, pour une fonction quelconque donnée en entrée.

    Parameters:
        x (array-like): Données en x.
        y (array-like): Données en y.
        func (callable): Fonction à ajuster.
        p0 (list): Estimations initiales des paramètres.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        n_iter (int): Nombre de simulations Monte-Carlo.
        plot_ax (matplotlib.axes._axes.Axes, optional): Axe matplotlib pour tracer le snake plot.
        **kwargs: Options supplémentaires pour plt.plot.
    Returns:
        tuple: (paramètres ajustés, incertitudes sur les paramètres).
    """

    if xerr is None:
        xerr = np.zeros_like(x)
    if yerr is None:
        yerr = np.zeros_like(y)

    # Fit initial
    popt, _ = scopt.curve_fit(func, x, y, p0=p0)

    # Monte-Carlo simulations
    param_samples = []
    for _ in range(n_iter):
        # Simuler x et y en tenant compte des erreurs
        x_sim = x + np.random.normal(0, xerr)
        y_sim = y + np.random.normal(0, yerr)

        try:
            popt_sim, _ = scopt.curve_fit(func, x_sim, y_sim, p0=popt)
            param_samples.append(popt_sim)
        except RuntimeError:
            # Si le fit échoue pour une simulation, ignorer cette itération
            continue

    param_samples = np.array(param_samples)
    if param_samples.size == 0:
        raise RuntimeError(
            "Aucune simulation Monte-Carlo n'a réussi. Vérifiez vos données et paramètres initiaux."
        )

    # Moyenne et écart-type des paramètres ajustés
    param_mean = np.mean(param_samples, axis=0)
    param_std = np.std(param_samples, axis=0)

    # Optionnel : trace le snake plot
    if plot_ax is not None:
        # Calculer la courbe centrale
        y_fit = func(x, *param_mean)

        # Simulation Monte-Carlo pour générer les incertitudes sur y
        y_samples = []
        for _ in range(n_iter):
            params_sample = np.random.normal(param_mean, param_std)
            y_samples.append(func(x, *params_sample))
        y_samples = np.array(y_samples)

        # Calcul des intervalles d'incertitudes
        y_low = np.percentile(y_samples, 16, axis=0)  # 1 sigma inférieur
        y_high = np.percentile(y_samples, 84, axis=0)  # 1 sigma supérieur

        # Trace la courbe centrale
        if "label" not in kwargs:
            plot_ax.plot(x, y_fit, label="Ajustement Monte Carlo", **kwargs)
        else:
            plot_ax.plot(x, y_fit, **kwargs)
        # Trace la bande
        plot_ax.fill_between(x, y_low, y_high, alpha=0.5, **kwargs)
        plot_ax.legend()

    for i in range(0, len(param_mean)):
        print(
            f"Paramètre {i}: Moyenne = {param_mean[i]:.3f}, Ecart-type = {param_std[i]:.3f}"
        )

    return param_mean, param_std


def plot_bode(
    freq, gain, phase, freq_err=None, gain_err=None, phase_err=None, **kwargs
):
    """
    Trace un diagramme de Bode.
    Parameters:
        freq (array-like): Fréquence.
        freq_err (array-like, optional): Incertitudes sur la fréquence.
        gain (array-like): Magnitude en dB.
        gain_err (array-like, optional): Incertitudes sur la magnitude.
        phase (array-like): Phase en degrés.
        phase_err (array-like, optional): Incertitudes sur la phase.
        **kwargs: Options supplémentaires pour plt.semilogx.
    """
    fig, axs = plt.subplots(2)
    fig.set_size_inches((8, 7))
    for ax in axs:
        ax.tick_params(axis="both", labelsize=15)
        ax.ticklabel_format(style="sci", axis="both", scilimits=(-3, 3))
        ax.grid()

    ax_mag = axs[0]
    ax_phase = axs[1]

    ax_mag.errorbar(
        x=freq,
        y=gain,
        xerr=freq_err,
        yerr=gain_err,
        fmt="+",
        # mec="k",
        # ecolor="k",
        capsize=5,
        label="Gain",
        **kwargs,
    )
    ax_mag.set_xscale("log")
    ax_phase.errorbar(
        x=freq,
        y=phase,
        xerr=freq_err,
        yerr=phase_err,
        fmt="+",
        # mec="k",
        # ecolor="k",
        capsize=5,
        label="Phase",
        **kwargs,
    )
    ax_phase.set_xscale("log")

    ax_mag.set_ylabel("Gain (dB)", fontsize=18)
    ax_phase.set_ylabel("Phase (°)", fontsize=18)
    ax_phase.set_xlabel("Fréquence (Hz)", fontsize=18)
    ax_mag.legend()
    ax_phase.legend()
    return


def np2unp(x, xerr):
    """L'objet de cette fonction est de convertir deux tableaux numpy contenant respectivement les données et leurs erreurs, en un tableau unumpy issu du package "uncertainties" pour automatiser la propagation de ces dernières.

    Args:
        x (array-like): Données
        xerr (array-like): Incertitudes

    Returns:
        unumpy.uarray: Tableau unumpy (Données,Incertitudes)
    """

    return unumpy.uarray(x, xerr)


def patch_umath_function(func_name):
    """Surcharge la fonction func_name pour lui permettre de supporter les lists et np.ndarrays

    Args:
        func_name (string): Nom de la fonction à surcharger
    """
    original_func = getattr(umath, func_name)  # Get original function

    def wrapper(x):
        if isinstance(x, (list, np.ndarray)):
            return [original_func(xi) for xi in x]  # Apply function element-wise
        return original_func(x)  # Apply function normally

    # Replace the original function in umath with the patched version
    setattr(umath, func_name, wrapper)


def init_umath():
    """Cette fonction permet surcharger l'ensemble des fonctions de umath pour le support des lists et np.arrays"""

    # List all standard mathematical functions in umath
    umath_functions = [
        "acos",
        "acosh",
        "asin",
        "asinh",
        "atan",
        "atan2",
        "atanh",
        "ceil",
        "copysign",
        "cos",
        "cosh",
        "degrees",
        "erf",
        "erfc",
        "exp",
        "expm1",
        "fabs",
        "factorial",
        "floor",
        "fmod",
        "frexp",
        "fsum",
        "gamma",
        "hypot",
        "isinf",
        "isnan",
        "ldexp",
        "lgamma",
        "log",
        "log10",
        "log1p",
        "modf",
        "pow",
        "radians",
        "sin",
        "sinh",
        "sqrt",
        "tan",
        "tanh",
        "trunc",
    ]
    # Apply monkey patching to all umath functions
    for func in umath_functions:
        patch_umath_function(func)


def unp2np(tab):
    """Cette fonction permet de revenir à deux tableaux numpy contenant respectivement les données et les incertitudes associés à partir d'un unumpy.uarray. Cette fonction est nécessaire pour afficher correctement les résultats sur un plot par exemple.

    Args:
        tab (unumpy.uarray): Tableau unumpy (Données,Incertitudes)

    Returns:
        numpy.array : Données, Incertitudes
    """
    x = []
    xerr = []
    for element in tab:
        x.append(element.nominal_value)
        xerr.append(element.std_dev)
    return np.array(x), np.array(xerr)


def make_template(fname=None):
    """
    Returns:
        str: Template de code Python pour l'utilisation du présent package.
    """
    template = """
################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b

# Reading data
file_path = "test_sample.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("x", "y")

# Performing regression with uncertainties and plotting raw data
if True:
   x    = np.array(df["x"])
   y    = np.array(df["y"])
   xerr = np.array(df["xerr"])
   yerr = np.array(df["yerr"])
   results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

# Quick test of how to use uncertainties package:
if True:
   # Step1: convert the panda dataframe containing raw data + incertainty into uarrays
   x_test = DAU.np2unp(np.array(df["x"]), np.array(df["xerr"]))
   y_test = DAU.np2unp(df["y"], df["yerr"])

   # Test of uncertainty propagation with simple multiplication
   test_x = x_test * y_test
   print(f"test_x {test_x}") 
   #or
   print(f"test_x {unumpy.nominal_values(test_x)} pm {unumpy.std_devs(test_x)}")

   # Raw computation to check if everything is working
   x, xerr = DAU.unp2np(x_test)
   y, yerr = DAU.unp2np(y_test)
   test_x_theo = x * y
   err_theo = np.abs(np.sqrt((xerr / x) ** 2 + (yerr / y) ** 2) * test_x_theo)
   print(f"err_theo{err_theo}")

# Switch from False to True for Monte Carlo regression, smoothing, and additional plots:
if True:
    fit_monte_carlo, fit_monte_carlo_err = DAU.monte_carlo_fit(
        x=df["x"],
        y=df["y"],
        func=linear_func,
        p0=[1, 1],
        xerr=df["xerr"],
        yerr=df["yerr"],
    plot_ax=ax,
        color="green",
        label="Monte Carlo fit",
    )

    # Smoothing the data
    data_smoothed = DAU.smooth(data=[df["x"], df["y"]], smooth_factor=5)

    # Plotting smoothed data
    DAU.plot(ax, data_smoothed[0], data_smoothed[1], color="red", label="Smoothed data")

# Adding legend and displaying the plot
ax.legend()
plt.show()
    """
    print(template)
    if fname:
        with open(fname, "w") as f:
            f.write(template)
    return


# Programme principal
if __name__ == "__main__":
    make_template(fname="microscope.py")

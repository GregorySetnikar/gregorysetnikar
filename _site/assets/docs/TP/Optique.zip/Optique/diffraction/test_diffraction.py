################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp
import uncertainties.umath as um

# Permet l�utilisation des fonctions math�matiques standards sur des tableaux unumpy (par d�faut seulement des scalaires)
DAU.init_umath()


# Function definition for linear fit with Monte Carlo
def sinc(x, E_0, x_0, c, cst):
    return E_0 * (np.sinc(c * (x - x_0))) ** 2 + cst


# Reading data
file_path = "Values.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$x (cm)$", "I (u.a)")

# import data
I = df["Gray_Value"]
x = df["Distance_(cm)"]

# DAU.plot(ax=ax, x=x, y=I)
p0 = [180, 2.7, 1, 80]
results_fit = DAU.monte_carlo_fit(x=x, y=I, ax=ax, func=sinc, p0=p0)

# Adding legend and displaying the plot
ax.legend()
plt.show()

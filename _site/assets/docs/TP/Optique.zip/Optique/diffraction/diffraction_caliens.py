################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp
import uncertainties.umath as um

# Permet l�utilisation des fonctions math�matiques standards sur des tableaux unumpy (par d�faut seulement des scalaires)
DAU.init_umath()


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "data_caliens.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$b$", "$\\frac{\lambda*D}{\Delta x}$")

# import data
b = df["b"] * 1e-3
n = df["n"]
dx = df["dx"] * 1e-2
dx_err = df["dx_err"] * 1e-2


L = 650e-9
f = 200e-3

udx = DAU.np2unp(dx, dx_err)

# Performing regression with uncertainties and plotting raw data
x = b
uy = (L * f * n) / udx
y, yerr = DAU.unp2np(uy)

cheveau = (1e-3) / 6
value = (L * f) / cheveau
print(f"cheveu {value} en m")


results_fit = DAU.regression(x=x, y=y, yerr=yerr, ax=ax, color="blue", model="lineaire")


# Adding legend and displaying the plot
ax.legend()
plt.show()

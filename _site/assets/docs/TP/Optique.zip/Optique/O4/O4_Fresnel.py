# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 10:37:44 2024

@author: physique
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 15:03:48 2024

@author: physique
"""


import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


# Constantes
f_prime = 5  # en cm
D = 2560  # en mm distance ecran/trou
u_D = 10  # en mm

d = 700  # mm
u_d = 50  # mm

lbda = 543.5e-7  # en cm


def linear(x, a, b):

    return a * x + b


## Données

b = np.array([183.5, 64, 40.5, 30, 24.5, 20.8, 18.5, 16.5])  # en cm
b -= f_prime

y = 1 / b
u_b = np.array([10, 4, 2, 1, 1, 0.5, 0.5, 0.5])
u_y = y**2 * u_b


k = np.array([1, 2, 3, 4, 5, 6, 7, 8])

p, pcov = curve_fit(linear, xdata=k, ydata=y, sigma=u_y)
perr = np.sqrt(np.diag(pcov))


fig = plt.figure()
plt.errorbar(x=k, y=y, yerr=u_y, fmt="o")
plt.plot(k, y)
plt.grid()

a = -1 / p[1]
u_a = perr[1] / p[1] ** 2

rho = np.sqrt(lbda / p[0])  # 0.19/2 théorique
d = 2 * np.sqrt(lbda / p[0])  # 0.19/2 théorique
# 0.19/2 théorique
u_rho = rho * perr[0] / p[0]
u_d = 2 * rho * perr[0] / p[0]


print(f"a {a} pm {u_a}")
print(f"rho {rho} pm {u_rho}")
print(f"d {d} pm {u_d}")

plt.show()

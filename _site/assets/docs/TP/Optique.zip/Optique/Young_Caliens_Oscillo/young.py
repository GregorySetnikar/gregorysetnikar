################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# 7000 µs = 28,67mm


i = (df["ni"] / df["n"]) * (28.67 / 7000)  # en mm
i_err = (df["ni_err"] / df["n"]) * (28.67 / 7000)  # en mm
# i = l D /a


# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$\lambda$", "i")

# Performing regression with uncertainties and plotting raw data
x = np.array(df["lambda"] * 1e-9)
y = np.array(i * 1e-3)
yerr = np.array(i_err * 1e-3)
results_fit = DAU.regression(x=x, y=y, yerr=yerr, ax=ax, color="blue")


D = 750e3  # mm
D_err = 5e3
a = D / results_fit["a"]

aerr = np.sqrt((D_err / D) ** 2 + (results_fit["u_a"] / results_fit["a"]) ** 2)
print(f"a = {a} pm {aerr} μm")


ax.legend()
plt.show()

# -*- coding: utf-8 -*-
"""
Created on Tue Apr  8 15:52:11 2025

@author: eliot
"""

import python_DataAnalysisUtils_lyon as dau
import numpy as np
import uncertainties.umath as umath
import uncertainties.unumpy as unp
import matplotlib.pyplot as plt

data, units = dau.loadfile("planck.csv", delimiter="\t")
print(data)

l = data["lambda"] * 10 ** (-9)
I1 = data["I1"]
I2 = data["I2"]

h = 6.62e-34
c = 3e8
k = 1.38e-23


def f(l, T):
    return ((h * c**2) / (l**5)) * (1 / (np.exp((h * c) / (l * k * T)) - 1))


def rapport(l, T1, T2):

    return ((np.exp((h * c) / (l * k * T1)) - 1)) / (np.exp((h * c) / (l * k * T2)) - 1)


def wien(l):
    return 2.89777291e-3 / l


fig, ax = dau.make_fig("$\lambda$ (en m)", "I (en ua)")
dau.plot(x=l, y=I1, ax=ax)
# s = dau.monte_carlo_fit(x=l, y=I1 / I2, func=rapport, p0=[2700, 2800], plot_ax=ax)


x = np.linspace(4e-7, 8e-7)
T = wien(5.9e-7)
T = 2500
T2 = 5000
y = f(x, T)  # / f(x, T2)

dau.plot(x=x, y=y, ax=ax)

plt.show()

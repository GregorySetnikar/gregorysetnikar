# -*- coding: utf-8 -*-
"""
Created on Tue Apr  8 15:52:11 2025

@author: eliot
"""

import python_DataAnalysisUtils_lyon as dau
import numpy as np
import uncertainties.umath as umath
import uncertainties.unumpy as unp


data, units = dau.loadfile("planck2.csv")

l = data["lambda"] * 10 ** (-9)
I1 = data["I1"]
I2 = data["I2"]


def f(l, T):
    h = 6.62e-34
    c = 3e8
    k = 1.38e-23
    a = 1e-9
    return a * 2 * h * c**2 / l**5 * 1 / (np.exp(h * c / (l * k * T)) - 1)


def f2(l, T):
    h = 6.62e-34
    c = 3e8
    k = 1.38e-23
    return 2 * h * c**2 / l**5 * 1 / (np.exp(h * c / (l * k * T)) - 1)


def f3(l, T):
    h = 6.62e-34
    c = 3e8
    k = 1.38e-23
    return ((h * c**2) / (l**5)) * (1 / (np.exp((h * c) / (l * k * T)) - 1))


def wien(l):
    return 2.89777291e-3 / l


# %%

fig, ax = dau.make_fig("$\lambda$ (en m)", "I (en ua)")
dau.plot(x=l, y=I, ax=ax)
# es = dau.monte_carlo_fit(x=l, y=I, func=f3, p0=[2800], plot_ax=ax,xmax=5.5e-7)

x = np.linspace(4e-7, 8e-7)
T = wien(5.9e-7)
T = 2800
y = f3(x, T) * 1e-7 - 0.09e4

dau.plot(x=x, y=y, ax=ax)

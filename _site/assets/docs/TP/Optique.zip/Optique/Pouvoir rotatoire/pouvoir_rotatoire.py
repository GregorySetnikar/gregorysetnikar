################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$1/\lambda^2$ (en $nm^2$)", "pouvoir rotatoire spécifique ")

# Performing regression with uncertainties and plotting raw data

x = (np.array(df["x2"]) - np.array(df["x1"])) * 1e-1  # en dm
l = np.array(df["lambda"])
xerr = np.array(df["x1_err"]) * 1e-1
lerr = np.array(df["lambda_err"])

c = 0.825  # mol/L
alpha = 180  # degré
h = 3  # en dm

ux = DAU.np2unp(x, xerr)
ualpha_spe = alpha / (ux * c)
print(ualpha_spe)
alpha_spe, alpha_spe_err = DAU.unp2np(ualpha_spe)

ul = DAU.np2unp(l, lerr)
ul2 = 1 / ul**2

l2, l2err = DAU.unp2np(ul2)

fit = DAU.regression(
    ax=ax, x=l2, y=alpha_spe, xerr=l2err, yerr=alpha_spe_err, color="blue"
)

# results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")


# Adding legend and displaying the plot
ax.legend()
plt.show()

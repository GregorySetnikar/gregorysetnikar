################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Reading data
file_path = "data_exp.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

ldba = df["lambda"] * 1e-9
ldba_err = np.ones(len(ldba)) * 0.4e-9

n = df["n"]
m = df["m"]

uL = DAU.np2unp(ldba, ldba_err)

uL1 = 1 / uL

y, yerr = DAU.unp2np(uL1)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig(
    "$\\frac{1}{n^2} - \\frac{1}{m^2}$", "$\\frac{1}{\lambda} (m^{-1})$"
)

# Performing regression with uncertainties and plotting raw data

x = (1 / n**2) - (1 / m**2)
results_fit = DAU.regression(x=x, y=y, yerr=yerr, ax=ax, color="blue", model="lineaire")

h = 6.58e-16
c = 2.98e8

ry, rystr = DAU.format_value_with_uncertainty(results_fit["a"], results_fit["u_a"])

print(f"Ry = {ry}")

ry = results_fit["a"] * (h * c)
ry_err = results_fit["u_a"] * (h * c)

ry, rystr = DAU.format_value_with_uncertainty(ry, ry_err)
print(f"Ry = {ry}")

ax.legend()
plt.show()

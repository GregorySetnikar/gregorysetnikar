#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utilitaires divers pour le post-traitement de données sous python

Dépendances:

Usage: [pas d'usage direct a priori]

Auteurs: C. Winisdoerffer (21/08/2024)
"""

# Importation des librairies
import numpy as np
import scipy.optimize as scopt

# Définition des fonctions
def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """ Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X
    (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés a partir de paramètres d'essai a_test et
    b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    Auteur: B. Guiselin
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )

    opt_affine = scopt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    # print("Résultats de l'ajustement :")
    # print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    # print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

# Programme principal
if __name__ == "__main__":
   pass

   


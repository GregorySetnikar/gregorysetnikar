#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN
Version du 22/07/2022
"""
# %% Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt


# %% Définition de fonctions pour effectuer des modélisations affine et non linéaire de données À NE PAS MODIFIER
def modele_NL(X, Y, u_X, u_Y, params_test, f, f_deriv):
    """
    Effectue une modélisation non linéaire Y = f(X,params), en tenant compte des incertitudes sur X (u_X)
    et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d’essai contenus dans le
    tableau params_test.
    La fonction renvoie un tableau qui contient dans l’ordre :
    - les paramètres optimisés dans l’ordre (params_opt),
    - leurs incertitudes dans l’ordre (u_params_opt),
    - la valeur du chi2 réduit (chi2_opt).
    f_deriv désigne la dérivée de la fonction f pour le calcul des résidus.
    """

    def residu_NL(params, x, y, u_x, u_y):
        return (y - f(x, params)) / np.sqrt(u_y * u_y + (f_deriv(x, params) * u_x) ** 2)

    opt_NL = opt.least_squares(residu_NL, params_test, args=(X, Y, u_X, u_Y))
    params_opt = opt_NL.x
    hessian_NL = np.matmul(opt_NL.jac.transpose(), opt_NL.jac)
    u_params_opt = np.sqrt(2.0 / np.abs(np.diagonal(hessian_NL)))
    chi2_opt = np.sum(residu_NL(params_opt, X, Y, u_X, u_Y) ** 2) / (len(X) - 2)
    return np.hstack((params_opt, u_params_opt, np.array([chi2_opt])))


def modele_affine(X, Y, u_X, u_Y, a_test, b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (
    u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d’essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l’ordre :
    - la valeur de a optimisée (a_opt),
    - la valeur de b optimisée (b_opt),
    - l’incertitude sur la valeur de a (u_a_opt),
    - l’incertitude sur la valeur de b (u_b_opt),
    - la valeur du chi2 réduit (chi2_opt).
    """

    def affine(x, a, b):
        return a * x + b

    def residu_affine(p_affine, x, y, u_x, u_y):
        a = p_affine[0]
        b = p_affine[1]
        return (y - affine(x, a, b)) / np.sqrt(u_y * u_y + (a * u_x) ** 2)

    opt_affine = opt.least_squares(
        residu_affine, np.array([a_test, b_test]), args=(X, Y, u_X, u_Y)
    )
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(), opt_affine.jac)
    u_a_opt = np.sqrt(2.0 / hessian_affine[0, 0])
    u_b_opt = np.sqrt(2.0 / hessian_affine[1, 1])
    chi2_opt = np.sum(residu_affine(np.array([a_opt, b_opt]), X, Y, u_X, u_Y) ** 2) / (
        len(X) - 2
    )
    print("Résultats de l’ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt, u_a_opt))
    print("- ordonnée à l’origine = {0:.2e} +/- {1:.1e}".format(b_opt, u_b_opt))
    return np.array([a_opt, b_opt, u_a_opt, u_b_opt, chi2_opt])


# %% Paramètres À MODIFIER
filename = "data.txt"  # nom du fichier avec f, u(f), Ue, u(Ue), Us, u(Us), phi, u(phi) dans les unités SI
R = 1e4  # résistance en ohm
u_R = 1  # incertitude sur la résistance en ohm
C = 1e-8  # capacité en F
u_C = 1e-9  # incertitude sur la capacité en ohm

# %% Importation des données
data = np.genfromtxt(filename)
freq = data[:, 0]
u_freq = data[:, 1]
Ue = data[:, 2]
u_Ue = data[:, 3]
Us = data[:, 4]
u_Us = data[:, 5]
phi = data[:, 6] * np.pi / 180.0  # conversion des degrés en radians
u_phi = data[:, 7] * np.pi / 180.0  # conversion des degrés en radians

# %% Définition de variables auxiliaires
puls = 2.0 * np.pi * freq
u_puls = 2.0 * np.pi * u_freq
gain = Us / Ue
u_gain = gain * np.sqrt(
    (u_Ue / Ue) ** 2 + (u_Us / Us) ** 2
)  # utilisation de la formule de propagation
# des incertitudes pour un produit
tauRC = R * C
u_tauRC = tauRC * np.sqrt(
    (u_R / R) ** 2 + (u_C / C) ** 2
)  # utilisation de la formule de propagation
# des incertitudes pour un produit


# %% Effectuer une modélisation non linéaire du gain et de la phase (non recommandée)
def gain_th(w, tau):  # fonction de modélisation
    x = w * tau
    return 1.0 / np.sqrt(1.0 + x * x)


def gain_th_deriv(
    w, tau
):  # dérivée de la fonction de modélisation en fonction de la pulsation
    x = w * tau
    return -x * tau / (1.0 + x * x) ** (3.0 / 2.0)


def phase_th(w, tau):  # fonction de modélisation
    x = w * tau
    return -np.arctan(x)


def phase_th_deriv(
    w, tau
):  # dérivée de la fonction de modélisation en fonction de la pulsation
    x = w * tau
    return -tau / (1.0 + x * x)


param_NL_gain = modele_NL(
    puls, gain, u_puls, u_gain, np.array([tauRC]), gain_th, gain_th_deriv
)
tau_gain = param_NL_gain[0]  # valeur optimale de tau
u_tau_gain = param_NL_gain[1]  # incertitude associée
chi2_gain = param_NL_gain[2]  # chi2 réduit

param_NL_phase = modele_NL(
    puls, phi, u_puls, u_phi, np.array([tauRC]), phase_th, phase_th_deriv
)
tau_phase = param_NL_phase[0]  # valeur optimale de tau
u_tau_phase = param_NL_phase[1]  # incertitude associée
chi2_phase = param_NL_phase[2]  # chi2 réduit

# %% Effectuer une modélisation linéaire du gain et de la phase (recommandée)
puls2 = puls * puls  # carré de la pulsation
u_puls2 = 2.0 * puls * u_puls  # incertitude sur le carré de la pulsation
gain_m2 = 1.0 / gain / gain  # inverse du carré du gain
u_gain_m2 = gain_m2 * 2.0 * u_gain / gain  # incertitude sur l’inverse du carré du gain
tan_phi = np.tan(phi)  # tangente de la phase
u_tan_phi = u_phi * (1.0 + tan_phi * tan_phi)  # incertitude sur la tangente de la phase

param_affine_gain = modele_affine(
    puls2, gain_m2, u_puls2, u_gain_m2, tauRC * tauRC, 1.0
)
a_affine_gain = param_affine_gain[0]  # extraction de la pente
u_a_affine_gain = param_affine_gain[2]  # extraction de l’incertitude sur la pente
b_affine_gain = param_affine_gain[1]  # extraction de l’ordonnée à l’origine
u_b_affine_gain = param_affine_gain[
    3
]  # extraction de l’incertitude sur l’ordonnée à l’origine
chi2_affine_gain = param_affine_gain[4]  # extraction du chi2 réduit
tau_affine_gain = np.sqrt(a_affine_gain)  # extraction de tau à partir de la pente
u_tau_affine_gain = (
    tau_affine_gain * 0.5 * u_a_affine_gain / a_affine_gain
)  # incertitude de tau à partir
# de celle de la pente

param_affine_phase = modele_affine(puls, tan_phi, u_puls, u_tan_phi, tauRC, 0.0)
a_affine_phase = param_affine_phase[0]  # extraction de la pente
u_a_affine_phase = param_affine_phase[2]  # extraction de l’incertitude sur la pente
b_affine_phase = param_affine_phase[1]  # extraction de l’ordonnée à l’origine
u_b_affine_phase = param_affine_phase[
    3
]  # extraction de l’incertitude sur l’ordonnée à l’origine
chi2_affine_phase = param_affine_phase[4]  # extraction du chi2 réduit

# %% Affichage des résultats
print("\nModélisation non linéaire du gain")
print("- tau (non linéaire) = {0:.2e} +/- {1:.1e}".format(tau_gain, u_tau_gain))
print("- chi2 (non linéaire) = {0:.2f}".format(chi2_gain))

print("\nModélisation linéaire du gain")
print(
    "- tau (linéaire) = {0:.2e} +/- {1:.1e}".format(tau_affine_gain, u_tau_affine_gain)
)
print("- chi2 (linéaire) = {0:.2f}".format(chi2_affine_gain))

print("\nModélisation non linéaire de la phase")
print("- tau (non linéaire) = {0:.2e} +/- {1:.1e}".format(tau_phase, u_tau_phase))
print("- chi2 (non linéaire) = {0:.2f}".format(chi2_phase))

print("\nModélisation linéaire de la phase")
print("- tau (linéaire) = {0:.2e} +/- {1:.1e}".format(a_affine_phase, u_a_affine_phase))
print("- chi2 (linéaire) = {0:.2f}".format(chi2_affine_phase))

# %% Tracé des graphes
plt.figure()
plt.errorbar(puls, gain, u_gain, u_puls, fmt="o", label="données expérimentales")
plt.plot(puls, gain_th(puls, tau_affine_gain), label="modèle ajusté (gain)")
plt.xscale("log")
plt.xlabel("Pulsation $\\omega$ (rad/s)")
plt.ylabel("Gain")
plt.legend()
plt.grid(True)
plt.show()

plt.figure()
plt.errorbar(puls, phi, u_phi, u_puls, fmt="o", label="données expérimentales")
plt.plot(puls, phase_th(puls, tau_affine_gain), label="modèle ajusté (phase)")
plt.xscale("log")
plt.xlabel("Pulsation $\\omega$ (rad/s)")
plt.ylabel("Phase $\\varphi$ (rad)")
plt.legend()
plt.grid(True)
plt.show()

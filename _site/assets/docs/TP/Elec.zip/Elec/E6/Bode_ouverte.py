# -*- coding: utf-8 -*-
"""
Created on Tue Oct  8 12:44:06 2024

@author: ens
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt

freq = np.array([100, 500, 1000,2000,5000,10000,50000])
Phi_input = np.array([0.665,-0.28,-2.285,-0.53,2.021,1.803,-2.953])
Phi = np.array([2.051, 0.506,-1.941,-0.641,1.308,0.702, 4.707-3*np.pi])
Dephasage = Phi-Phi_input

Amplitude_input =  np.array([0.496,0.497,0.496,0.497,0.501,0.516,0.603])
Amplitude =  np.array([0.149, 0.587,0.784, 0.83,0.644,0.41,0.103])


y = 20 * np.log10(Amplitude / Amplitude_input)
x = np.log10(freq)

fig, ax = plt.subplots(2, 1)

ax[0].scatter(x, y, label="-20*log(T)")
ax[0].set_ylabel("-20 * log(T)")
ax[1].scatter(x, Dephasage, label="Phi")
ax[1].set_ylabel("phi")
ax[1].set_xlabel("log(f)")


plt.show()


## Nyquist


x = Amplitude/Amplitude_input*np.sin(Dephasage)
y = Amplitude/Amplitude_input*np.cos(Dephasage)

figure_2 = plt.figure()
plt.plot(x, y)
plt.grid()
plt.show()



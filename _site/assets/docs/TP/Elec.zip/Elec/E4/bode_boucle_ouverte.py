import numpy as np
import matplotlib.pyplot as plt


f = np.array([1, 10, 100, 1000, 2000])  # en Hz
u1 = np.array([500.5, 500.5, 500.5, 2010, 4008])  # en m!V
u2 = np.array([2.4, 2.4, 2.3, 3.9, 3.90])  # en m
phi = np.array([-12, -13, -26, -70, -73])  # en degrées

x = np.log10(f)
y = -20 * np.log10(u1 / u2)


fig, ax = plt.subplots(2, 1)

ax[0].scatter(x, y, label="-20*log(T)")
ax[0].set_ylabel("-20 * log(T)")
ax[1].scatter(x, phi, label="Phi")
ax[1].set_ylabel("phi")
ax[1].set_xlabel("log(f)")


plt.show()

# err_u1 = np.array([0.05,
# err_u2 = np.array([0.05,
# err_phi = np.array([1,

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp

DAU.init_umath()

# Reading data
file_path = "data_rlc.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

t = df["t"]
t_err = df["t_err"]
ut = DAU.np2unp(t, t_err)

fmax = 50e3  # en Hz
fmin = 10  # en Hz
dt = 5  # en s

pas = (fmax - fmin) / dt

uf = ut * pas

f, f_err = DAU.unp2np(uf)


R_int = 0.67 + 50
R = df["R_mes"] + R_int
R_err = df["R_err"]
uR = DAU.np2unp(R, R_err)

L = 2.778e-3
L_err = 0.001e-3
uL = DAU.np2unp(L, L_err)

C = 47.21e-9
C_err = 0.01e-9
uC = DAU.np2unp(C, C_err)


uQ = (1 / uR) * unp.sqrt(uL / uC)
Q = (1 / R) * np.sqrt(L / C)
print(uQ)

omega = 2 * np.pi * uf
print(f"resonance {uf}")
omega_0 = 1 / unp.sqrt(uL * uC)
print(f"propre {omega_0/(2*np.pi)}")


ux = 1 / uQ**2

uo = omega**2
uoo = omega_0**2

x, xerr = DAU.unp2np(ux)
y, yerr = DAU.unp2np(uo / uoo)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$1/Q^2$", "$(\Omega/\Omega_0)^2$")

# Performing regression with uncertainties and plotting raw data

results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

truc = results_fit["a"] / results_fit["b"]

print(truc)


# Adding legend and displaying the plot
ax.legend()
plt.show()

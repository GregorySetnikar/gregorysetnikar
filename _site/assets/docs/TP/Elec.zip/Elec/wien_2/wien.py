################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp
import uncertainties.umath as um

# Permet l�utilisation des fonctions math�matiques standards sur des tableaux unumpy (par d�faut seulement des scalaires)
DAU.init_umath()


# Function definition for linear fit with Monte Carlo
def exp(x, a, V0, C):
    return V0 * np.exp(a * x) + C


# Reading data
file_path = "data_3.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

print(df)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("x", "y")

# Performing regression with uncertainties and plotting raw data
x = np.array(df["Temps"])
y = np.array(df["Crete"])

DAU.plot(x=x, y=y, ax=ax, label="Data")

result = DAU.monte_carlo_fit(x=x, y=y, ax=ax, func=exp, p0=[81.7, 1, 0.5], xmax=0.013)

""" 
fig2, ax2 = DAU.make_fig("x", "y")
test_y = np.log(y)
DAU.plot(x=x, y=test_y, ax=ax2, label="Data")
reg = DAU.regression(x=x, y=test_y, ax=ax2, xmin=0, xmax=0.045e-3)
"""

R = 1004
Rerr = 1
uR = DAU.np2unp(R, Rerr)

R1 = 1005
R1err = 1
uR1 = DAU.np2unp(R1, R1err)

R2 = 1969
R2err = 1
uR2 = DAU.np2unp(R2, R2err)

R2 = 2011
R2err = 1
uR2 = DAU.np2unp(R2, R2err)

Rprime = 1090
Rprime_err = 1
uRprime = DAU.np2unp(Rprime, Rprime_err)

Rcarte = 1e6

uRprime = (uRprime * Rcarte) / (Rcarte + uRprime)

C = 97.22e-9
Cerr = 0.01e-9
uC = DAU.np2unp(C, Cerr)

Cprime = 98.68e-9
Cprime_err = 0.01e-9
uCprime = DAU.np2unp(Cprime, Cprime_err)

# us = (1 / (uR * uC)) * ((uR2 / (2 * uR1)) - 1)
us = (1 / (2 * uR * uCprime)) * ((uR2 / uR1) - (uR / uRprime) - (uCprime / uC))

print(us)
# Adding legend and displaying the plot
ax.legend()
plt.show()

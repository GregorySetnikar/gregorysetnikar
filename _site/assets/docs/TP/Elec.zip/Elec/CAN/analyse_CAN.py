# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 03:58:19 2025

@author: ens
"""

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres

C = 1e-6
R = 620e3

### Reading data
file_path = "data.csv"  # Replace with the correct file path
df_all, units = DAU.loadfile(file_path)


df = DAU.filter_df(df_all, 'Type', 'Linearite')

E_ref = np.mean(np.array(df['Eref']))
U = np.array(df['U'])
N = np.array(df['N'])

f_horloge = np.mean(np.array(df['f_horloge']))



fig, ax = DAU.make_fig(r"$U$ (V)", r"$N$")
DAU.plot(ax, U, N)
result_fit = DAU.regression(U, N, ax=ax)

PenteAttendue = R*C/E_ref*f_horloge*2
print(result_fit["a"])
print(f'A comparer avec {PenteAttendue}')






plt.show()
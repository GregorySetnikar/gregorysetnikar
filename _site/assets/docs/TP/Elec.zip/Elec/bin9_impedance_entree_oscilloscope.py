# -*- coding: utf-8 -*-
"""
Created on Fri Apr 19 22:54:23 2024

@author: ens
"""

import numpy as np
import matplotlib.pyplot as plt
import PythonLyonUtils as PLU

phase_ref = -0.3*np.pi/180;

freq = np.array([10,9,5,3,2,1])*1e3 # fréquences en Hz
u_freq = np.array([1e-6,1e-6,1e-6,1e-6,1e-6,1e-6]) # incertitude sur la fréquence négligeable (Hz)
phase_1 = np.array([-68,-67,-60.5,-51,-41,-24.2])*np.pi/180 # déphasage R=R_int par rapport à R=0 Ohm  en rad avec environ 75 cm de câble environ
u_phase_1 = np.array([1.5,2.5,0.9,1.5,0.9,1.3])*np.pi/180 # erreur sur le déphasage (rad)
y = np.tan((phase_1-phase_ref))
u_y = (1 + y**2)*u_phase_1

phase_2 = np.array([-74,-71,-68,-61.5,-52.5,-34.5])*np.pi/180 # idem avec 1.65m de câble
u_phase_2 = np.array([3,4,1,1.5,1.2,2])*np.pi/180
y_2 = np.tan((phase_2-phase_ref))
u_y_2 = (1 + y_2**2)*u_phase_2

#a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt = PLU.modele_affine(freq,np.tan((phase_1-phase_ref)),u_freq,u_phase_1,1,0)

a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt = PLU.modele_affine(freq,y,u_freq,u_y,1,0)

R = 851e3; # résistance d'entrée de l'oscilloscope
u_R = 10e3; #erreur sur la résistance d'entrée de l'oscilloscope
C = -a_opt/(np.pi*R) # capacité d'entrée de l'oscilloscope
u_C = C*np.sqrt((u_a_opt/a_opt)**2+(u_R/R)**2) # incertitude sur C

print(f"C {C} /pm {u_C}")

fig = plt.figure()
plt.errorbar(freq,y, xerr=u_freq,yerr=u_y, fmt="o")
plt.plot(freq,a_opt*freq+b_opt)
plt.grid()
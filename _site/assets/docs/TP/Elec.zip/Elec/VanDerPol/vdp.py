################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "vdp.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$R_{NL}$", "$s_{cc}$")

# Performing regression with uncertainties and plotting raw data
x = np.array(df["Rnl"])
s = np.array(df["s"])
y = s**2

results_fit = DAU.regression(x=x, y=y, ax=ax, color="blue")


# Adding legend and displaying the plot
ax.legend()
plt.show()

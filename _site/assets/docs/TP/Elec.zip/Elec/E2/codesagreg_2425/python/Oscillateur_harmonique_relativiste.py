import numpy as np
import matplotlib.pyplot as plt
import scipy.integrate
from math import *

#Ce script trace le portrait de phase
#d'un oscillateur 1D

#On peut également s'en servir pour tracer les solutions
#en fonction du temps

"""
Les lignes que peut changer l'utilisateur sont les suivantes :
    -Le nombre de pas d'integration et le temps final
    -L'équation du mouvement à intégrer, en modifiant la fonction sys
    -La condition initiale, en modifiant y0
    -Le tracé au choix du portrait de phase ou de la solution en fonction du temps, en modifiant le booleen tracer_portrait_phase
"""

#Donnees---------------------------------------

nombre_pas = 2000
t_final = 40
c = 3e8
t = np.linspace(0,t_final,num=nombre_pas)

tracer_portrait_phase = True

#Systeme d'equations a resoudre-----------------

"""
La fonction sys doit renvoyer une liste contenant
la dérivée de x et celle de x'
Pour l'oscillateur harmonique le retour est donc [x',-x]
"""

def sys(y,t):
    x, xprime = y

    #changer la ligne suivante pour un oscillateur different
    #return [xprime, -x] #oscillateur harmonique
    #return [xprime, -x-0.1*xprime] #oscillateur harmonique amorti
    #return [xprime, -np.sin(x)-0.1*xprime] #pendule simple amorti
    #return [xprime, (0.2-x**2)*xprime -x] #oscillateur de Van der Pol
    #return [xprime, -x*(1-xprime**2/c**2)**(3/2)] #oscillateur harmonique relativiste
    return [xprime, -x*(1-xprime**2/c**2)**(3/2)-0.01*xprime] #oscillateur harmonique amorti relativiste

#Liste de conditions initiales-------------------

"""
Les conditions initiales sont sous la forme [x(0),x'(0)]
y0 est un tableau devant contenir autant de conditions
initiales qu'il y a de portraits de phase a tracer
exple : pour 3 courbes y0 = [[10,0],[10,2],[8,5]]
"""

y0 = [[0,0.5*c],[0,0.8*c],[0,0.9*c],[0,0.99*c]]

#Integration par le solveur odeint---------------------------------

sol_0 = (scipy.integrate.odeint(sys,y0[0],t))
sol_1 = (scipy.integrate.odeint(sys,y0[1],t))
sol_2 = (scipy.integrate.odeint(sys,y0[2],t))
sol_3 = (scipy.integrate.odeint(sys,y0[3],t))

# Affichage portrait de phase
plt.figure(1)
plt.plot(sol_0[:,0]/c,sol_0[:,1]/c, label="$v_{max} = 0.5 c$")
plt.plot(sol_1[:,0]/c,sol_1[:,1]/c, label="$v_{max} = 0.8 c$")
plt.plot(sol_2[:,0]/c,sol_2[:,1]/c, label="$v_{max} = 0.9 c$")
plt.plot(sol_3[:,0]/c,sol_3[:,1]/c, label="$v_{max} = 0.99 c$")

plt.xlabel("$ x \omega_0 /c$", fontsize=30)
plt.ylabel("$v/c$", fontsize=30)
plt.axis('equal')
plt.grid()
plt.legend(fontsize=20,loc='upper right')
plt.title("Portrait de phase", fontsize=30)



plt.show()

# Affichage trajectoire
plt.figure(2)

plt.plot(t,sol_0[:,0]/c, label="$v_{max} = 0.5 c$")
plt.plot(t,sol_1[:,0]/c, label="$v_{max} = 0.8 c$")
plt.plot(t,sol_2[:,0]/c, label="$v_{max} = 0.9 c$")
plt.plot(t,sol_3[:,0]/c, label="$v_{max} = 0.99 c$")

plt.ylabel("$ x \omega_0 /c$", fontsize=30)
plt.xlabel("$\omega_0 t$", fontsize=30)
plt.grid()
plt.legend(fontsize=20,loc='upper right')
plt.title("Trajectoires", fontsize=30)


plt.show()

# Affichage vitesse
plt.figure(3)

plt.plot(t,sol_0[:,1]/c, label="$v_{max} = 0.5 c$")
plt.plot(t,sol_1[:,1]/c, label="$v_{max} = 0.8 c$")
plt.plot(t,sol_2[:,1]/c, label="$v_{max} = 0.9 c$")
plt.plot(t,sol_3[:,1]/c, label="$v_{max} = 0.99 c$")

plt.ylabel("$ v /c$", fontsize=30)
plt.xlabel("$\omega_0 t$", fontsize=30)
plt.grid()
plt.legend(fontsize=20,loc='upper right')
plt.title("Vitesses", fontsize=30)



plt.show()

# Etude spectrale
# attention c'est sûrement foireux

def fourier(t, signal):
    N, dt = len(t), t[1]-t[0] #Nombre de point et intervalle de temps
    signal = signal - np.mean(signal) #on centre le signal, ce qui enlève un point de fréquence nulle
    sp = np.fft.fft(signal) #on calcule la fft
    mod = np.sqrt(sp.real**2 + sp.imag**2)[0:int(N/2)] # on en prend le module
    freq = np.fft.fftfreq(N, d=dt)[0:int(N/2)] #on associe les coordonnées à un fréquence
    return freq, mod


plt.figure(4)

xf_0, yf_0 = fourier(t, sol_0[:,0])
xf_1, yf_1 = fourier(t, sol_1[:,0])
xf_2, yf_2 = fourier(t, sol_2[:,0])
xf_3, yf_3 = fourier(t, sol_3[:,0])

plt.plot(2*np.pi*xf_0, yf_0/np.max(yf_0), label="$v_{max} = 0.5 c$")
plt.plot(2*np.pi*xf_1, yf_1/np.max(yf_1), label="$v_{max} = 0.8 c$")
plt.plot(2*np.pi*xf_2, yf_2/np.max(yf_2), label="$v_{max} = 0.9 c$")
plt.plot(2*np.pi*xf_3, yf_3/np.max(yf_3), label="$v_{max} = 0.99 c$")

plt.ylabel("$ Spectre $", fontsize=30)
plt.xlabel("$ f/\omega_0 $", fontsize=30)
plt.grid()
plt.legend(fontsize=20,loc='upper right')
plt.title("Transformée de Fourier", fontsize=30)
#plt.xlim([0,2])

plt.show()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Tracé de la courbe de Delta_r G en fonction de l'avancement pour quelques réactions. On pourra changer les conditions
experimentales. Réactions concernées : synthèse de l'ammoniac, précipitation de l'iodure de plomb
On pourra aussi adapter le code pour illustrer d'autres réactions.

Dépendances:

Usage: python python_EquilibreChimique_lyon.py

Auteurs: F. Pagaud & G. Legrand (21/04/2020)
         Révisions apportées par les agrégatifs de Lyon 2022-2023
"""

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})


# -----------------------------------------
# Constantes, donnees tabulees et conditions experimentales
# -----------------------------------------

R = 8.314 # constante des gaz parfaits (J/K/mol)
T = 300 # temperature (K)

p_o = 10**5 # pression standard (Pa)
p = 10**5 # pression (Pa)

c_o = 1 # concentration standard (mol/L)
n_o = 0.001  # quantite de matiere init de Pb (mol)


def Delta_rG0_a(T) :
    '''Enthalpie libre standard de reaction pour la synthese de l'ammoniac'''
    Delta_rH_a = -37840
    Delta_rS_a = -(65000-13675)/300
    return Delta_rH_a - T*Delta_rS_a

def Delta_rG0_pb(T) :
    '''Enthalpie libre standard de reaction pour la precicpitation de l'iodure de plomb'''
    Delta_rH_pb = 56000         
    Delta_rS_pb = 48
    return Delta_rH_pb - T*Delta_rS_pb
    
## Avancement normalise a sa valeur maximale
step = 0.001
x = np.arange(0, 1.00, step)

def Delta_rG_a(T,p) :
    '''Enthalpie libre de reaction pour la synthese de l'ammoniac'''
    Delta_rG_o = Delta_rG0_a(T)
    Delta_rG = Delta_rG_o + R*T*np.log((2*x)**2/((1-x)*(3*(1-x))**3) * (p_o/p)**2)
    return Delta_rG
    
def Delta_rG_pb(T,p) :
    '''Enthalpie libre de reaction pour la precicpitation de l'iodure de plomb'''
    Delta_rG_o = Delta_rG0_pb(T)
    Delta_rG = Delta_rG_o + R*T*np.log( n_o*x*(n_o*2*x)**2/(c_o**3) )      
    return Delta_rG
    
# Programme principal
if __name__ == "__main__":

    # -----------------------------------------
    # Premiere reaction: Synthese de l'ammoniac
    # -----------------------------------------

    # Calcul de l'enthalpie libre du systeme en fonction de x
    Delta_rG = Delta_rG_a(T,p)
    G = [0]
    for i in range (1, len(x)) :
        G.append(G[i-1]+Delta_rG[i]*step/1000)

    # trace de la figure
    fig=plt.figure("Enthalpie standard de reaction en fonction de l'avancement")

    plt.clf()

    ax1 = plt.axes([0.15, 0.22, 0.35, 0.7])
    ax2 = plt.axes([0.58, 0.22, 0.35, 0.7])

    # sliders pour changer la valeur de P et T
    axP = plt.axes([0.12, 0.02, 0.78, 0.03])	
    axT = plt.axes([0.12, 0.06, 0.78, 0.03])	
    sP = Slider(axP, 'P [bar]', 0.2, 10, valinit=p/10**5, valfmt='%0.2f')
    sT = Slider(axT, 'T [K]', 100, 1000, valinit=T, valfmt='%0.f')


    def update(val):
        ''' Mise a jour de la figure a partir des nouvelles valeurs de T et P '''
        T = sT.val
        P = sP.val*10**5
        
        y2 = Delta_rG_a(T, P) # nouvelle enthalpie libre de reaction
        
        y1 = [0] # calcul de la nouvelle enthalpie libre du systeme
        for i in range (1, len(y2)) :
            y1.append(y1[i-1]+y2[i]*step/1000)
        
        ind = np.argwhere(np.abs(y2/1000) < min(np.abs(y2/1000))+0.0001)[0,0]
        ptx = x[ind]
        
        l1.set_ydata(y1)
        l2.set_ydata(y2/1000)
        p1.set_xdata(ptx)
        p1.set_ydata(y1[ind])
        p2.set_xdata(ptx)
        fig.canvas.draw_idle()
        
    # mise a jour
    sT.on_changed(update)
    sP.on_changed(update)


    # mise en forme de la figure
    plt.title('$\mathrm{N_{2(g)} + 3H_{2(g)} = 2NH_{3(g)}}$', fontsize = 28)
    ax1.set_xlabel(r'$x=\xi/\xi_{max}$', fontsize = 26)
    ax1.set_ylabel('$G$ [kJ]', fontsize = 26)
    ax1.set_ylim(-15, 20)

    ax2.set_xlabel(r'$x=\xi/\xi_{max}$', fontsize = 26)
    ax2.set_ylabel('$\Delta_rG$  [kJ/mol]', fontsize = 26)

    l1, = ax1.plot(x, G, '-r', lw = 4)
    ax2.plot([0, 1], [0, 0], '-k', lw=1)
    l2, = ax2.plot(x, Delta_rG/1000, '-r', lw = 4)

    # reperage du point d'equilibre
    ind = np.argwhere(np.abs(Delta_rG/1000) < min(np.abs(Delta_rG/1000))+0.0001)[0,0]
    ptx = x[ind]
    p1, = ax1.plot(ptx, G[ind], 'o', color = 'orange', markersize = 15, zorder=5)
    p2, = ax2.plot(ptx, 0, 'o', color = 'orange', markersize = 15, zorder=5)

    ax1.grid()
    ax2.grid()

    mng = plt.get_current_fig_manager()
    mng.window.showMaximized()
    plt.show()


    # -----------------------------------------
    # Premiere reaction: dissolution iodure de plomb
    # -----------------------------------------

    # Calcul de l'enthalpie libre du systeme en fonction de x
    Delta_rG = Delta_rG_pb(T,p)
    G = [0]
    for i in range (1, len(x)) :
        G.append(G[i-1]+Delta_rG[i]*step/1000)

    # trace de la figure
    fig=plt.figure("Enthalpie standard de reaction en fonction de l'avancement")

    plt.clf()

    ax1 = plt.axes([0.15, 0.22, 0.35, 0.7])
    ax2 = plt.axes([0.58, 0.22, 0.35, 0.7])

    # sliders pour changer la valeur de P et T
    axP = plt.axes([0.12, 0.02, 0.78, 0.03])	
    axT = plt.axes([0.12, 0.06, 0.78, 0.03])	
    sP = Slider(axP, 'P [bar]', 0.2, 10, valinit=p/10**5, valfmt='%0.2f')
    sT = Slider(axT, 'T [K]', 100, 1000, valinit=T, valfmt='%0.f')


    def update(val):
        ''' Mise a jour de la figure a partir des nouvelles valeurs de T et P '''
        T = sT.val
        P = sP.val*10**5
        
        y2 = Delta_rG_pb(T, P) # nouvelle enthalpie libre de reaction
        
        y1 = [0] # calcul de la nouvelle enthalpie libre du systeme
        for i in range (1, len(y2)) :
            y1.append(y1[i-1]+y2[i]*step/1000)
        
        ind = np.argwhere(np.abs(y2/1000) < min(np.abs(y2/1000))+0.0001)[0,0]
        ptx = x[ind]
        
        l1.set_ydata(y1)
        l2.set_ydata(y2/1000)
        p1.set_xdata(ptx)
        p1.set_ydata(y1[ind])
        p2.set_xdata(ptx)
        fig.canvas.draw_idle()
        
    # mise a jour
    sT.on_changed(update)
    sP.on_changed(update)


    # mise en forme de la figure
    plt.title('$\mathrm{Pb^{2+}_{(aq)} + 2 I^{-}_{(aq)} = PbI_{2(s)}}$', fontsize = 28)
    ax1.set_xlabel(r'$x=\xi/\xi_{max}$', fontsize = 26)
    ax1.set_ylabel('$G$ [kJ]', fontsize = 26)
    ax1.set_ylim(-15, 20)

    ax2.set_xlabel(r'$x=\xi/\xi_{max}$', fontsize = 26)
    ax2.set_ylabel('$\Delta_rG$  [kJ/mol]', fontsize = 26)
    ax2.set_ylim(-60, 40)

    l1, = ax1.plot(x, G, '-r', lw = 4)
    ax2.plot([0, 1], [0, 0], '-k', lw=1)
    l2, = ax2.plot(x, Delta_rG/1000, '-r', lw = 4)

    # reperage du point d'equilibre
    ind = np.argwhere(np.abs(Delta_rG/1000) < min(np.abs(Delta_rG/1000))+0.0001)[0,0]
    ptx = x[ind]
    p1, = ax1.plot(ptx, G[ind], 'o', color = 'orange', markersize = 15, zorder=5)
    p2, = ax2.plot(ptx, 0, 'o', color = 'orange', markersize = 15, zorder=5)

    ax1.grid()
    ax2.grid()

    mng = plt.get_current_fig_manager()
    mng.window.showMaximized()
    plt.show()

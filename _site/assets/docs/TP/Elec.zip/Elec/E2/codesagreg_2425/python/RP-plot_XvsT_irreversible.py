#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lien entre avancement et température dans un RP pour différents temps de passage

pour une réaction A-> P et une réaction d'ordre 1 par rapport à chacun des réactifs, dans un RP, la réaction étant irréversible


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""



# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.constants as sc
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def xRP(tau,A,Ea,T):
    ktau = tau*A*np.exp(-Ea/(sc.R*T))
    return 1-np.exp(-ktau)

def xRPAC(tau,A,Ea,T):
    ktau = tau*A*np.exp(-Ea/(sc.R*T))
    return ktau/(1+ktau)


if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RP-XvsT.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(0,1,1000)
    T =np.linspace(200,500,1000)
    A = 3e7
    Ea = 40e3

    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0])
    #plot a vertical line at zero to give a hint on where it lies
    ax1.axhline(1,color='#cccccc')
    colors = ['#c51b7d','#e9a3c9','#41ab5d','#005a32']
    ls=[':','--','-','-.',(0, (3, 1, 1, 1, 1, 1))]
    #temps de passages
    liste = [1e-2,1,1e2,300]
    for i,el in enumerate(liste) :
        ax1.plot(T,xRP(el,A,Ea,T), color = colors[i],ls=ls[i] ,label='$\\tau = {}$'.format(el))
    #on trace la courbe pour un RPAC à titre de comparaison
    ax1.plot(T,xRPAC(1,A,Ea,T), color = colors[1],ls=ls[1],alpha=0.5 )


    ax1.legend(loc='lower right')
    #labels for the axis and title of the graph
    ax1.set_xlabel('$T$')
    ax1.set_ylabel('$X_\mathrm{A}$')
    #set limits to the plotted data (to crop for example)
    ax1.set_xlim(min(T),max(T))
    #show or hide the bounding axes
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


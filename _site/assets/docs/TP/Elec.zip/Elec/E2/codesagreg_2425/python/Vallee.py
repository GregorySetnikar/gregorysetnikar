#!/usr/bin/env python3
# -*- coding: utf-8 -*-

''' Ce code affiche la vallée de stabilité des différents isotopes de chaques atomes
ainsi que l'ajustement non-linéaire lié à cette vallée '''

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import math
import matplotlib
import scipy.optimize as spo
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})

##Donnees

aju = True         #Booleen permettant d'activer l'affichage ou non de l'asjustement


N = np.array([0, 1, 1, 2, 3, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 10, 10, 10, 11, 12, 12, 12, 13, 14, 14, 14, 15, 16, 16, 16, 17, 18, 20, 18, 20, 18, 20, 22, 20, 22, 20, 22, 23, 24, 26, 28, 24, 24, 25, 26, 27, 28, 27, 28, 26, 28, 29, 30, 30, 28, 30, 31, 32, 32, 30, 32, 33, 34, 36, 34, 36, 34, 36, 37, 38, 40, 38, 40, 38, 40, 41, 42, 44, 42, 40, 42, 43, 44, 46, 48, 44, 46, 42, 44, 46, 48, 50, 48, 46, 48, 49, 50, 50, 50, 51, 52, 54, 56, 52, 50, 52, 53, 54, 55, 56, 58, 52, 54, 55, 56, 57, 58, 60, 58, 56, 58, 59, 60, 62, 64, 60, 62, 58, 60, 62, 63, 64, 66, 68, 64, 62, 64, 65, 66, 67, 68, 69, 70, 72, 74, 70, 72, 68, 70, 71, 72, 73, 74, 76, 78, 74, 70, 72, 74, 75, 76, 77, 78, 80, 82, 78, 74, 76, 78, 79, 80, 81, 82, 82, 78, 80, 82 ,84, 82, 82, 83, 84, 85, 86, 88, 90, 82, 86, 87, 88, 90, 92, 88, 90, 88, 90, 91, 92, 93, 94, 96, 94, 90, 92, 94, 95, 96, 97, 98, 98, 94, 96, 98, 99, 100, 102, 100, 98, 100, 101, 102, 103, 104, 106, 104, 102, 104, 105, 106, 107, 108, 107, 108, 106, 108, 109, 110, 112, 110, 108, 110, 111, 112, 113, 114, 116, 114, 116, 114, 116, 117, 118, 120, 118, 116, 118, 119, 120, 121, 122, 124, 122, 124, 122, 124, 125, 126])        #neutrons des isotopes stable
Z = np.array([1, 1, 2, 2, 3, 3, 4, 5, 5, 6, 6, 7, 7, 8, 8, 8, 9, 10, 10, 10, 11, 12, 12, 12, 13, 14, 14, 14, 15, 16, 16, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20 ,20, 20, 20, 20, 20, 21 ,22, 22, 22, 22, 22, 23, 23, 24, 24, 24, 24, 25, 26, 26, 26, 26, 27, 28, 28, 28, 28, 28, 29, 29, 30, 30, 30, 30, 30, 31, 31,32, 32, 32, 32, 32, 33, 34, 34, 34, 34 ,34, 34, 35, 35, 36, 36, 36, 36, 36, 37, 38, 38, 38, 38, 39, 40, 40, 40, 40, 40, 41, 42, 42, 42, 42, 42, 42, 42, 44, 44, 44, 44, 44, 44, 44, 45, 46, 46, 46, 46, 46, 46, 47, 47, 48, 48, 48, 48, 48, 48, 48, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 51, 51, 52, 52, 52, 52, 52, 52, 52, 52, 53, 54, 54, 54, 54, 54, 54, 54,54 ,54, 55, 56, 56, 56, 56, 56, 56, 56, 57, 58, 58, 58, 58, 59, 60, 60, 60 ,60, 60, 60, 60, 62, 62, 62, 62, 62, 62, 63, 63, 64, 64, 64, 64, 64, 64, 64, 65, 66, 66, 66, 66, 66, 66, 66, 67, 68, 68, 68, 68, 68, 68, 69, 70, 70, 70, 70, 70 ,70, 70, 71, 72, 72, 72, 72, 72, 72, 73, 73, 74, 74, 74, 74, 74, 75, 76, 76, 76, 76, 76, 76, 76, 77, 77, 78, 78, 78, 78, 78, 79, 80, 80, 80, 80, 80, 80, 80, 81, 81, 82, 82, 82, 82])        #protons ---
A = N + Z


##L'ajustement

#fonction f realisant le fit. ici : une droite
def f(x,p) :
    (a,b) = p
    res = a*x**(2/3)+b
    fit = '$ax^{2/3}+b$'
    return (res,fit)

#derivee de la fonction f
def Dx_f(x,p) :
    (a,b) = p
    return 2/3*a*x**(-1/3)

#fonction d'ecart des donnees a l'ajustement
def residual(p, y, x) :
    return(y-f(x,p)[0])/np.sqrt(uy**2 + (Dx_f(x,p)*ux)**2)
    

def affichage(a, ua, k=2) :
    """Prend en arguments deux nombres et retourne deux str en ecriture scientifique a la meme puissance.
    k est le facteur de Student, vaut 2 par defaut"""
    
    dec_a = int(np.floor(np.log10(np.abs(a))))
    dec_ua = int(np.floor(np.log10(k*ua)))
    diff = int(np.abs(dec_a-dec_ua))
    
    if diff != 0 :
        if dec_a != 0 :
            str_tot = "({}$\pm${})".format(round(a*10**(-dec_a), diff), round(k*ua*10**(-dec_a),diff)) + "$\cdot 10^{"+str(dec_a)+"}$"
        else :
            str_tot = "{}$\pm${}".format(round(a*10**(-dec_a), diff), round(k*ua*10**(-dec_a),diff))
    else :
        if dec_a != 0 :
            str_tot = "({}$\pm${})".format(int(a*10**(-dec_a)), int(k*ua*10**(-dec_a))) + "$\cdot 10^{"+str(dec_a)+"}$"
        else :
            str_tot = "{}$\pm${}".format(int(a*10**(-dec_a)), int(k*ua*10**(-dec_a)))
    
    return str_tot

color_data = ['r', 'b', 'g', 'y']
color_fit = ['orange', 'c', (0.2, 0.8, 0.5), (0.5, 0.5, 0.1)]
mark = ['o', 's', '>','<']
ref = "Mesure"
k = 2   #definition du facteur k (coeff de Student)





x = A
y = A/Z
p0 = [0,0]
uy = np.array(len(A)*[1])
ux = np.array(len(A)*[1])

result = spo.leastsq(residual, p0, args = (y,x), full_output = False)
popt = result[0]	#parametres optimaux d'ajustement
pcov = result[1]	#Matrice des covariances

#str_a = affichage(popt[0], upopt[0])
#str_b = affichage(popt[1], upopt[1])

xrange = np.arange(0, A[-1]+10, 0.1)
(yrange,lab_fit) = f(xrange, popt)
y_trace = yrange**(-1)*xrange

##Le trace

plt.figure('Vallée de stabilité')
plt.clf()
plt.plot([0, A[-1]+10], [0, (A[-1]+10)/2], '--k', label = 'Z = N', linewidth = 3)
plt.scatter(A, Z, s = 20, marker = 's', c='r', label = 'Isotopes stables')
if aju :
    plt.plot(xrange, y_trace, '-b', linewidth = 3, zorder = 0, label = 'y='+lab_fit+', a = ' + str(round(popt[0], 4)) + ' ; b = ' + str(round(popt[1], 2)) )
plt.xlim([0, A[-1]+10])
plt.ylim([0, Z[-1]+10])
plt.grid()

plt.xlabel('Nombre de nucléons', fontsize = 28)
plt.ylabel('Nombre de protons', fontsize = 28)
plt.legend(loc = 2, framealpha = 0.5)


##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

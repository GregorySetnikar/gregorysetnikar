#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Illustration de la dynamique d'une particule libre: à l'instant initial, la fonction d'onde correspond à un paquet d'ondes
gaussien. L'évolution de l'enveloppe ainsi que de la partie réelle sont ensuite présentées en exploitant le développement
limité de la relation de dispersion k(\omega) soit à l'ordre 1, soit à l'ordre 2.
Ref. "Physique quantique", M. Le Bellac (2003)

Entrées :
    - sigma0 : étalement du paquet d'onde gaussien initial
    - k : nombre d'onde
    - omega : fréquence associée à la dynamique

Dépendances:

Usage: python_Evolution_Paquet_Ondes_gaussien_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Definition des fonctions
def paquetdonde_DL1(t):
    """ Evolution d'un paquet d'onde avec le DL à l'ordre 1 """
    phi = 1/pow(2*np.pi*sigma0**2,1./4.)/np.sqrt(sigma0**2)*k  \
        * np.exp( 1j * k * positions -1./(2.*sigma0**2)*(k*positions-omega*t)**2)
    return phi

def paquetdonde_DL2(t):
    """ Evolution d'un paquet d'onde avec le DL à l'ordre 2 """
    phi = 1/pow(2*np.pi*sigma0**2,1./4.)/np.sqrt(sigma0**2 + 2j*omega*t)*k  \
        * np.exp( 1j * k * positions -1./(2.*sigma0**2 + 2j*omega*t)*(k*positions-omega*t)**2)
    return phi

def init():
    """ Initialisation de l'animation """
    ax.set_ylim(ymin, ymax)
    ax.set_xlim(xmin, xmax)
    nframe = 0
    line.set_data(positions, np.real(paquetdonde(t)))
    line2.set_data(positions, np.abs(paquetdonde(t)))
    line3.set_data(positions, -np.abs(paquetdonde(t)))
    return line,line2,line3,

def update(nframe):
    """ Mise à jour de l'animation """
    t = times[nframe]
    nframe = nframe + 1
    line.set_data(positions, np.real(paquetdonde(t)))
    line2.set_data(positions, np.abs(paquetdonde(t)))
    line3.set_data(positions, -np.abs(paquetdonde(t)))
    return line,line2,line3

# Programme principal
if __name__ == "__main__":
   # Choix entre DL1 et DL2
   if True:
      ordre_DL = 1
   else:
      ordre_DL = 2
   # Parametres
   sigma0 = 3  # étalement du paquet d'onde gaussien à l'instant initial
   k = 1       # nombre d'onde (doit être non nul)
   omega = 0.5 # fréquence associée à la dynamique

   tmax = 30/omega # temps à la fin de l'animation
   sigmamax = np.sqrt(sigma0**2+(2*omega*tmax/sigma0)**2)
   xmin = min(tmax*omega/k-2*sigmamax/k,-2*sigma0/k) # abscisse minimale sur le graphe
   xmax = 2*sigmamax/k+tmax*omega/k                  # abscisse maximale sur le graphe
   nframes = 100 # nombres d'images

   positions = np.linspace(xmin,xmax,500) # tableau des positions
   times = np.linspace(0,tmax,nframes) # tableau des temps

   t = 0
   if ordre_DL == 1:
      paquetdonde = paquetdonde_DL1
   elif ordre_DL == 2:
      paquetdonde = paquetdonde_DL2
   else:
      sys.exit('Not implemented')
   phi = paquetdonde(t)
   ymax = np.max(np.abs(phi)+0.05)
   ymin = -ymax

   fig, ax = plt.subplots()
   line, = ax.plot([], [], 'b', lw=2)
   line2, = ax.plot([], [], 'g', lw=1)
   line3, = ax.plot([], [], 'g', lw=1)
   plt.legend(["Paquet d'onde", "Enveloppe"])

   ani = animation.FuncAnimation(fig, update, nframes,
        interval=20, blit=False, init_func=init)

   plt.xlabel(r'$x[a.u.]$')
   plt.ylabel(r'$\psi[a.u.]$')
   plt.show()


   
   




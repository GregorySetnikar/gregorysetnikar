#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Proportion d'énergie à fournir pour maintenir un fonctionnement isotherme dans un réacteur piston pour une réaction d'ordre 2.


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def avancement(k,C0,V,Q):
    return k*V*C0/(Q+k*V*C0)


def VpourX(Q,k,C0,X):
    return Q/(k*C0)*(X/(1-X))


# Programme principal
if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RP-evolX.svg"
    #Range of values where the data will be evaluated
    Vtot = 1.506e-2
    V =np.linspace(0,Vtot,1000)
    X =np.linspace(0.1,0.9,9)
    k = 1.4e-4
    Q = 1/3600
    C0 = 2500


    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0])
    #plot a vertical line at zero to give a hint on where it lies
    ax1.axhline(0,color='#cccccc')
    colors = ['#e66101','#fdb863','#4d4d4d','#b2abd2','#5e3c99']
    ls=[':','--','-','-.',(0, (3, 1, 1, 1, 1, 1))]
    ax1.plot(V/Vtot,avancement(k,C0,V,Q), color = colors[0],ls=ls[0])
    #calcul du volume nécessaire pour avoir un taux de conversion donné
    inverseV = VpourX(Q,k,C0,X)/Vtot
    ax1.plot(inverseV,X,ls='',ms=3,marker='o')
    #ajout des valeurs numériques sous forme textuelle
    for i,valX in enumerate(X):
        plt.annotate("{:.3f}".format(inverseV[i]).replace(".",","), (inverseV[i]+0.01, valX-0.02))
        
    #labels for the axis and title of the graph
    ax1.set_xlabel('$V/V_\\mathrm{total}$')
    ax1.set_ylabel('$X_\\mathrm{A}$')
    #set limits to the plotted data (to crop for example)
    ax1.set_ylim(0,1.1)
    ax1.set_xlim(0,1)
    #show or hide the bounding axes
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


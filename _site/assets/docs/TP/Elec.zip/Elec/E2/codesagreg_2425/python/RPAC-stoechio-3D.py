#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Influence du rapport stoechiométrique M sur le temps de passage nécessaire pour avoir un taux de conversion donné.

pour une réaction A+B -> P avec nB=M*nA et une réaction d'ordre 1 par rapport à chacun des réactifs

Tracé tridimensionnel en (X,M)

Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""
# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as tick
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import LinearLocator, FixedLocator, FormatStrFormatter

from matplotlib import cm
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def rapportTauMtau1(x,m):
    return (1-x)/(m-x) 

# Programme principal
if __name__ == "__main__":
    #Name of the output file
    fileOutput = "rapport_tau_stoechio.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(1e-3,1-1e-3,100)
    m =np.linspace(1,20,100)
    xx,mm = np.meshgrid(x, m, indexing='ij')
    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)#,  width_ratios=(1, 1), height_ratios=(2, 1), left=0.08, right=0.95, bottom=0.05, top=0.95, wspace=0.18, hspace=0.3
    ax1 = fig.add_subplot(gs[0,0],projection='3d', proj_type='ortho')
    ax1.plot_surface(xx,mm,rapportTauMtau1(xx,mm),cmap=cm.viridis)

    #labels for the axis and title of the graph
    ax1.set_xlabel('$x$')
    ax1.set_ylabel('$M$')
    ax1.set_zlabel('$\dfrac{\\tau_{M}}{\\tau_{1}}$')
    plt.savefig(fileOutput)
    plt.show()


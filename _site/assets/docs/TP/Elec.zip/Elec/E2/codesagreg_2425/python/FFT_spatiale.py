import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.widgets import Slider, Button
import matplotlib
from matplotlib import patches

"""
fft_spatiale

Ce code permet d'afficher une grille de pas variables dans les deux dimensions et affiche sa transformée de Fourier spatiale en parallèle.
"""


# Définition des paramètres de la figure
matplotlib.rc('xtick', labelsize=18)
matplotlib.rc('ytick', labelsize=18)
matplotlib.rcParams.update({'font.size': 18})

# Définition de la taille de la grille
N = 256
x = np.linspace(0, N, N)
X, Y = np.meshgrid(x, x)

# Définition de la fonction pour générer la grille
def grille(x,y,a,b):
    h = 6 # épaisseur de la grille
    if np.floor(x%a)<h or np.floor(y%b)<h:
        return 0
    else:
        return 1

# Vectorisation de la fonction pour permettre son utilisation avec numpy
grille = np.vectorize(grille)

# Création de la figure et des sous-graphiques
fig = plt.figure(figsize = (20,10))
plt.subplots_adjust(bottom=0.20)
ax1 = plt.subplot(121)
ax2 = plt.subplot(122)
plt.set_cmap('gray')

# Paramètres initiaux pour la grille
a = 10
b = 10

# Calcul de la FFT 2D de la grille initiale
image = grille(X,Y,a,b)
ft = np.fft.ifftshift(image)
ft = np.fft.fft2(ft)
ft = np.fft.fftshift(ft)

# Tracé du sous-graphique ax1 avec la grille initiale
ax1.pcolormesh(X, Y, image)
ax1.set_xlabel('$x$')
ax1.set_ylabel('$y$')

# Tracé du sous-graphique ax2 avec la FFT de la grille initiale
ax2.imshow(np.sqrt(abs(ft)),extent=[-1/2,1/2,-1/2,1/2])
ax2.set_xlim(-1/8,1/8)
ax2.set_ylim(-1/8,1/8)
ax2.set_xlabel('$k_x$')
ax2.set_ylabel('$k_y$')

# Création des sliders pour les paramètres de la grille
slider_a = plt.axes([0.15, 0.105, 0.25, 0.03])
slider_b = plt.axes([0.15, 0.075, 0.25, 0.03])
s_a = Slider(slider_a, '$a_x$', 1, 50, valinit=10, valfmt='%0.1f')
s_b = Slider(slider_b, '$a_y$', 1, 50, valinit=10, valfmt='%0.2f')

# Fonction de mise à jour des graphiques en fonction des valeurs des sliders
def update(val):
    ax1.clear()
    ax2.clear()
    a = s_a.val
    b = s_b.val

    # Calcul de la grille mise à jour
    image = grille(X,Y,a,b)
    ft = np.fft.ifftshift(image)
    ft = np.fft.fft2(ft)
    ft = np.fft.fftshift(ft)

    # Tracé du sous-graphique ax1 avec la grille mise à jour
    ax1.pcolormesh(X, Y, image)
    ax1.set_xlabel('$x$')
    ax1.set_ylabel('$y$')
    # Tracé du sous-graphique ax2 avec la FFT de la grille mise à jour
    ax2.imshow(np.sqrt(abs(ft)),extent=[-1/2,1/2,-1/2,1/2])
    ax2.set_xlim(-1/8,1/8)
    ax2.set_ylim(-1/8,1/8)
    ax2.set_xlabel('$k_x$')
    ax2.set_ylabel('$k_y$')

# Mise à jour des graphiques lorsque les sliders sont modifiés
s_a.on_changed(update)
s_b.on_changed(update)

# Création du bouton de réinitialisation des sliders
reset_button_ax = plt.axes([0.8, 0.025, 0.1, 0.04])
reset_button = Button(reset_button_ax, 'Réinitialiser', hovercolor='0.975')
def reset(event):
    s_a.reset()
    s_b.reset()
reset_button.on_clicked(reset)

plt.show()


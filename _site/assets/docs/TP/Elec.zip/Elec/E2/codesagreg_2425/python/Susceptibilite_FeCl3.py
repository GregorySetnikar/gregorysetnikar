#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Détermination de la susceptibilité paramagnétique d'une solution de FeCl3 par la méthode de Quincke. Le protocole est détaillé
dans la Ref. "Physique expérimentale, Optique, magnétisme, électrotechnique, mécanique, thermodynamique et physique non
linéaire", Jolidon (2021).

Dépendances:

Usage: python python_Susceptibilite_FeCl3_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import numpy.polynomial as pnl
import matplotlib.pyplot as plt
import scipy.optimize as scopt


# Definition des fonctions
def etalonnage_electroaimant(X,Y,u_X,u_Y):
   """
   Effectue une modélisation polynomiale d'ordre 3 "Y = a + b*X + c*X^2 + d*X^3", en tenant compte(*) des incertitudes sur
   X (u_X) et Y (u_Y).
   La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai obtenus à l'aide de numpy.polyfit
   La fonction renvoie une liste qui contient dans l'ordre : 
       - les valeurs des coefficients optimisés (coeff_opt) [avec la convention coeff_opt = (a_opt, b_opt, c_opt, d_opt)]
       - les incertitudes sur ces valeurs (u_coeff_opt)
       - la valeur du chi2 réduit (chi2_opt).
   (*) ATTENTION: en l'état, l'incertitude sur X n'est pas prise en compte!
   """
   def polynome(x,coeff):
      return pnl.polynomial.polyval(x,coeff)

   def residu(coeff,x,y,u_x,u_y):
      return (y-polynome(x,coeff)) / np.abs(u_y)

   # Guess initial
   first_guess = pnl.polynomial.polyfit(X, Y, 3)
      
   # Méthode des moindres carrés prenant en compte les incertitudes sur Y
   optim = scopt.least_squares(residu,first_guess,args=(X,Y,u_X,u_Y))

   coeff_opt = optim.x
   hessian   = np.matmul(optim.jac.transpose(),optim.jac)
   u_coeff_opt = np.sqrt(2./np.diag(hessian))
   chi2_opt  = np.sum(residu(coeff_opt,X,Y,u_X,u_Y)**2) / (len(X)-2) 
   return [coeff_opt, u_coeff_opt, chi2_opt]

def modele_affine(X,Y,u_X,u_Y):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai obtenus à l'aide de numpy.polyfit
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a*x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return (y-affine(x,a,b)) / np.sqrt(u_y*u_y+(a*u_x)**2)

    # Guess initial
    first_guess = pnl.polynomial.polyfit(X, Y, 1)
    a_guess = first_guess[1]
    b_guess = first_guess[0]

    opt_affine = scopt.least_squares(residu_affine,np.array([a_guess,b_guess]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt(2./hessian_affine[0,0])
    u_b_opt = np.sqrt(2./hessian_affine[1,1])
    chi2_opt = np.sum(residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y)**2) / (len(X)-2)
    #print("Résultats de l'ajustement :")
    #print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    #print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

def susceptibilite(a,u_a,d1,d2,u_d,titre,g=9.81,rho_sel=1.41e3,rho_eau=1.e3,Xeau=-9.e-6):
   """ Exploitation de la relation $\Delta z \propto B^2$ de la méthode de Quincke.
   Les valeurs par defaut correspondent au cas d'une solution acqueuse de FeCl3 """
   # Section des tubes [m^2] et les incertitudes correspondantes
   S1 = np.pi*(d1/2)**2
   S2 = np.pi*(d2/2)**2
   u_S1 = S1*np.sqrt(2)*u_d/d1
   u_S2 = S2*np.sqrt(2)*u_d/d2
   # Formule du Jolidon
   Xsel = a * (2.*4*np.pi*1.e-7*rho_sel*g*(1+S2/S1))/titre + (1.-1./titre)*rho_sel/rho_eau*Xeau
   u_Xsel = Xsel * np.sqrt((u_a/a)**2+(u_S1*S2/(S1*S1))**2+(u_S2/S1)**2)
   print('La susceptibilité vaut {:.2e} +/m {:.2e}'.format(Xsel,u_Xsel))
   print('Pour FeCl3, la valeur tabulée vaut 1.29e-3 (pour une température voisine de 300 K)')
   return
   


# Programme principal
if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   # Le 1er ensemble, etal_I et etal_B, correspond aux couples (courant, champ B) associés à l'étape d'étalonnage de
   # l'électro-aimant. Les incertitudes associées sont u_etal_I et u_etal_B.
   # Le 2eme ensemble, asc_I et asc_z, correspond aux couples (courant, hauteur du ménisque) associés à l'étape
   # où est exploité l'ascension du liquide paramagnétique dans l'entrefer de l'électro-aimant. Les incertitudes associées sont
   # u_asc_I et u_asc_z
   # Les paramètres expérimentaux correspondant aux aspects "projection de l'image", "concentration de la solution", ...
   # sont également à préciser (les noms suffisamment explicites)
   if True:
      # 1er jeu de données (pour l'étalonnage)
      etal_I = np.array([])                                                # I [A]
      etal_B = np.array([]) # B [T]
      u_etal_I = 
      u_etal_B = 
      # 2eme jeu de données (pour l'ascension)
      asc_I = np.array([]) # I [A]
      asc_z = np.array([])                    # z [m]
      u_asc_I  = 
      u_asc_z  = 
      u_asc_B  =   # si on souhaite considerer que la connaissance de B est toujours entachee
                                              # de cette incertitude, independamment de toute autre consdideration
      # Paramètres expérimentaux
      grandissement =                                              # rapport des diamètres de l'image du tube et du tube
      u_grandissement =  # incertitude correspondante
      d1 =   # diamètre du tube situé dans l'entrefer [m], cf Jolidon
      d2 =   # diamètre du tube situé "en champ nul" [m], cf Jolidon
      u_d =  # incertitudes sur les diamètres
      titre =   # titre massique de la solution
      
   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Étalonnage du dispositif
   etalonnage = etalonnage_electroaimant(etal_I,etal_B,u_etal_I,u_etal_B)

   # Ascension paramagétique
   # Step 1: conversion image --> objet
   y = asc_z / grandissement
   u_y = y * np.sqrt((u_asc_z/asc_z)**2 + (u_grandissement/grandissement)**2)
   # Step 2: exploitation de la courbe d'etalonnage
   asc_B = pnl.polynomial.polyval(asc_I,etalonnage[0])
   x = asc_B**2
   u_x = x*np.sqrt(2*(u_asc_B/asc_B)**2)
   # Step 3: ajustement
   ajustement = modele_affine(x,y,u_x,u_y)
   # Susceptibilite
   susceptibilite(ajustement[0],ajustement[2],d1,d2,u_d,titre)

   # Plots
   fig, axes = plt.subplots(2,1,figsize=(6,6))
   axes[0].errorbar(etal_I,etal_B,xerr=u_etal_I,yerr=u_etal_B,linestyle='')
   tmp = np.linspace(np.min(etal_I),np.max(etal_I))
   axes[0].plot(tmp,pnl.polynomial.polyval(tmp,etalonnage[0]),label='ajustement polynomial')
   axes[0].set_title('Etalonnage\n B = {:.2e} + {:.2e} I + {:.2e} I^2 + {:.2e} I^3'.format(*etalonnage[0]))
   axes[0].set_xlabel('I [A]')
   axes[0].set_ylabel('B [T]')
   axes[0].legend(loc='lower right')

   axes[1].errorbar(x,y,xerr=u_x,yerr=u_y,linestyle='')
   tmp = np.linspace(np.min(asc_B**2),np.max(asc_B**2))
   axes[1].plot(tmp,ajustement[0]*tmp+ajustement[1],label='ajustement affine')
   axes[1].set_title('z = {:.2e} B^2 + {:.2e}'.format(ajustement[0],ajustement[1]))
   axes[1].set_xlabel('B^2 [T^2]')
   axes[1].set_ylabel(r'$\Delta z$ [m]')
   axes[1].legend(loc='lower right')

   plt.tight_layout()
   if True:
      plt.savefig('ascension_paramag.png')
   plt.show()


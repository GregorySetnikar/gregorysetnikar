#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN
Version du 24/10/2022
"""

#\%\% Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

#\%\% Définition de fonctions pour effectuer des modélisations affine et non linéaire de données À NE PAS MODIFIER
def modele_NL(X,Y,u_X,u_Y,params_test,f,f_deriv):
    """
    Effectue une modélisation non linéaire Y = f(X,params), en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai contenus dans le tableau params_test.
    La fonction renvoie un tableau qui contient dans l'ordre :
        - les paramètres optimisés dans l'ordre (params_opt),
        - leurs incertitudes dans l'ordre (u_params_opt),
        - la valeur du chi2 réduit (chi2_opt).
    f_deriv désigne la dérivée de la fonction f pour le calcul des résidus.
    """
    def residu_NL(params,x,y,u_x,u_y):
        return ( y - f(x,params) ) / np.sqrt ( u_y * u_y + ( f_deriv(x,params) * u_x ) ** 2 )

    opt_NL = opt.least_squares(residu_NL,params_test,args=(X,Y,u_X,u_Y))
    params_opt = opt_NL.x
    hessian_NL = np.matmul(opt_NL.jac.transpose(),opt_NL.jac)
    u_params_opt = np.sqrt( 2. / np.abs( np.diagonal(hessian_NL) ) )
    chi2_opt = np.sum( residu_NL(params_opt,X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    return np.hstack((params_opt,u_params_opt,np.array([chi2_opt])))

#\%\% Définition de fonctions pour effectuer une modélisations affine À NE PAS MODIFIER
def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre :
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )

    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

def Puis_T(x,params):
    a = params[0]
    b = params[1]
    c = params[2]
    return a * ( x ** 4 - b ** 4 ) + c * ( x - b )

def deriv_Puis_T(x,params):
    a = params[0]
    b = params[1]
    c = params[2]
    return 4 * a * x ** 3 + c

#\%\% Paramètres À MODIFIER
filename = 'data3.txt' # nom du fichier avec U en V et I en A puis l'incertitude sur U en V et l'incertitude sur I en A
R0 =  # résistance de la lampe à température ambiante en ohms
T0 =  # température ambiante en K
l0 =  # estimation de la longueur du filament de tungstène en m
r0 =  # estimation du rayon de courbure du filament de tungstène en m
emiss =  # estimation de l'émissivité du tungstène

#\%\% Importation des données
data = np.genfromtxt(filename)
U = data[:,0]
I = data[:,1]
u_U = data[:,2]
u_I = data[:,3]
a = 2.00e-14 # loi empirique de la résistivité du tungstène en fonction de la température (SI)
b = 2.48e-10 # loi empirique de la résistivité du tungstène en fonction de la température (SI)
c = -1.86e-8 # loi empirique de la résistivité du tungstène en fonction de la température (SI)
sigma = 5.67e-8 # constante de Boltzmann (SI)
P = U * I # puissance en W

#\%\% Calcul des incertitudes À MODIFIER
u_P = P * np.sqrt( ( u_U / U ) ** 2 + ( u_I / I ) ** 2 ) # incertitude sur la puissance en W
if False:
    T = data[:,4] + 273 # température mesurée au pyromètre optique en K
    u_T = data[:,5]
else:
    T = ( np.sqrt( b * b - 4 * a * c + 4 * a * U / I / R0 * ( a * T0 * T0 + b * T0 + c ) ) - b ) / ( 2 * a ) # température calculée en K à partir des propriétés électriques d'un filament de tungstène
    u_T = 0.01 * T # incertitude sur T calculée en K

#\%\% Introduction de variables auxiliaires
X = T / np.amax(T) # normalisation de la température, sinon l'optimisation ne fonctionne pas
Y = P / np.amax(P) # même procédure pour P
u_X = u_T / np.amax(T)
u_Y = u_P / np.amax(P)

#\%\% Effectuer une modélisation de P en fonction de T^4
a_est = 2. * np.pi * r0 * l0 * sigma * emiss * np.amax(T**4) / np.amax(P)
b_est = - 2. * np.pi * r0 * l0 * sigma * emiss * T0 ** 4 / np.amax(P)
param_affine = modele_affine(X**4,Y,4*u_X*X**3,u_Y,a_est,b_est)
a_affine = param_affine[0] / np.amax(T**4) * np.amax(P) # extraction de la pente sans facteurs de normalisation
u_a_affine = param_affine[2] / np.amax(T**4) * np.amax(P) # extraction de l'incertitude sur la pente sans facteurs de normalisation
b_affine = param_affine[1] * np.amax(P) # extraction de l'ordonnée à l'origine sans facteurs de normalisation
u_b_affine = param_affine[3] * np.amax(P) # extraction de l'incertitude sur l'ordonnée à l'origine sans facteurs de normalisation
chi2_affine = param_affine[4] # extraction du chi2 réduit
T0_affine = ( - b_affine / a_affine ) ** 0.25 # température ambiante optimisée
u_T0_affine = 0.25 * T0_affine * np.sqrt( ( u_b_affine / b_affine ) ** 2 + ( u_a_affine / a_affine ) ** 2 )

#\%\% Effectuer une modélisation de ln(P) en fonction de ln(T)
n_est = 4.
c_est = np.log(2. * np.pi * r0 * l0 * sigma * emiss)
param_affine = modele_affine(np.log(T),np.log(P),u_T/T,u_P/P,n_est,c_est)
n_affine = param_affine[0] # extraction de la pente 
u_n_affine = param_affine[2] # extraction de l'incertitude sur la pente
c_affine = param_affine[1] # extraction de l'ordonnée à l'origine
u_c_affine = param_affine[3] # extraction de l'incertitude sur l'ordonnée à l'origine
chi2_affine_2 = param_affine[4] # extraction du chi2 réduit

#\%\% Effectuer une modélisation non linéaire de P en fonction de T qui tient compte de la convection
d_est = 10 * 2 * np.pi * r0 * l0 * np.amax(T) / np.amax(P)
params_NL = modele_NL(X,Y,u_X,u_Y,np.array([a_est,T0/np.amax(T),d_est]),Puis_T,deriv_Puis_T)
a_NL = params_NL[0] / np.amax(T**4) * np.amax(P)
u_a_NL = params_NL[3] / np.amax(T**4) * np.amax(P)
T0_NL = params_NL[1] * np.amax(T) 
u_T0_NL = params_NL[4] * np.amax(T)
d_NL = params_NL[2] / np.amax(T) * np.amax(P)
h_NL = d_NL / a_NL
h_NL *= sigma * emiss
u_h_NL = params_NL[5] / np.amax(T) * np.amax(P)
u_h_NL = h_NL * np.sqrt( (u_h_NL / d_NL ) ** 2 + ( u_a_NL / a_NL ) ** 2)
chi2_NL = params_NL[-1]

#\%\% Tracé des données
T_fin = np.linspace(np.amin(T),np.amax(T),100)
plt.figure()
plt.errorbar(T**4,P,u_P,4*T**3*u_T,'o')
plt.plot(T_fin**4,a_affine*T_fin**4+b_affine,'-',label=r'$T_v=(${0:.2f}$\pm${1:.1f}) K,$\chi_2=${2:.2f}'.format(T0_affine, u_T0_affine, chi2_affine))
plt.xlabel(r'$T^4$ (K)')
plt.ylabel(r'$P$ (W)')
plt.legend()
plt.show()

plt.figure()
plt.errorbar(np.log(T),np.log(P),u_P/P,u_T/T,'o')
plt.plot(np.log(T_fin),n_affine*np.log(T_fin)+c_affine,'-',label=r'$n=(${0:.2f}$\pm${1:.1f}),$\chi_2=${2:.2f}'.format(n_affine, u_n_affine, chi2_affine_2))
plt.xlabel(r'$\ln(T)$')
plt.ylabel(r'$\ln(P)$')
plt.legend()
plt.show()

plt.figure()
plt.errorbar(T,P,u_P,u_T,'o')
plt.plot(T_fin,Puis_T(T_fin,np.array([a_NL,T0_NL,d_NL])),'-',label=r'$h=(${0:.2f}$\pm${1:.1f}), $T_v=(${2:.2f}$\pm${3:.1f}) K,$\chi_2=${4:.2f}'.format(h_NL, u_h_NL, T0_NL, u_T0_NL, chi2_NL))
plt.xlabel(r'$T$')
plt.ylabel(r'$P$')
plt.legend()
plt.show()

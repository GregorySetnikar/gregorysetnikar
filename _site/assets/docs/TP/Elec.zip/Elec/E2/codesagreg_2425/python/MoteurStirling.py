#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-traitement des données (enregistrées dans un fichier) correspondant à un moteur Stirling equipé d'un capteur de pression
et de 2 fourches optiques
Format des données: numéro du cycle, numéro de la fente dans le cycle, pression

Dépendances:

Usage: python python_MoteurStirling_lyon.py

Auteurs: B. Guiselin & E. Brillaux (27/02/2022)
         C. Winisdoerffer (17/03/2022)
         Révisions apportées par les agrégatifs de Lyon 2021-2022
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import time

# Definition des fonctions
def basic_parameters():
   """ Définition des paramètres techniques du moteur Stirling de l'ENS Lyon """
   # Paramètres à ne pas modifier
   Nfentes = 50     # Nombre de fentes
   Vmin    = 32.    # Volume minimal en cm3
   Vmax    = 44.    # Volume maximal en cm3
   deltaP  = 100.   # Différence de pression maximale en kPa
   Nbits   = 10     # Nombre de bits du CAN de la carte arduino
   return Nfentes, Vmin, Vmax, deltaP, Nbits

def read_datafile(fname):
   """ Récupération des données contenues dans le fichier fname """
   try:
      data = np.genfromtxt(fname)
   except ImportError:
      raise ImportError("Impossible d'accéder au fichier {}".format(fname))
   return data

def process_data(data):
   """ Traitement des données et conversion """
   # Le format des données est supposé être:
   #    1ère colonne = numéro du cycle
   #    2ème colonne = numéro de la fente dans le cycle
   #    3ème colonne = pression (codée sur 10 bits)
   cycles = data[:,0]
   fentes = data[:,1]
   press  = data[:,2]
   # Recuperation des paramètres du dispositif mis en œuvre
   Nfentes, Vmin, Vmax, deltaP, Nbits = basic_parameters()
   # Conversion de la pression "sur 10 bits" en pression "en Pa"
   press  = 1.e3 * deltaP * (press/(2**Nbits-1.)-0.5)
   # Calcul du volume de la chambre
   arg = 2.*np.pi*(fentes-1.)/Nfentes
   ###########################################################################################################
   # Attention, dans la formule suivante établissant le lien entre indice de fente et volume, il est crucial
   # que l'indice i=1 corresponde au volume minimal Vmin
   ###########################################################################################################
   V = -0.5*(Vmax-Vmin)*np.cos(arg) + 0.5*np.sqrt((Vmin+Vmax)**2-((Vmin-Vmax)*np.sin(arg))**2)
   # Conversion cm3 --> m3
   V *= 1.e-6
   # Extraction de cycles entiers
   ibeg = np.where(fentes == 1)[0][0]          # debut du 1er cycle complet
   iend = np.where(fentes == Nfentes)[0][-1]   # fin du dernier cycle complet
   Ncycles = (iend-ibeg+1)/Nfentes
   return Ncycles, Nfentes, press[ibeg:iend], V[ibeg:iend], fentes[ibeg:iend]

def compute_thermo(Ncycles, press, V):
   """ Considérations thermodynamiques """
   # Calcul du travail fourni (en J)
   W = np.trapz(press,V)
   print('Travail moyen fourni durant un cycle = {} J (moyenne sur {} cycles)'.format(W/Ncycles, Ncycles))
   # Transfert thermique reçu de la source chaude (en J)
   m = input("Masse d'éthanol brûlé (en g): ")
   try:
      m   = float(m)
   except ValueError:
      print('Réponse non valable --> 10 g par défaut')
      m = 10.
   L   = 29693. # chaleur latente de combustion de l'éthanol en J/g
   Qc  = m*L    # transfert thermique reçu de la source chaude en J
   eta = W/Qc   # rendement du moteur
   print('Transfert thermique moyen reçu durant un cycle = {} J (moyenne sur {} cycles)'.format(Qc/Ncycles, Ncycles))
   print('Rendement moyen = {}.'.format(eta))
   return

def plot_data(fname, Nfentes, press, V):
   """ Visualisation des données dans le diagramme de Watt """
   plt.grid()
   # Visualisation de l'ensemble des données
   plt.plot(1.e6*V,1.e-3*press,zorder=1,color='k')
   # Visualisation d'un cycle
   if False:
      ibeg = int(Nfentes*Ncycles/2) # celui 'du milieu'
   else:
      ibeg = 0                      # le premier
   iend = ibeg + Nfentes
   plt.scatter(1.e6*V[ibeg:iend],1.e-3*press[ibeg:iend],c=np.arange(Nfentes),s=40,cmap='autumn_r',zorder=2)
   # Decorum
   plt.colorbar(label='Indice de fente')
   plt.xlabel(r'V (cm$^3$)')
   plt.ylabel('p (kPa)')
   if True:
      plt.savefig(fname+time.strftime("%y%m%d.%H%M")+".png")
   plt.show()
   return
      
# Programme principal
if __name__ == "__main__":
   # Interaction avec l'utilisateur
   fname = input("Nom du fichier contenant les données: ")
   # Récupération des données brutes
   data = read_datafile(fname)

   # Couples (pression, volume) (en unités SI) sur des cycles complets
   Ncycles, Nfentes, press, V, fentes = process_data(data)

   # Calculs de considérations thermodynamiques
   compute_thermo(Ncycles, press, V)

   # Visualisation
   plot_data(fname, Nfentes, press, V)


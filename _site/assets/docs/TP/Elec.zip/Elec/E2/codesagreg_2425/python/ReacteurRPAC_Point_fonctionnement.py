#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Détermine le(s) point(s) de fonctionnement d'un réacteur RPAC gouverné par les équations de cinétique XCin, et de
thermodynamique XTherm, tel que décrit dans la Ref. "Chimie Tout-en-un PC/PC*", B. Fosset J.-B. Baudin et F. Lahitète (2022)
[chap. Éléments de génie des procédés].

Entrées :
    - a1 facteur pré-exponentiel de la loi d'Arrhenius 
    - tau temps de passage dans le réacteur
    - ea1 énergie d'activation
    - r constante des gaz parfaits
    - te température du thermostat
    - gH enthalpie standard de réaction,
    - ca débit molaire 
    - rho masse volumique
    - Cp capacité thermique

Dépendances:

Usage: python python_ReacteurRPAC_Point_fonctionnement_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np 
from scipy.optimize import root
import matplotlib.pyplot as plt

# Definition des constantes et variables
a1  = 1e13   # s^-1
tau = 1000   # s
ea1 = 99.7e3 # J/mol
r   = 8.31   # J/K/mol
te  = 300    # K
gH  = -20e3  # J/mol
ca  = 5e3    # mol/m^3
rho = 850    # kg/m^3
Cp  = 2200   # J/g/K

# Definition des fonctions
def XCin(t,tau=1000):
    """ Equation du taux de conversion provenant de la cinétique (plus précisment de la loi d'Arrhenius) """
    k1 = a1 * np.exp(-ea1/r/t)
    X = k1 * tau /(k1*tau +1)
    return X

def XTherm(T):
    """ Equation du taux de conversion provenant de la thermochimie (plus précisment d'un bilan thermique sur un réacteur)  """
    X= -rho*Cp*(T-te)/ca/gH
    return X

def DIff(T):
    """ Fonction permettant de trouver une racine de l'equation 'XCin = XTherm' """
    W = abs(XCin(T) -XTherm(T))
    return W

# On sépare la fonction en plusieurs intervalles sur lesquels on cherche une racine
Troot = np.linspace(250,400,40) 
mem= np.array([])
last=[str(150.0)]
for T in Troot :
    a = root(DIff,[T]).x[0]
    stra = str(a)[0:5]
    if stra not in last:
        if DIff(a)<0.01 :
            mem=np.append(a,mem)
            last =  np.append(last,str(a)[0:5])
print('Point(s) de fonctionnement : ', mem)

# Affichage
T = np.linspace(250,400,10000)
Xcin = XCin(T)
Xtherm = XTherm(T)
plt.plot(T,Xcin,label='cinétique')
plt.plot(T,Xtherm,label='thermo')
plt.xlabel('T')
plt.ylabel('X')
plt.ylim(0,1)
plt.title("Points de fonctionnement, Te = " + str(te) + "K"     )
plt.plot(mem,XTherm(mem),'+',markersize=17,label='Pf')
plt.legend()
plt.show()

    

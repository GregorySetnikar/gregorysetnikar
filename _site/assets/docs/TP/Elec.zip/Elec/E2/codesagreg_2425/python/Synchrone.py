#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''Simulation du point de fonctionnement de la machine synchrone'''

import numpy as np
import scipy.optimize as spo
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=24)
matplotlib.rc('ytick', labelsize=24)
matplotlib.rcParams.update({'font.size': 22})

###

M = 1 #Moment lagnétique du rotor
B0 = 1#Champ du stator

alpha = np.arange(-np.pi, np.pi, 0.01) #Dephasage rotor/stator
C_r = 0.1

fig, ax = plt.subplots()
plt.subplots_adjust(left=0.15, bottom=0.25)


def couple(alpha) :
    return(M*B0*np.sin(alpha))

res = np.arcsin(C_r/(M*B0))

Gamma_func = couple(alpha)

plt.plot(alpha, Gamma_func, lw=4, color = 'b')
f, = plt.plot([-np.pi, np.pi], [C_r, C_r], '-r', lw=4)
pt, = plt.plot([res, np.pi-res], [C_r,C_r], 'ok', markersize = 15, alpha=1)
ax.set_xlim(-np.pi, np.pi)
ax.set_ylim(-1.5, 1.5)
#tx1 = plt.text(7, 40e-4, '$ C(\Omega) = \phi_0 \dfrac{U - \phi_0 \Omega}{r} $',fontsize=30, color = 'b')
#tx2 = plt.text(7, 30e-4, '$ \Gamma_r(\Omega) = k \Omega^2 $',fontsize=30, color = 'r')
#tx3 = plt.text(7, 20e-4, '$ \phi_0 = 2R \mathcal{L} B$',fontsize=30)
plt.ylabel('$ C, \Gamma_r $ [$\mathrm{N \cdot m}$]', fontsize = 28)
plt.xlabel(r'$\alpha$ [$\mathrm{rad}$]', fontsize = 28)
titre = plt.title(r"Point de fonctionnement $\alpha = $" + "%0.2f"%res+" $\mathrm{rad}$", fontsize=30)
plt.grid()

axU = plt.axes([0.1, 0.08, 0.7, 0.03])

sU = Slider(axU, '$\Gamma_r$', -1.5, 1.5, valinit=C_r, valfmt='%0.2f')


def update(val):
    C_r = sU.val
    res = np.arcsin(C_r/(M*B0))
    if 0 <= C_r <1 :
        pt.set_xdata([res, np.pi-res])
        pt.set_ydata([C_r, C_r])
        pt.set_alpha(1)
    elif -1 < C_r <0 :
        pt.set_xdata([res, -np.pi-res])
        pt.set_ydata([C_r, C_r])
        pt.set_alpha(1)
    else :
        pt.set_alpha(0)
    f.set_ydata([C_r, C_r])
    titre.set_text(r"Point de fonctionnement $\alpha = $" + "%0.2f"%res +" $\mathrm{rad}$")
    fig.canvas.draw_idle()


sU.on_changed(update)


resetax = plt.axes([0.92, 0.05, 0.05, 0.04])
button = Button(resetax, 'Reset',  hovercolor='0.975')

def reset(event):
    sU.reset()
button.on_clicked(reset)


##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

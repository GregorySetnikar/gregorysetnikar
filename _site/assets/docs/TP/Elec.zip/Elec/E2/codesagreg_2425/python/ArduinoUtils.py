#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utilitaires de récupération sous python de données échantillonnées par un Arduino et transférées via le port série

Dépendances:

Usage: [pas d'usage direct a priori]

Auteurs: C. Winisdoerffer (17/03/2022)
         Révisions apportées par les agrégatifs de Lyon 2021-2022
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import sys, time, argparse, collections
import serial

# Definition des fonctions
def progress_bar(progress):
    """ Barre de visualisation de la progression """
    barLength = 10              # longueur de la barre
    progress  = float(progress) # conversion (éventuelle)
    block = int(round(barLength*progress))
    text = "\rProgression: [{}]".format( "#"*block + "-"*(barLength-block))
    #text = "\rPourcentage: [{}] {}%".format( "#"*block + "-"*(barLength-block), progress*100)
    sys.stdout.write(text)
    sys.stdout.flush()
    return

def manage_SerialPort(argv):
   """ Gestion du port série """
   # Définition de valeurs par défaut
   baudrate = 9600   # doit être identique à celui défini dans le script Arduino
   port     = 'COM1' # port série utilisé pour établir la comm. ordi-Arduino
   # Traitement des arguments optionnels passés sur la ligne de commande
   if argv[1:]:
      # Defining valid arguments and embed them into a parser
      parser = argparse.ArgumentParser()
      parser.add_argument("-r", "--baudrate",   type=int, help="baudrate")
      parser.add_argument("-p", "--port",       type=str, help="port serie")
      args = parser.parse_args()
      # Parse the arguments
      if args.baudrate:   baudrate = args.baudrate
      if args.port:       port = args.port
   # Création et spécification du port série
   serialport          = serial.Serial()
   serialport.baudrate = baudrate
   serialport.port     = port
   return serialport

def check_SerialPort(serialport):
   """ Test de la communication avec le port série """
   # Message
   print('Port série considéré: port = {}, baudrate = {}'.format(serialport.port, serialport.baudrate))
   print('!!!'*36)
   print("! Attention: le port série NE doit PAS être déjà utilisé (par exemple par le Serial Monitor d'arduino)")
   print("! Le cas échéant, fermer les fenêtres concernées avant de lancer le script") 
   print('!!!'*36)
   # Test du port
   try:
      serialport.open()                  # ouverture du port serie
   except:
      print("Port série spécifié invalide; utilisez (la prochaine fois) l'option '-p nomduport'")
      print("Recherche automatique d'un port valide (sans garantie, en particulier si plusieurs sont disponibles)")
      ok_port = False
      for prefix in ['COM', '/dev/ttyACM']:
         i = 0
         while i < 10 and not(ok_port):
            serialport.port = '{}{}'.format(prefix,i)
            try:
               serialport.open()
               ok_port = True
            except:
               i += 1
      if not(ok_port):
         print('Echec de la recherche automatique')
         serialport.port = input("Entrez un nom de port valide: ")
         try:
            serialport.open()
         except:
            sys.exit('Nom de port invalide')
      else:
         print('Port série considéré après recherche automatique: port = {}'.format(serialport.port))
   time.sleep(0.1)
   # Purge du port série
   serialport.reset_input_buffer()
   # Test du port série
   try :
        print("Lecture d'une ligne [affichage brut]: {}".format(serialport.readline()))
        print("Si le résultat n'est pas satisfaisant, modifier le baudrate avec l'option '-r baudrate'")
        time.sleep(1)
   except:
        print('Problème de réception des données')
   return

def detect_Fields(serialport):
   """ Détermine le nombre de données présentes sur une ligne transmise par le port série """
   guess = []
   while len(guess) < 10:
      try:
         # Recuperation des donnees ligne a ligne
         data_byte   = serialport.readline()
         # Conversion binaire --> chaine de caract.
         data_string = data_byte.decode('utf8')
         if data_string[0] != '#': # skip lines beginning with '#'
            guess += [len(data_string.split('\t'))]  # fields are separated by tabulations
      except:
         pass
   # Sanity check
   # todo
   Nfields = collections.Counter(guess).most_common(1)[0][0]
   print('Nfields = {}'.format(Nfields))
   return Nfields
               
def getdata_static(serialport, imax=100, Nfields=None, verbose=False):
   """ Récupère un jeu de données de longueur prédéfinie (default: imax=100) et le sauve dans un fichier.
       Idéal pour le post-traitement. """
   # Test de la comm.
   check_SerialPort(serialport)
   # Detection du nombre de données par ligne
   if not(Nfields):
      Nfields = detect_Fields(serialport)
   # Initialisation
   data = np.nan * np.ones((imax, Nfields))
   # Message
   print("\n* Récupération de {} données consécutives. Pour interrompre le programme, Ctrl+C".format(imax))
   start = time.time()
   # Récuperation des données
   i = 0
   while i < imax:
      try:
         # Recuperation des donnees ligne a ligne
         data_byte   = serialport.readline()
         # Conversion binaire --> chaine de caract.
         data_string = data_byte.decode('utf8')
         # Affichage de la ligne
         if False: print(data_string.strip())
         # Conservation des données numériques
         if data_string[0] != '#': # skip lines beginning with '#'
            try:
               line = np.fromstring(data_string, dtype=float, sep="\t")
               if verbose: print(line,len(line))
               # Conservation des données
               if len(line) == Nfields:
                  data[i,:] = line
                  i += 1
               # Affichage d'une barre de progression
               progress_bar(float(i+1)/imax)
            except: # skip the line if not possible
               pass
      except KeyboardInterrupt: # correspond a un Ctrl + C
         print("Lecture interrompue")
         return
   end = time.time()
   print("\n Temps d'acquisition : {:4f}".format(end-start))
   # Fermeture du port serie
   serialport.close()
   # Sauvegarde
   fname = 'data.{}.txt'.format(time.strftime("%y%m%d.%H%M"))
   print('\n* Sauvegarde des donnees dans le fichier: {}'.format(fname))
   np.savetxt(fname, data)
   return data
   
def getdata_dynamic(serialport, imax=500, iblck=13, yrange=None, Nfields=None, verbose=False):
   """ Récupère les données et les visualise "comme sur un oscillo" 
       Adapté de A. Bérut, https://github.com/aberut/arduino-oscillo) """
   # Test de la comm.
   check_SerialPort(serialport)
   # Detection du nombre de données par ligne
   if not(Nfields):
      Nfields = detect_Fields(serialport)
   # Initialisation
   blck = np.zeros((iblck, Nfields))    # les données sont affichées par blocs (de longueur iblck)
   data = np.zeros((imax, Nfields))
   # Oscilloscope
   fig   = plt.figure()
   ax    = fig.add_subplot(111)
   # Voies de l'oscillo
   channels = [[] for i in range(Nfields)]
   for ifield in range(Nfields):
      channels[ifield], = ax.plot(data[:,ifield])
   # Curseur repérant le dernier point tracé
   cursor, = ax.plot([0,0],[0,2**10-1],'r--')
   # min et max de l'axe des ordonnées
   if yrange:
      ax.set_ylim(yrange[0],yrange[1])
   else:
      ax.set_ylim(0,2**10-1)
   ax.grid()
   # Message
   print("\n* Récupération des données. Pour interrompre le programme, Ctrl+C")
   ibeg = 0
   iend = 0
   t0 = time.time()
   while True:
      try:
         i = 0
         while i < iblck:
            # Recuperation des donnees ligne a ligne
            data_byte   = serialport.readline()
            # Conversion binaire --> chaine de caract.
            data_string = data_byte.decode('utf8')
            # Affichage de la ligne
            if verbose: print(data_string.strip())
            # Conservation des données numériques dans le bloc à visualiser
            if data_string[0] != '#': # skip lines beginning with '#'
               try:
                  line = np.fromstring(data_string, dtype=float, sep="\t")
                  if False: print(line,len(line))
                  # Conservation des données
                  if len(line) == Nfields:
                     blck[i,:] = line
                     i += 1
               except:
                  pass
         # Sauvegarde du dernier bloc de données à la suite du préc. avec le modulo
         ibeg = iend
         iend += iblck
         if iend <= imax:
            data[ibeg:iend,:] = blck[:,:]
         else:
            delta_i = imax-ibeg
            data[ibeg:imax,:]       = blck[:delta_i,:]
            data[0:iblck-delta_i,:] = blck[delta_i:,:]
            iend = iblck-delta_i
         # Visualisation
         for ifield in range(Nfields):
            channels[ifield].set_ydata(data[:,ifield])
         cursor.set_xdata([iend,iend])
         plt.pause(0.01)
         plt.title('Temps écoulé : {:.4} s'.format(time.time()-t0))
         fig.canvas.draw()
      except KeyboardInterrupt: # correspond a un Ctrl + C
         print("Lecture interrompue")
         serialport.close()
         return
   serialport.close()
   return
                  
# Programme principal
if __name__ == "__main__":
   pass


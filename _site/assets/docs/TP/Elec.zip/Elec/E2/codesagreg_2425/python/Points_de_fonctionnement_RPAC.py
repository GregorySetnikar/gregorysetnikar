#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simulation des points de fonctionnement d'un réacteur ouvert avec python

Dépendances:

Usage: python python_points_de_fonctionnement_rpac_lyon.py

Auteurs: Ellipses PC/PC* 3ème edition, dirigée par Bertrand HAUCHECORNE 
    ISBN : 9782340-066731
Modifié par les agrégatifs 2022-2023
"""


# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

# Définition des fonctions
def k(T):
    """ renvoie la constante de vitesse selon la loi d'Arrhenius"""
    return k0*np.exp(-Ea/(R*T))

def Xc(T):
    """ renvoie le taux de conversion selon une cinetique d'odre 1"""
    return 1/(1+1/k(T)/tau)

def Xth(T,Te):
    """ renvoie le taux de conversion en fonction de la température T et de la température d'entrée Te"""
    return (h*S*(T0-T)-rho*Q*Cp*(T-Te))/(F0*DeltaH0)

def update(val):
    """Met à jour la figure quand on modifie la valeur du paramètre via le slider"""
    line.set_ydata(Xth(Temperature,Te_slider.val))
    fig.canvas.draw_idle()

def reset(event):
    """Permet de réinitialiser la valeur de Te utilisée pour tracer la courbe du taux de conversion thermodynamique"""
    Te_slider

# Constantes du problème

# Données thermodynamiques
R = 8.314 #en J/mol/K, constante des gaz parfaits
DeltaH0 = -150000 # en J/mol, enthalpie standard de réaction
rho = 900 #en kg/m3, masse volumique
Cp = 2100 #en J/kg/K? capacité thermique massique

# Données cinétiques de la réaction d'odre 1
k0 = 1e15 #en s, facteur de la constante de vitesse
Ea = 157000 #en J/mol, énergie d'activation

# Données sur les flux
tau = 600 #en s, durée de passage
V = 5.2e-4 #en m3, volume du réacteur
Q = V/tau #en m3/s, débit volumique
C0 = 6e3 #en mol/m3, concentration initiale de peroxyde
F0 = C0*Q #en mol/s, flux d'entrée

# Données sur l'échange thermique
h = 80 #en W/m2/K,coefficient conducto-convectif d'échange
S = 3.14e-2 #en m2, surface d'échange
T0 = 293 #en K, température d'échange

# Température initiale du slider
init_Te = 450

# Listes des temperatures en abscisses pour toutes les courbes
Temperature = np.linspace(250,700,10**5)

# Liste des valeurs du taux de conversion cinetique
Xcinetique = [Xc(T) for T in Temperature]

# Programme principal
if __name__ == "__main__":

    # Tracé des courbes
    plt.figure()
    plt.plot(Temperature,Xcinetique,'k',label = 'Xc')
    plt.xlabel('Température (K)')
    plt.ylabel('X')
    plt.legend()
    plt.grid(True)
    plt.show()

    fig,ax = plt.subplots()

    ax.set_ylim(-0.3,1.2)
    fig.subplots_adjust(left=0.1,bottom=0.35)

    # Tracé de la figure contenant l'intersection entre le taux de conversion cinétique et le taux de conversion thermodyamique
    line, = ax.plot(Temperature,Xth(Temperature,init_Te),color='red',linestyle='dashed')

    ax.plot(Temperature,Xcinetique,'k',label = 'Xc')

    axTemp = fig.add_axes([0.25,0.1,0.65,0.03])
    Te_slider= Slider(ax=axTemp,label='Te [K]',valmin=300,valmax=600,valinit=init_Te)
    
    Te_slider.on_changed(update)


    # Créé un bouton reset à l'aide du widget 'Button' de matplotlib
    resetax = fig.add_axes([0.8, 0.025, 0.1, 0.04])
    button = Button(resetax, 'Reset', hovercolor='0.975')

    button.on_clicked(reset)

    ax.set_xlabel('Température [K]')
    plt.show()
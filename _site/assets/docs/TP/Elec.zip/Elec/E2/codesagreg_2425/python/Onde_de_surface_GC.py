#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Animation qualitative du mouvement des particules de fluide lors du passage d'une onde de surface gravito-capillaire.
Les valeurs numériques sont données en unité arbitraire dans un but purement visuel.

Dépendances:

Usage: python python_Onde_de_surface_GC_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np

import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.widgets import Slider, Button

# Definition des fonctions

def X(x, z, t, h=1, A=0.1, k=0.33, w=1):
    """Calcul de la position horizontale d'une particule
    ou d'un tableau de particules
    x et z correspondent aux positions moyennes de chaque particule
    t le temps
    h la profondeur d'eau
    A l'amplitude de l'onde
    k le vecteur d'onde
    w la pulsation
    """
    return x + A* np.cos(k*x - w*t) * np.cosh(k*z)/np.cosh(k*h)

def Z(x, z, t, h = 1, A=0.1, k=0.33, w=1):
    """Calcul de la position verticale d'une particule
    ou d'un tableau de particules
    x et z correspondent aux positions moyennes de chaque particule
    t le temps
    h la profondeur d'eau
    A l'amplitude de l'onde
    k le vecteur d'onde
    w la pulsation
    """
    return z + A* np.sin(k*x - w*t) * np.sinh(k*z)/np.sinh(k*h)

# Programme principal
if __name__ == "__main__":

    # Paramètres variables
    fig,((ax1,ax2))=plt.subplots(2,1,sharex=True, gridspec_kw={'height_ratios': [2, 1]}, figsize=(10,6))
    fig.suptitle("Ondes de surface gravito-capillaire", fontsize="x-large")


    ax2=plt.subplot(2, 1, 2)
    ax2.axis('off')
    axis_color = 'lightgoldenrodyellow'


    A_slider_ax = fig.add_axes([0.33, .17, 0.3, .02], facecolor = axis_color)
    k_slider_ax = fig.add_axes([0.33, .12, 0.3, 0.02], facecolor=axis_color)
    A_slider = Slider(A_slider_ax, 'Amplitude', 0, 1, valinit = 0.4)
    A_slider.label.set_size(15)
    k_slider = Slider(k_slider_ax,  'k', 1, 10, valinit = 5)
    k_slider.label.set_size(15)

    #------------------------------------------------------------
    #Etat initial


    h = 0.5              # hauteur d'eau
    A = A_slider.val/4   # Amplitude
    k = k_slider.val     # Vecteur d'onde

    x_0 = 3*h * np.linspace(0, 1, 20)
    z_0 = h * np.linspace(0, 0.8, 16)
    x_0, z_0 = np.meshgrid(x_0, z_0)  #Positions d'équilibre des particules

    # Listes pour stocker et observer les positions de 2 particules
    x1 = []
    z1 = []
    x2 = []
    z2 = []

    dt = 1. / 15 # 15fps
    t = 0
    w = 2               # Pulsation (arbitraire pour bien visualiser)

    #------------------------------------------------------------
    # Figure et Animation

    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax = fig.add_subplot(111, aspect='equal',
                        xlim=(-0.2*h*3, 1.2*h*3), ylim=(-0.2*h, 1.2*h))
    ax.axes.xaxis.set_ticklabels([])
    ax.axes.yaxis.set_ticklabels([])
    plt.xticks([])
    plt.yticks([])


    particles, = ax.plot([], [], 'bo', ms=3)  # Position des particules
    line1, = ax.plot([], [], color="red")     # Trajectoire de la 1ere particulre
    line2, = ax.plot([], [], color="red")     # Trajectoire de la 2nde


    def init():
        """Initialisation de l'animation"""
        particles.set_data([], [])
        line1.set_data([], [])
        return particles, line1, line2

    def animate(i):
        """Effectue un pas d'animation"""
        global x_0, z_0, x1, z1, x2, z2, t,dt, ax, fig, w, h
        # Potentiel update de A et k
        A = A_slider.val/4
        k = k_slider.val
        # Calcul des nouvelles positions
        t = t + dt
        x = X(x_0, z_0 , t,h, A, k, w)
        z = Z(x_0, z_0 , t,h, A, k, w)
        x1 += [x[15, 10]]
        z1 += [z[15, 10]]
        x2 += [x[6, 10]]
        z2 += [z[6, 10]]
        # Update de l'animation
        particles.set_data(x, z)
        line1.set_data(x1[-30:], z1[-30:])
        line2.set_data(x2[-30:], z2[-30:])
        return particles,line1, line2



    #Bouton pour démarrer l'animation
    def animate_button(self):
        ani = animation.FuncAnimation(fig, animate, frames=600,
                                interval=20, blit=True, init_func=init)
        fig.canvas.draw()

    # Bouton
    axnext = fig.add_axes([0.785, 0.02,0.1, 0.075], facecolor = axis_color)
    bnext = Button(axnext, 'Run')
    bnext.on_clicked(animate_button)


    plt.show()

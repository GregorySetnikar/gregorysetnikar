#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Utilitaires de plot et de fit

Dépendances:

Usage: [pas d'usage direct a priori]

Auteurs: Agrégatifs de Lyon 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

# Definition des fonctions
def plot_data(ax,x,y,xerr,yerr,labelx,labely):
    """
    Prend en argument l'environnement axis de matplotlib et les données avec les labels
    et trace celles ci avec les barres d'erreur
    """
    ax.errorbar(x,y,xerr=xerr,yerr=yerr,fmt='.')
    ax.set_xlabel(labelx,fontsize=20)
    ax.set_ylabel(labely,fontsize=20)
    ax.tick_params(axis='both', which='both', labelsize=16, width=2)
    return
    
def plot_fit_affine(ax,X,a_opt,b_opt):
    """
    Trace simplement le modèle affine calculé à l'aide des paramètres 
    de l'ajustement sur un tableau d'abscisses quelconque
    """
    Y_fit = a_opt*X +b_opt
    ax.plot(X,Y_fit,color='r',label='pente: a={:.2f}'.format(a_opt))
    return
    
def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement affine :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    print('- chi2 optimal = {0:.2e}'.format(chi2_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

def modele_lineaire(X,Y,u_X,u_Y,a_test):
    """
    Effectue une modélisation linéaire Y = a * X , en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir du paramètre d'essai a_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def lin(x,a):
        return a * x 

    def residu_lin(p_lin,x,y,u_x,u_y):
        a = p_lin[0]
        return ( y - lin(x,a) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_lin = opt.least_squares(residu_lin,np.array([a_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_lin.x[0]
    hessian_lin = np.matmul(opt_lin.jac.transpose(),opt_lin.jac)
    u_a_opt = np.sqrt( 2. / hessian_lin[0,0])
    chi2_opt = np.sum( residu_lin(np.array([a_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement linéaire :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print('- chi2 optimal = {0:.2e}'.format(chi2_opt))
    return np.array([a_opt,u_a_opt,chi2_opt])


def plot_fit_lin(ax,X,a_opt):
    """
    Trace simplement le fit linéaire à partir des paramètres optimaux obtenus sur 
    un tableau d'abscisses X'
    """
    ax.plot(X,a_opt*X,color='r',label='pente: a={:.2f}'.format(a_opt))
    return
    
# Programme principal
if __name__ == "__main__":
    pass

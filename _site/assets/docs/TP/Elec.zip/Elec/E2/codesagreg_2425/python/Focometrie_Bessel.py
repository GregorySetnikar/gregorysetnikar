#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script d'analyse des données correspondant à la mise en œuvre de la méthode de Bessel pour la détermination de la distance
focale d'une lentille mince.
Les incertitudes sont évaluées à l'aide de la méthode des moindres carrés.

Dépendances:

Usage: python python_Focometrie_Bessel_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    Auteur: B. Guiselin
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    # print("Résultats de l'ajustement :")
    # print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    # print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   if True:
      # Valeurs relevées en préparation
      # Distances objet-écran [m]
      D = np.array([])
      # Incertitudes associées [m]
      u_D = 
      # Distances entre les deux positions de Bessel [m]
      dx = abs(np.array([]))
      # Incertitudes associées [m]
      u_dx = 
   else:
      # A COMPLETER PAR L'UTILISATEUR
      pass # syntax consideration...

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Variables pertinentes pour la méthode de Bessel
   x = 4*D
   u_x = 4.*u_D
   y = D**2-dx**2
   u_y = np.sqrt((2*D*u_D)**2+(2*dx*u_dx)**2)
   # Ajustement affine (pour obtenir un premier guess...)
   bessel = np.polyfit(x, y, deg=1)
   # Modélisation affine (avec la prise en compte des incertitudes)
   a_guess = bessel[0]
   b_guess = bessel[1]
   [a_opt, b_opt, u_a_opt, u_b_opt, chi2] = modele_affine(x,y,u_x,u_y,a_guess,b_guess)

   # Comparaison à la valeur "tabulée"
   jnk = input("Focale indiquée sur le support de la lentille [m]: ")
   try:
      focale = float(jnk)
   except ValueError:
      focale = 0.120 # default value
      print("Réponse non valable --> valeur par defaut f'= {} [m]".format(focale))
   zscore = (a_opt - focale)/u_a_opt

   # Affichage des résultats de la modélisation
   print("f' = ", a_opt, '+/-', u_a_opt , '[m]')
   print("chi2 = ", chi2)
   print("zscore = ", zscore)
   
   # Plot
   plt.figure()
   plt.errorbar(x, y, xerr=u_x, yerr=u_y, fmt='+', label = 'points expérimentaux')
   tmp = np.array([np.min(x),np.max(x)]) # pour tracer une droite, 2 points suffisent...
   plt.plot(tmp, a_opt*tmp + b_opt, label = 'modèle affine')
   plt.xlabel(r'$4D$ [m]')
   plt.ylabel(r'$D^2-\Delta x^2$ [m$^2$]')
   plt.legend()
   plt.show()





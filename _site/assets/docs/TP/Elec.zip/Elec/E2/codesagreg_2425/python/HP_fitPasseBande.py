#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-traitement des données permettant la caractérisation du filtre passe-bande correspondant à la modélisation d'un HP
sous la forme d'une impédance électromotionnelle dont l'expression est donnée par Donnini & Quaranta, BUP 777, 1627 (1995)
Format des données: temps, tension, temps, courant (obtenues sous Latis-Pro et exportées en format txt, le séparateur
                                                    correspondant au caractère ";")

Dépendances:

Usage: python python_HP_fitPasseBande_lyon.py [-h] [-r CONVERT_FACTOR] [-f FILENAME]

Auteurs: M. Boselli & F. Vialla (21/02/2023)
         C. Winisdoerffer (22/03/2023)
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import sys, argparse, glob, subprocess
import scipy.optimize as scopt

# Definition des fonctions
def preamble():
   """ Préambule """
   print("Les données sont supposées avoir été acquises au préalable (par exemple sous Latis-Pro) puis exportées "\
         "au format txt, sous la forme (Temps, Voie1, Temps, Voie2).\n"\
         "La Voie1 correspond à la tension U mesurée aux bornes de l'impédance Z lorsque celle-ci est alimentée par un "\
         "GBF en mode sweep.\n"\
         "La Voie2 correspond à la tension mesurée aux bornes d'une résistance R (connue) et permet d'en déduire "\
         "le courant I traversant l'impédance Z.\n\n"\
         "Il appartient à l'utilisateur de définir le facteur de conversion entre la tension Voie2 et le courant I, "\
         "soit à l'appel du script, soit en modifiant le code source. Le nom du (des) fichier(s) à traiter ainsi que la "\
         "fréquence maximale échantillonnée peuvent/doivent également être définis au niveau de la ligne de commande, "\
         "ou en modifiant le code source.\n")
   return

def impedance_model_module(f,R,numer,Q,fres):
   """ Modélisation du module de l'impédance du HP """
   Zmod = np.abs(R+ numer/(1+1j*Q*(f/fres - fres/f)))
   return Zmod

def impedance_model_phase(f,R,numer,Q,fres):
   """ Modélisation de l'argument de l'impédance du HP """
   Zphase = np.unwrap(np.angle(R+ numer/(1+1j*Q*(f/fres - fres/f))))
   return Zphase

def param_estimate(freq,Zmod):
   """ Estimation grossière des paramètres correspondant à une modélisation de |Z| sous la forme d'un passe-bande """
   r = (Zmod[0]+Zmod[1])/2.
   ind_max = np.argmax(Zmod)  # get the position of the max of |Z| over the frequency domain
   numer = Zmod[ind_max]-r
   Q = 5
   fres = freq[ind_max]
   return [r,numer,Q,fres]

# Programme principal
if __name__ == "__main__":
   # Définition des valeurs par défaut
   Rconvert = -3.5                  # conversion tension-courant par Rconvert = U/I [V/A]
   fmax = 500                       # frequence maximale echantillonnee [Hz]
   fnames = ['data/1_masse0g.txt']  # liste des fichiers à analyser
   if True: # récupération de l'ensemble des fichiers txt présents dans un répertoire (pour s'épargner
            # de constituer la liste 'à la main'...
      fnames = glob.glob('data/*.txt')

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Traitement des arguments optionnels passés sur la ligne de commande
   if sys.argv[1:]:
      # Defining valid arguments and embed them into a parser
      parser = argparse.ArgumentParser()
      parser.add_argument("-r", "--conversion_factor",   type=float, help="conversion factor R=U/I")
      parser.add_argument("-m", "--maximal_frequency",   type=float, help="sampled maximal frequency")
      parser.add_argument("-f", "--filename",            type=str,   help="data filename")
      args = parser.parse_args()
      # Parse the arguments
      if args.conversion_factor:   Rconvert = args.conversion_factor
      if args.maximal_frequency:   fmax = args.maximal_frequency
      if args.filename:            fnames = list(args.filename)

   # Interaction avec l'utilisateur
   if False:
      preamble()

   # Traitement des données
   for fname in fnames:
      # Réécriture (éventuelle) des nombres décimaux avec la norme internationnale [ex: 3,14159 --> 3.14159]
      cmd = "sed -i 's/\,/\./g' {}".format(fname)
      subprocess.call([cmd], shell=True)
      # Récupération des données
      data = np.genfromtxt(fname,delimiter=';', skip_header=True)
      time = data[:,0]
      U    = data[:,1]
      I    = data[:,3] / Rconvert # prise en compte de la conversion Voie2 [V] --> I [A]
      # Calcul de l'impédance
      Z = np.fft.fft(U)/np.fft.fft(I)
      # FFT analysis
      ndata = time.size
      dt    = time[1]-time[0]
      freq  = np.fft.fftfreq(ndata, d=dt)   # équivalent à: df = 1./T 
                                            #               freq = np.fft.fftfreq(ndata) * ndata * df
      # Get (1st) index where freq > fmax
      nmax = np.argmax(freq > fmax)
      # Plot
      fig, axes = plt.subplots(2,1,figsize=(6,6))
      axes[0].plot(freq[:nmax],np.abs(Z[:nmax]))
      axes[0].set_xlabel('f [Hz]')
      axes[0].set_ylabel(r'|Z| $[\Omega]$')
      axes[0].set_title('Nom du fichier analysé: {}'.format(fname))
      axes[1].plot(freq[:nmax],np.unwrap(np.angle(Z[:nmax])))
      axes[1].set_xlabel('f [Hz]')
      axes[1].set_ylabel(r'arg(Z)')
      if True:
         plt.savefig(fname[:-4]+'.png')
      plt.show()

      # Fit
      answer = input("Voulez vous effectuer une modélisation sur |Z| (y/n, default: y)? ")
      if answer != 'n' and answer != 'N':
         # Intervalle temporel sur lequel effectuer la modélisation
         answer = input("Borne inférieure de l'intervalle fréquentiel [Hz] (default: {}): ".format(0))
         try:
            fmin_fit = float(answer)
         except:
            print("Unable to convert {} to float, using default value".format(answer))
            fmin_fit = 0
         answer = input("Borne supérieure de l'intervalle fréquentiel [Hz] (default: {}): ".format(fmax))
         try:
            fmax_fit = float(answer)
         except:
            print("Unable to convert {} to float, using default value".format(answer))
            fmax_fit = fmax
         # Get (1st) index where freq > fmin_fit or fmax_fit
         nmin_fit = np.argmax(freq > fmin_fit)
         nmax_fit = np.argmax(freq > fmax_fit)
         # Guess initial des paramètres du fit [R, numerateur, facteur de qualité, fréquence de résonance] pour |Z|
         if True:
            first_guess = param_estimate(freq[nmin_fit:nmax_fit],np.abs(Z[nmin_fit:nmax_fit]))
            print("Using computed first guess parameters: {}".format(first_guess))
         else:
            first_guess = [10,20,2,(fmin_fit+fmax_fit)/2]
            print("Using default first guess parameters: {}".format(first_guess))
         # Curve fitting pour |Z|
         params, cov = scopt.curve_fit(impedance_model_module,\
                                       freq[nmin_fit:nmax_fit],np.abs(Z[nmin_fit:nmax_fit]),first_guess)
         print("Best fit parameters for |Z|: {}".format(params))
         print("......... en particulier, pour la résistance: R = {} +/- {} [Ohm]".format(params[0],np.sqrt(cov[0,0])))
         print("......... en particulier, pour le numérateur: numer = {} +/- {} [Ohm]".format(params[1],np.sqrt(cov[1,1])))
         print("......... en particulier, pour le fact. de qualité: Q = {} +/- {} ".format(params[2],np.sqrt(cov[2,2])))
         print("......... en particulier, pour la freq. de résonance: fres = {} +/- {} [Hz]".format(params[3],np.sqrt(cov[3,3])))
         # Curve fitting pour arg(Z)
         if False:   # l'optmisation des paramètres à l'aide de la phase nécessite plus de raffinement...
            first_guess = params    # on utilise les résultats sur |Z| pour initialiser le fit de arg(Z)
            params_phase, cov_phase = scopt.curve_fit(impedance_model_phase,\
                                      freq[nmin_fit:nmax_fit],np.unwrap(np.angle(Z[nmin_fit:nmax_fit]))+np.pi,first_guess)
            print("Best fit parameters for arg(Z): {}".format(params_phase))
         # Plot
         fig, axes = plt.subplots(2,1,figsize=(6,6))
         axes[0].plot(freq[:nmax],np.abs(Z[:nmax]))
         axes[0].plot(freq[nmin_fit:nmax_fit], impedance_model_module(freq[nmin_fit:nmax_fit],*params))
         axes[0].set_xlabel('f [Hz]')
         axes[0].set_ylabel(r'|Z| $[\Omega]$')
         axes[0].set_title('Nom du fichier analysé: {}'.format(fname))
         axes[1].plot(freq[:nmax],np.unwrap(np.angle(Z[:nmax]))+np.pi)
         axes[1].plot(freq[nmin_fit:nmax_fit], impedance_model_phase(freq[nmin_fit:nmax_fit],*params))
         #axes[1].plot(freq[nmin_fit:nmax_fit], impedance_model_phase(freq[nmin_fit:nmax_fit],*params_phase))
         axes[1].set_xlabel('f [Hz]')
         axes[1].set_ylabel(r'arg(Z)')
         if False:
            plt.savefig(fname[:-4]+'_withfit.png')
         plt.show()
   


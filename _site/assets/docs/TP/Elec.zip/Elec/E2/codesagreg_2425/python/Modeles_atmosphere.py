#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Évolution de la pression en fonction de l'altitude dans le cas d'une atmosphère isotherme ou adiabatique, et comparaison
avec les données expérimentales présentées dans la Ref. "Thermodynamique", B. Diu, C. Guthmann, D. Lederer et B. Roulet (2007).

Dépendances:

Usage: python python_Modeles_atmosphere_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt

def modele_standard():
   """ Retourne temperature T(z) et pression P(z) en fonction de l'altitude tels que dans le Diu (p.632), avec des noms
   suffisamment explicites """
   # Altitude [m]
   z_m = np.array([0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000], dtype='float')
   # Température [C ou K]
   T_C = np.array([15,8.5,2,-4.5,-11,-17.5,-24,-30.5,-37,-43.5,-50], dtype='float')
   T_K = 273.15 + T_C
   # Pression [hPa ou Pa]
   P_hPa = np.array([1013,899,795,701,616,540,472,410,357,307,264], dtype='float')
   P_Pa = P_hPa * 1.e2
   return z_m,T_C,T_K,P_hPa,P_Pa

def modele_isotherme(z,T0):
   """ Retourne la pression normalisée P(z)/P(z=0) en fonction de l'altitude z [m] dans le cas du modèle de l'atmosphère
   isotherme (terrestre) pour une température T0 [K], ainsi que l'échelle de hauteur H [m] """
   # Paramètres physiques
   R = 8.314     # constante des gaz parfaits [J/mol/K]
   M_air = 29e-3 # masse molaire de l'air [kg/mol]
   g = 9.81      # accélération de la pensanteur [m/s^2]
   # Échelle de hauteur de l'atmosphère isotherme [m]
   H = R*T0/(M_air*g)
   # P(z) normalisée
   P = np.exp(-z/H)
   return P,H

def modele_adiabatique(z,T0):
   """ Retourne la pression normalisée P(z)/P(z=0) en fonction de l'altitude z [m] dans le cas du modèle de l'atmosphère
   (terrestre) à gradient de température uniforme (gradient adiabatique), pour une température T(z=0)=T0 [K], ainsi que
   l'échelle de hauteur H [m] """
   # Paramètres physiques
   R = 8.314     # constante des gaz parfaits [J/mol/K]
   M_air = 29e-3 # masse molaire de l'air [kg/mol]
   g = 9.81      # accélération de la pensanteur [m/s^2]
   # Échelle de hauteur de l'atmosphère isotherme [m]
   H = R*T0/(M_air*g) 
   # P(z) normalisée
   P = (1.-2.*z/(7.*H))**(7/2)
   return P,H

if __name__ == "__main__":
   # Altitudes considérées [m]
   z = np.linspace(0,10000.)
   # Pression à l'altitude z=0 [Pa]
   P0 = 101300.
   # Température à l'altitude z=0 [K]
   T0 = 15.8 + 273.15

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Modèle standard
   z_std,T_C,T_K,P_hPa_std,P_Pa_std = modele_standard()
   # Modèle isotherme
   P_isoth,H = modele_isotherme(z,T0)
   # Modèle adiabatique
   P_adiab,H = modele_adiabatique(z,T0)

   # Conversion
   P_isoth *= P0 * 1.e-2 # normalisation + Pa --> hPa
   P_adiab *= P0 * 1.e-2 # normalisation + Pa --> hPa
   z_std   *= 1.e-3      # m --> km 
   z       *= 1.e-3      # m --> km 

   # Plot
   plt.figure()
   plt.plot(z_std,P_hPa_std,'k^', label = "données du modèle standard", ms=10)
   plt.plot(z, P_isoth, 'b.',label="cas isotherme", ms=6)
   plt.plot(z, P_adiab, 'r.',label="cas adiabatique", ms=6)
   plt.xlabel("altitude (km)")
   plt.ylabel("pression (hPa)")
   plt.legend()
   plt.show()
               



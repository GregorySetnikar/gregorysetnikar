#!/usr/bin/env python
# coding: utf-8

"""
Instabilité de Rayleigh-Plateau, analyse basée sur celle présentée dans la Ref. "Physique expérimentale, Optique, magnétisme,
électrotechnique, mécanique, thermodynamique et physique non linéaire", Jolidon (2021).

Dépendances:

Usage: python python_Postraitement_Rayleigh-Plateau_fond_blanc_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""
# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt

# Definition des fonctions
def pause(a):
    input(a + "\n\t Press the <ENTER> key to continue... \n")
    return

def preamble():
   """ Préambule """
   print("Les données sont supposées avoir été acquises au prélable à l'aide du logiciel ImageJ, et enregistrées au format "\
         "csv, avec les colonnes (i, area, x, y, t) où i est le numéro de la goutte, et t est le numéro de la frame où elle "\
         "apparait.\n"\
         "Pour obtenir ce fichier, importer la vidéo SANS L'OPTION VIRTUAL STACK (c'est plus long, mais ça évite plein de "\
         "manipulations supplémentaires), et en nuances de gris. Binariser l'image avec 'Image-Adjust-Threshold'. Aller "\
         "ensuite dans 'Analyze-set measurements', tout décocher et cocher 'Area, center of mass, stack position'.\n"\
         "Repérer les gouttes avec 'Analyze-Analyze particles' puis supprimer les images qui ne sont pas intéressantes dans "\
         "le fichier texte.\n")
   return

# Programme principal
if __name__ == "__main__":
# Interaction avec l'utilisateur
   if True:
      preamble()
   # Nom du fichier de donnees
   fname = 'Rayleigh_Plateau/Results.csv'
   # Rapport pixel/mm
   scale = 
   # Debit de la burette et incertitude associée
   debit = 
   u_debit = 
   l_jet =  # avec la conversion mm -> m
   u_l =        # avec la conversion mm -> m

   # Booleen pour faire afficher des messages a l'aide de la fonction pause définie ci-dessus
   # Normalement, cela fonctionne, mais si ce n'est pas le cas (notamment avec une distribution conda3), ne pas hesiter
   # a modifier msg = True en msg = False
   msg = True

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================

   # Recuperation des données
   data = np.genfromtxt(fname, delimiter=',')[1:]

   # Cosmetic
   parameters = {'axes.labelsize': 13,
                 'xtick.labelsize': 13,
                 'ytick.labelsize': 13}
   plt.rcParams.update(parameters)

   # Calcul du rayon des gouttes en mm
   rayons = np.sqrt(data[:,1]/np.pi)/scale
   T = data[:,4]
   N_gouttes = int(data[-1,0])
   print("Total: {} gouttes, {} frames".format(N_gouttes,T[-1]))

   # Statistique des rayons
   r_avg = np.average(rayons)
   r_std = np.std(rayons)
   print(f'r = {r_avg : ^-.3f} +- {r_std : ^-.3f} mm')

   plt.figure()
   # Trace l'histogramme des valeurs du rayon des gouttes.
   plt.hist(rayons, 30, edgecolor='k')
   plt.xlabel('rayon (mm)')
   plt.ylabel("nombre d'évènements")
   #Trace une ligne verticale à la moyenne de la distribution.
   plt.axvline(r_avg,color='r', label=fr'$\langle r \rangle$ = {r_avg : ^-.3f} mm')
   plt.legend()
   plt.show()

   # Statistique des distances entre gouttes
   list_d = []
   list_d_avg = []

   for t in range(1,int(np.max(T))):
      if t in T:
         # Liste des gouttes d'une même image t
         gouttes_t = []
         for goutte in data:
            if goutte[4]==t:
               gouttes_t.append(list(goutte))
                
         # Tri selon leur abscisse x
         gouttes_t = np.array(gouttes_t)
         gouttes_t_sort=gouttes_t[np.argsort(gouttes_t[:,2])]
         X = gouttes_t_sort[:,2]/scale
        
         # Calcul des distances et de la distance moyenne
         d = np.diff(X)
         d_avg = np.average(d)
         list_d = list_d+list(d)
         list_d_avg.append(d_avg)

   d_avg = np.average(list_d)
   d_std = np.std(list_d)
   print(f'lambda = {d_avg : ^.3f} +- {d_std : ^.3f} mm \n')

   plt.figure()
   # Trace l'histogramme des distances
   plt.hist(list_d,25,edgecolor='k')
   plt.xlabel('$\lambda$ (mm)')
   plt.ylabel("nombre d'évènements")
   #Trace une ligne verticale à la moyenne de la distribution.
   plt.axvline(d_avg,color='r', label=fr'$\langle \lambda \rangle$ = {d_avg : ^.3f} mm')
   plt.legend()
   plt.show()

   # Vérification de la valeur du rapport lambda/r donné dans le Jolidon page 457
   if msg: pause('Vérification de la valeur du rapport lambda/r donné dans le Jolidon page 457')
   rapport = d_avg/l_jet
   erreurRapport = rapport*np.sqrt((d_std/d_avg)**2 + (u_l/l_jet)**2)

   rapportErreurRelative = (d_std/d_avg)/(r_std/r_avg)
   print(f"Le rapport des erreurs relatives sur la longueur d'onde et sur le rayon des gouttes est : {rapportErreurRelative : ^-.1f} \n")
   print(f"Le rapport lambda/r est : {rapport : ^.3f} +- {erreurRapport : ^.3f} \n")

   # Validation des hypothèses :
   # Calcul du nombre d'Ohnesorge pour négliger la diffusion
   if msg: pause("Calcul du nombre d'Ohnesorge")

   rho_eau = 1e3     # masse volumique de l'eau
   gamma_eau = 70e-3 # tension de surface air-eau (celle de l'eau colorée est supposée égale à celle de l'eau pure)
   eta_eau = 1e-3    # viscosite cinématique de l'eau
   Oh = eta_eau*np.sqrt(rho_eau/gamma_eau*l_jet)
   print(f'Nombre d\'Ohnesorge : Oh = {Oh : ^.0e} \n')

   # Compétition avec l'instabilité de Kelvin-Helmholtz
   if msg: pause("Compétition avec l'instabilité de Kelvin-Helmholtz")
   v0 = debit/(np.pi*np.power(l_jet, 2))/rho_eau
   erreurV = v0*np.sqrt((l_jet/erreurL)**2 + (debit/u_debit)**2)
   print(f'Vitesse initiale : {v0*100 : ^.1f} +- {erreurV : ^.1f} cm.s-1')
   rho_air = 1.2 # masse volumique de l'air
   kh = rho_air*np.power(v0, 2)*l_jet/gamma_eau
   print(f'Rapport Kelvin-Helmholtz sur Rayleigh-Plateau : {kh : ^.0e} \n')

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''Simule les niveaux d'occupation d'un laser à 3 niveaux. La transition laser s'effectue entre 1 et 2. 
S'appuie sur le Dangoisse - ch. 1

Auteur : Gauthier Legrand et Francis Pagaud. 31/05/2020.'''




##
import numpy as np # Outils numeriques
import scipy as sp # Outils scientifiques
import scipy.integrate # pour l’integration
import matplotlib.pyplot as plt # Outils graphiques
from matplotlib.widgets import Slider

import matplotlib
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})


## Parametres et conditions initiales

tfin=50e-1 # instant final de la simulation
dt=10e-3 # pas

Wp = 1
gamma32 = 10
gamma31 = 0.1
gamma21 = 0.1

sigma = 50
kappa = 1
c = 1

N10 = 1
N20 = 0
N30 = 0
J0 = 0

vec0 = [N10, N20, N30, J0]

##Fonctions

#y = [N1, N2, N3, J]
def systeme(y,t) :
    
    global Wp, gamma32, gamma31, gamma21, sigma, kappa, c
    
    (N1, N2, N3, J) = y
    
    dN1dt = gamma31*N3 + gamma21*N2 + Wp*(N3-N1) + sigma*J*(N2-N1)
    dN2dt = -sigma*J*(N2-N1) - gamma21*N2 + gamma32*N3
    dN3dt = -(gamma31 + gamma32)*N3 + Wp*(N1-N3)
    dJdt = -kappa*J + c*sigma*J*(N2-N1) + gamma21*N2*c*0.00000001       #Le dernier terme est crucial : c'est une emission spontanee quelconque qui lance la dynamique du laser (avec une proba tres faible de 0.000001%, du a la direction et la phase aleatoire du photon initial)
    
    res = [dN1dt, dN2dt, dN3dt, dJdt]
    return res
    
def update(val) :
    
    global Wp, gamma32, gamma31, gamma21, sigma, kappa, c
    Wp = sw.val
    sol = sp.integrate.odeint(systeme,vec0,t)
    
    N1 = sol[:, 0]
    N2 = sol[:, 1]
    N3 = sol[:, 2]
    J = sol[:, 3]
    ind = np.argwhere(np.abs(J-0.1) < min(np.abs(J-0.1))+0.0001)[0,0]
    
    l1.set_ydata(N1)
    l2.set_ydata(N2)
    l3.set_ydata(N3)
    lj.set_ydata(J)
    
    l.set_xdata([t[ind], t[ind]])
    ll.set_xdata([t[ind], t[ind]])
    
    fig.canvas.draw_idle()

    
    
    
## Resolution
 # Determination de l’entree de l’etage d’amplification
t = np.linspace(0,tfin,int(tfin/dt))
sol = sp.integrate.odeint(systeme,vec0,t)

N1 = sol[:, 0]
N2 = sol[:, 1]
N3 = sol[:, 2]
J = sol[:, 3]

ind = np.argwhere(np.abs(J-0.1) < min(np.abs(J-0.1))+0.0001)[0,0]


## Traces des courbes

fig = plt.figure('Laser à 3 niveaux')
plt.clf()

ax1 = plt.axes([0.07, 0.23, 0.4, 0.7])
ax2 = plt.axes([0.57, 0.23, 0.4, 0.7])
axw = plt.axes([0.07, 0.09, 0.85, 0.03])
plt.text(0, -2, '$\gamma_{32} = $' + str(gamma32))

#slider
sw = Slider(axw, '$W_P$', 0, 10,valfmt='%0.1f',valinit=Wp) # définition de l'intervalle des valeurs de Wp
sw.on_changed(update)

#taux d'occupation
l1, = ax1.plot(t,N1, '-r', lw = 3, label = '$N_1$')   # Le niveau 1
l2, = ax1.plot(t,N2, '-b', lw = 3, label = '$N_2$')   # Le niveau 2
l3, = ax1.plot(t,N3, '-g', lw = 3, label = '$N_3$')   # Le niveau 3
l, = ax1.plot([t[ind], t[ind]], [-0.05, 1.05], '--k', lw = 2)
ax1.text(t[ind]+0.1, 0.8, r'Emission cohérente', color = 'black')

#flux de photons
lj, = ax2.plot(t,J, '-k', lw = 3)     # Flux
ll, = ax2.plot([t[ind], t[ind]], [-0.05, 1.5], '--k', lw = 2)

ax1.set_xlabel("$t$ (s)")
ax1.set_ylabel("Taux d'occupation")
ax1.set_ylim(-0.05,1.05) # Pour bien voir l’ecretage
ax1.legend(framealpha = 0.5, loc=2)
ax1.grid()
ax2.set_ylim(-0.05, 1.5)
ax2.set_xlabel("$t$ (s)")
ax2.set_ylabel("Flux de photons ($\mathrm{s^{-1}\cdot m^{-2}}$)")

##
##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Influence de l'ordre a sur le temps de passage nécessaire pour avoir un taux de conversion donné.

pour une réaction A-> B  
Tracé tridimensionnel en (X,a)

Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as tick
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import LinearLocator, FixedLocator, FormatStrFormatter

from matplotlib import cm
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def rapportTau3D(xx,aa,x,a):
    xxx=xx.flatten()
    return np.piecewise(aa,[aa!=1,aa==1], [lambda aa:(aa-1)*xxx/(1-xxx)*1/(1-(1-xxx)**(aa-1))
        ,lambda aa:-xxx/(1-xxx)*1/np.log(1-xxx)])

def rapportTau1D(x,a):
    if a==1:
        return -x/(1-x)*1/np.log(1-x)
    else:
        return (a-1)*x/(1-x)*1/(1-(1-x)**(a-1))

# Programme principal
if __name__ == "__main__":
    #Name of the output file
    fileOutput = "rapport_tau_a-log.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(1e-3,1-1e-3,100)
    a =np.linspace(-2,2,100)
    xx,aa = np.meshgrid(x, a, indexing='ij')
    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0],projection='3d', proj_type='ortho')

    f=rapportTau3D(xx,aa,x,a)

    Z = np.log10(f)
    ax1.plot_surface(xx,aa,Z,cmap=cm.viridis,zorder=-10)
    #ajout de lignes pour l'ordre 0,1 et 2
    for ordre in [0,1,2]:
        ax1.plot(x,ordre*np.ones_like(x),np.log10(rapportTau1D(x,ordre)),zorder=50)

    #échelle logaithmique pour les données
    zticks = [1e-4, 1e-3, 1e-2, 1e-1, 1, 10,100]
    zticksa = ['1e-4','1e-3','1e-2','1e-1', '1', '10','100']
    ax1.set_zticks(np.log10(zticks))
    ax1.set_zticklabels(zticksa)

    #labels for the axis and title of the graph
    ax1.set_xlabel('$x$')
    ax1.set_ylabel('$\\alpha$')
    ax1.set_zlabel('$\dfrac{\\tau_{RPAC}}{\\tau_{RP}}$')
    plt.savefig(fileOutput)
    plt.show()


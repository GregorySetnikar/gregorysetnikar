# -- coding utf-8 --
# Created on Wed Apr  5 155647 2023
"""
Post-traitement des données (acquises par ailleurs) correspondant à l'expérience du moulin équipé d'un accéléromètre 3-axes

Dépendances:

Usage: python python_Post-traitement_Moulin_Coriolis_python.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

# Definition des fonctions
def aff(x, a, b):
    return a*x+b

def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    Auteur: B. Guiselin
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

# Programme principal
if __name__ == "__main__":
    # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
    fname = 'data.230424.1615.txt'        # Nom du fichier de données (par ex. généré à l'aide de python_ReadSerial_lyon.py)

    # Calibration de l'accéléromètre (à l'aide du serial plotter de l'IDE d'arduino)
    Ax_calibrage = 
    Ay_calibrage = 
    Az_calibrage = (Ax_calibrage + Ay_calibrage)/2

    ac_min = np.array([])         # Maximum de l'accélération de coriolis sur la figure 3
    ac_max = np.array([])                          # Minimum de l'accélération de coriolis sur la figure 3
    ac = ac_min                                                 # Moyenne de l'amplitude de l'accélération de coriolis
    u_ac = np.array([])              # Incertitude sur l'accélération de coriolis
    W = np.array([])                # Vitesse de rotation du plateau sur lequel est posé le moulin en rad.s-1
    u_W =                                           # Incertitude sur la vitesse de rotation du plateau en rad.s-1
    w =                                                     # Vitesse de rotation de l'hélice du moulin en rad.s-1
    u_w =                                           # Incertitude sur la vitesse de rotation de l'hélice du moulin en rad.s-1

    #=========================================================================================
    # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
    #=========================================================================================

    R = 25e-2                                            # Distance du capteur au centre de l'hélice du moulin [m]
    u_R = 0.5e-2                                         # Incertitude correspondante [m]
    xdata = np.linspace(W[0], W[-1], 100)

    data = np.genfromtxt(fname)
    t,Ax,Ay,Az = (data[:,0] - data[:,0][0]) , data[:,1] , data[:,2] , data[:,3]

    #Accelerations non calibrées
    fig,ax = plt.subplots()

    ax.plot(t,Ax,label=r'$a_x$')
    ax.plot(t,Ay,label=r'$a_y$')
    ax.plot(t,Az,label=r'$a_z$')
    ax.set_xlabel(r'ticks [ms]', fontsize = 13)
    ax.set_ylabel(r'Accélération [non calibrée]', fontsize = 13)
    plt.legend()
    #plt.tight_layout()
    plt.show()

    Ax_norm = Ax*9.81/Ax_calibrage  #m/s²
    Ay_norm = Ay*9.81/Ay_calibrage  #m/s²
    Az_norm = Az*9.81/Az_calibrage  #m/s²
    t_norm = t/1000  #s

    #Accelerations normalisées (en m.s-1)
    fig,ax = plt.subplots()

    ax.plot(t_norm,Ax_norm,label=r'$a_x$')
    ax.plot(t_norm,Ay_norm,label=r'$a_y$')
    ax.plot(t_norm,Az_norm,label=r'$a_z$')
    ax.set_xlabel('Temps [s]',fontsize = 13)
    ax.set_ylabel(r'Accélération [m.$s^{-2}$]', fontsize = 13)
    plt.legend()
    #plt.tight_layout()
    plt.show()

    #Limite de la transmission bluetooth
    """
    Affiche l'accélération de coriolis (la seule selon z), en reliant les points, de façon à montrer les limites de la transmission bluetooth.
    """
    fig,ax = plt.subplots()

    ax.scatter(t_norm,Az_norm)
    ax.plot(t_norm,Az_norm,color = 'red')
    ax.set_xlabel('Temps [s]', fontsize = 13)
    ax.set_ylabel(r'Accélération coriolis [m.$s^{-2}$]', fontsize = 13)
    plt.tight_layout()
    plt.show()

    # Régression linéaire de l'accélération de coriolis en fonction de la vitesse de rotation du plateau
    # Régression linéaire sans prise en compte des incertitudes
    reglin = np.polyfit(W, ac, 1)
    A_guess = reglin[0]
    B_guess = reglin[1]
    # Régression linéaire avec prise en compte des incertitudes
    [A_opti, B_opti, u_A_opti, u_B_opti, chi2] = modele_affine(W,ac,u_W,u_ac,A_guess,B_guess)
    print(f'- chi2 = {chi2 : ^-.2f}')

    fig, ax = plt.subplots()
    ax.errorbar(W, ac, u_ac, u_W, linestyle = 'none')
    ax.plot(xdata, aff(xdata, A_opti, B_opti), color = 'red')
    ax.set_xlabel(r'W [rad.$s^{-1}$]', fontsize = 13)
    ax.set_ylabel(r'Accélération [m.$s^{-2}$]', fontsize = 13)
    ax.set_xlim(0)
    ax.set_ylim(0)
    #plt.tight_layout()
    plt.show()

    #Calcul de la pente sans fit grâce à la formule théorique
    pente = 2*R*w
    u_R_relative = u_R/R
    u_w_relative = u_w/w
    u_pente = pente*np.sqrt(u_R_relative**2 + u_w_relative**2) # Utilisation de la formule de propagation des incertitudes
    print(f"La pente calculée à partir de la formule de l'accélération de coriolis est : {pente : ^-.2e} +/- {u_pente : ^-.1e}")

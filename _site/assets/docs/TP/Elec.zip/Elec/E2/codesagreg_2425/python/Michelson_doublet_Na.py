#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script d'analyse des données obtenues à l'aide de l'interféromètre de Michelson pour le doublet du Sodium: l'ajustement affine
de la position du miroir mobile pour différentes anti-coïncidences permet de déterminer la différence de longueur d'onde du
doublet.
Les incertitudes sont évaluées à l'aide de la méthode des moindres carrés.

Dépendances:

Usage: python python_Michelson_doublet_Na_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    Auteur: B. Guiselin
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    # print("Résultats de l'ajustement :")
    # print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    # print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   if False:
      # Valeurs relevées en préparation
      # Positions du chariot lors de l'anti-coincidence [mm]
      x_p = np.array([])
      # Incertitudes associées [mm]
      u_xp = 
      # Numéros de l'anti-coincidence
      p = np.array([])
   else:
      # Valeurs relevées lors de la présentation
      # Positions du chariot lors de l'anti-coincidence [mm]
      x_p = np.array([])
      # Incertitudes associées [mm]
      u_xp =  
      # Numéro de l'anti-coincidence
      p = np.array([])

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Données tabulées (Fruchart) [m]
   lambda_0_tab = 589.3 *1e-9
   u_lambda_0_tab = 0.1 *1e-9
   delta_lambda_tab = 0.597 *1e-9

   # Ajustement affine (pour obtenir un premier guess...)
   reglin = np.polyfit(p, x_p, 1)
   # Modélisation affine (avec la prise en compte des incertitudes)
   A_guess = reglin[0]
   B_guess = reglin[1]
   [A_opti, B_opti, u_A_opti, u_B_opti, chi2] = modele_affine(p,x_p,0,u_xp,A_guess,B_guess)

   # Calcul des grandeurs d'intérêt
   delta_lambda = abs(lambda_0_tab**2/(2*A_opti))
   u_delta_lambda = delta_lambda* np.sqrt(2*(u_lambda_0_tab/lambda_0_tab)**2 + (u_A_opti/A_opti)**2)

   # Comparaison à la valeur tabulée
   z_score = (delta_lambda - delta_lambda_tab)/u_delta_lambda

   # Affichage des résultats de la modélisation
   print("modèle : x_p = A*p + B")
   print('A = ', A_opti,'+/-', u_A_opti, "m")
   print("delta_lambda = ", delta_lambda, '+/-', u_delta_lambda,'m')
   print("chi2 =", chi2)
   print("z_score = ", z_score)
   
   # Plot
   plt.figure()
   plt.errorbar(p, x_p, yerr=u_xp, fmt='b+')
   tmp = np.array([np.min(p),np.max(p)]) # pour tracer une droite, 2 points suffisent...
   plt.plot(tmp, np.polyval(reglin, tmp), 'r-')
   plt.xlabel("Numéro de l'anti-coïncidence (sans dimension)")
   plt.ylabel('x_p [m]')
   plt.show()




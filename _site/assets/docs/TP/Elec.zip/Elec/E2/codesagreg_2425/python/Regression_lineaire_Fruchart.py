# -*- coding: utf-8 -*-
"""
Script de régression linéaire tel que présenté dans la Ref. "Physique expérimentale : optique, mécanique des fluides, ondes
et thermodynamique", M. Fruchart, P. Lidon, E. Thibierge, M. Champion et A. Le Diffon (2016)
"""
import numpy as np
import scipy.optimize as spo
import matplotlib.pyplot as plt

def reg_lin(x,y,ux,uy,abscisse="x",ordonnee="y",legenda="a", legendb="b",labpt="points expérimentaux",echellex=0 ,echelley=0):
    def f(x,p):
        a,b=p
        return a*x+b
    
    def Dx_f(x,p):
        a,b=p
        return a
    
    def residual(p,y,x):
        return (y-f(x,p))/np.sqrt(uy**2+(Dx_f(x,p)*ux)**2)
    
    p0=np.array([0,0]);
    
    result=spo.leastsq(residual,p0,args=(y,x),full_output=True);
    
    popt=result[0];
    pcov=result[1];
    upopt=np.sqrt(np.abs(np.diagonal(pcov)));

    #plt.grid();
    plt.errorbar(x*10**echellex,y*10**echelley,uy*10**echelley,ux*10**echellex,'+',label=labpt);
    lab = r"ajustement "+legenda+"*"+abscisse[0]+"+"+legendb#+" ; "+legenda+"={:.2e}".format(popt[0]) + ", "+legendb+"={:.2e}".format(popt[1])
    plt.plot(x*10**echellex,(x*popt[0]+popt[1])*10**echelley,label=lab);
    plt.legend()
    print(legenda," =", popt[0], " +/-", upopt[0]);
    print(legendb," =", popt[1]," +/-", upopt[1]);
    
    return popt,pcov,upopt


def fit_sin(tt, yy):
    '''Fit sin to the input time sequence, and return fitting parameters "amp", "omega", "phase", "offset", "freq", "period" and "fitfunc"'''
    tt = np.array(tt)
    yy = np.array(yy)
    ff = np.fft.fftfreq(len(tt), (tt[1]-tt[0]))   # assume uniform spacing
    Fyy = abs(np.fft.fft(yy))
    guess_freq = abs(ff[np.argmax(Fyy[1:])+1])   # excluding the zero frequency "peak", which is related to offset
    guess_amp = np.std(yy) * 2.**0.5
    guess_offset = np.mean(yy)
    guess = np.array([guess_amp, 2.*np.pi*guess_freq, 0., guess_offset])

    def sinfunc(t, A, w, p, c):  return A * np.sin(w*t + p) + c
    popt, pcov = spo.curve_fit(sinfunc, tt, yy, p0=guess)
    A, w, p, c = popt
    f = w/(2.*np.pi)
    fitfunc = lambda t: A * np.sin(w*t + p) + c
    return (A, w, p, c)

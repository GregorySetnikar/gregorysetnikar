#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-traitement d'une image (enregistrée dans un fichier) d'une goutte pendante permettant d'accéder à la mesure de
tension superficielle par stalagmométrie
Format des données: cf preamble()
Reférence: "Mesure de la tension superficielle par la technique de la goutte pendante", Gassin P.-M., BUP 108, 1 (2014)

Dépendances:

Usage: python python_Stalagmometrie_lyon.py

Auteurs: C. Winisdoerffer (14/01/2021, examen ONP L3)
         B. Guiselin (23/03/2022)
         C. Winisdoerffer (28/03/2022)
"""

# Importation des librairies
import numpy as np
import scipy
import matplotlib.pyplot as plt
import scipy.integrate as integrate
import scipy.interpolate as interp
import scipy.optimize as opt

# Definition des fonctions
def preamble():
   """ Préambule """
   print("Les étapes de traitement de l'image de la goutte pendante ne font pas partie de ce script, qui n'effectue "\
         "que l'optimisation du profil 'skeletonnisé'.\n"
         "L'extraction de ce profil peut être effectué par exemple avec le logiciel ImageJ, en enchaînant les commandes "\
         "suivantes :\n"
         "   setAutoThreshold('Default');\n"\
         "   //run('Threshold...');\n"\
         "   //setThreshold(0, 85);\n"\
         "   setOption('BlackBackground', false);\n"\
         "   run('Convert to Mask');\n"\
         "   run('Fill Holes');\n"\
         "   run('Find Edges');\n"\
         "   run('Skeletonize');\n"\
         "   run('Save XY Coordinates...', 'background=0 save=[nom_du_fichier].txt');\n")
   return
   
def basic_parameters():
   """ Définition des paramètres physiques dans le cas d'une goutte d'eau pendant à l'extrémité d'un capillaire dans l'air sur Terre """
   g     = 9.81   # Intensité de la pesanteur en m/s^2
   rho_l = 998.30 # Masse volumique du liquide en kg/m^3
   rho_g = 1.204  # Masse volumique du gaz en kg/m^3
   return g, rho_l, rho_g

def picture2profils(fname, calib, u_calib, rotate):
   """ Récupération des données brutes contenues dans le fichier fname, conversion en unités physiques et incertitudes, suivi de
l'extraction des profils gauche et droit avec l'origine située à l'apex de la goutte """
   # Données brutes
   try:
      data = np.genfromtxt(fname)
   except ImportError:
      raise ImportError("Impossible d'accéder au fichier {}".format(fname))
   # Coordonnées (en pixel) et incertitudes correspondantes
   x_px = data[:,0]
   y_px = data[:,1]
   u_x_px = 2.
   u_y_px = 2.
   # Conversion en unités physiques et incertitudes correspondantes (par propagation)
   x = x_px * calib
   y = y_px * calib
   u_x = np.sqrt((u_x_px*calib)**2 + (u_calib*x_px)**2)
   u_y = np.sqrt((u_y_px*calib)**2 + (u_calib*y_px)**2)
   # Rotation de l'image de pi/2 si nécessaire (= permutation des axes X et Y)
   if rotate:
      x, y = y, x
      u_x, u_y = u_y, u_x
   # Detection de l'apex et décalage
   imin = np.argmin(y)
   imin2 = len(y) - np.argmin(y[::-1]) - 1
   iorig = int((imin+imin2)/2.)
   x -= x[iorig]
   y -= y[iorig]
   u_x = np.sqrt(u_x**2 + u_x[iorig]**2)
   u_y = np.sqrt(u_y**2 + u_y[iorig]**2)
   # Split le profil en 2 1/2 profils
   profil_pos = np.array([ x[x>=0.], y[x>=0.], u_x[x>=0.], u_y[x>=0.]])
   profil_neg = np.array([-x[x<=0.], y[x<=0.], u_x[x<=0.], u_y[x<=0.]])
   return profil_pos, profil_neg
      
def get_FordhamEstimates(x, y):
   """ Estimation des paramètres beta et R0 par les tables de Fordham """
   DE = 2. * np.amax(x)
   iS = np.argmin(np.absolute(y-DE))
   DS = 2. * np.absolute(x[iS])
   sigma = DS/DE
   beta  = 0.12836 + sigma * (-0.7577 + sigma*(1.7713-0.5426*sigma))
   R0    = 0.9987 + beta * (0.1987 + beta*(-0.0734+0.34708*beta))
   R0    = 0.5*DE/R0
   return beta, R0

def goutte_ODEs(S, V, beta):
   """ Young-Laplace ODEs pour la goutte ; V = (phi, X, Y)
       Adimensionnement : R0 = rayon de courbure @ apex de la goutte
                          beta \propto R0**2 / \gamma
       Variables : S = s/R0 : abscisse curviligne adim.
                   X = x/R0 : abscisse cart. adim.
                   Y = y/R0 : ordonnee cart. adim.
       ODEs : dphi/dS = 2 - beta*Y - sin(phi)/X
              dX/dS   = cos(phi)
              dY/dS   = sin(phi) """
   phi, X, Y = V
   if X == 0. and phi == 0.:
      dphi_dS = 2.-beta*Y
   else:
      dphi_dS = 2.-beta*Y-np.sin(phi)/X
   dX_dS = np.cos(phi)
   dY_dS = np.sin(phi)
   return dphi_dS, dX_dS, dY_dS

def solution_numerique(beta):
   """ Résolution numérique du jeu d'équations différentielles """
   # Intervalle d'integration (doit etre suffisamment etendu)
   S = np.array([0,5])
   # Conditions initiales [phi, X, Y] @ S=0
   CIs = np.array([0.0, 0.0, 0.0])
   # Integration numerique
   if scipy.__version__ < "1.4.1":
      #https://stackoverflow.com/questions/60002848/solve-ivp-error-missing-2-required-positional-arguments
      #https://stackoverflow.com/questions/62725468/args-not-being-passed-to-scipy-solve-ivp
      sol = integrate.solve_ivp(lambda S, V: goutte_ODEs(S, V, beta), S, CIs, max_step=0.1)
   else:
      sol = integrate.solve_ivp(goutte_ODEs, S, CIs, max_step=0.1, args=(beta,))
   return sol.y[1], sol.y[2] 

def residu(param, x_exp, y_exp, u_x, u_y):
    """ Définition de l'erreur à optimiser par la méthode des moindres carrés """
    beta, R0 = param
    # Solution numérique
    X_sol, Y_sol = solution_numerique(beta)
    # Interpolation de la solution numérique aux mêmes ordonnées (y_exp) que les données expérimentales
    spl = interp.splrep(Y_sol,X_sol) # interpolation par des fonctions splines de la solution numérique
    dspl = interp.splder(spl)        # dérivée de l'interpolation
    # Résidu entre la solution numérique et les données expérimentales par la méthode de la variance effective
    err = (x_exp-interp.splev(y_exp/R0,spl)*R0) / np.sqrt(u_x**2 + (u_y*interp.splev(y_exp/R0,dspl))**2)
    return err

# Programme principal
if __name__ == "__main__":
   # Interaction avec l'utilisateur
   if True:
      preamble()
   if False:
      fname   = input("Nom du fichier contenant les données: ")
      calib   = input("Échelle de distance (en m/pixel): ")
      u_calib = input("Incertitude correspondante: ") 
      rotate  = input("Rotation de l'image (oui/non, la gravite est supposée être dirigée vers le bas): ") 
   else:
      fname  = 'eau_2_crop.txt'
      calib  = 0.71e-3/99.
      u_calib = calib * np.sqrt((0.01e-3/0.71e-3)** 2 + (2./99.)**2) # propagation des incertitudes sur L et # px
      rotate = True

   # Récupération des données et des incertitudes correspondantes (en unites physiques)
   profils = picture2profils(fname, calib, u_calib, rotate)

   # Optimisation des 2 1/2 profils
   param_opts = []
   for profil in profils:
      x   = profil[0]
      y   = profil[1]
      u_x = profil[2]
      u_y = profil[3]
      # Estimation des parametres avec Fordham (guess initial pour l'optimisation)
      beta, R0 = get_FordhamEstimates(x, y)
      # Optimisation
      param = [beta, R0]
      lsq = opt.least_squares(residu, param, args=(profil[:]))
      param = lsq.x
      jac = lsq.jac
      hess = np.linalg.inv(np.matmul(jac.transpose(),jac))
      beta_opt = param[0]
      R0_opt   = param[1]
      u_beta_opt = np.sqrt(2.*hess[0,0])
      u_R0_opt   = np.sqrt(2.*hess[1,1])
      param_opts.append([beta_opt, R0_opt, u_beta_opt, u_R0_opt])

   # Estimation des tensions de surface profils droit/gauche
   g, rho_l, rho_g = basic_parameters()
   Drho = rho_l - rho_g
   gamma_opts = []
   for param_opt,label in zip(param_opts,['(+)','(-)']):
      beta   = param_opt[0]
      R0     = param_opt[1]
      u_beta = param_opt[2]
      u_R0   = param_opt[3]
      gamma   = Drho*g*R0**2/beta
      u_gamma = gamma * np.sqrt((2.*u_R0/R0)**2 + (u_beta/beta)**2)
      gamma_opts.append([gamma, u_gamma])
      print('Tension de surface {} = ({:.2f} \pm {:.1f}) mN / m'.format(label, 1.e3*gamma, 1.e3*u_gamma))
   # Moyenne sur les 2 1/2 profils
   gamma_avg   = (gamma_opts[0][0]+gamma_opts[1][0])/2.
   u_gamma_avg = np.sqrt((gamma_opts[0][1]+gamma_opts[1][1])**2 +
                         ((gamma_opts[0][0]-gamma_opts[1][0])/np.sqrt(2.))**2)/2.
   print('Tension de surface (moy) = ({:.2f} \pm {:.1f}) mN / m'.format(1.e3*gamma_avg, 1.e3*u_gamma_avg))

   # Plot
   fig, ax = plt.subplots(figsize=(5, 5))
   ax.set_aspect('equal')
   ymax = np.amax([np.amax(profils[0][1]),np.amax(profils[1][1])])
   step = 5 # on ne dessine les données expérimentales que tous les step points
   for profil,param_opt,label in zip(profils,param_opts,['(+)','(-)']):
      # Données expérimentales
      x_exp = profil[0]
      y_exp = profil[1]
      # Fit
      beta = param_opt[0]
      R0   = param_opt[1]
      x_num, y_num = solution_numerique(beta)
      x_num *= R0
      y_num *= R0
      if label == '(-)':
         x_exp = -x_exp
         x_num = -x_num
      ax.plot(x_exp[::step] * 1e3, y_exp[::step] * 1e3, 'o', label = 'Data {}'.format(label))
      cond = ymax-y_num > 0
      ax.plot(x_num[cond] * 1e3, y_num[cond] * 1e3, '-', lw=2, label = 'Mod {}'.format(label))
   ax.set_title(r"$\gamma={:.2f} \pm {:.1f}$ mN / m".format(1.e3*gamma_avg, 1.e3*u_gamma_avg))
   ax.set_xlabel('x (mm)')
   ax.set_ylabel('y (mm)')
   plt.legend()
   if False:
      plt.savefig('stalagmometrie.png')
   plt.show()

   

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


'''
Un code pour réaliser un graphe interactif qui illustre la transition ferro-para
avec un slider pour contrôler la température. 
'''

    
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
import scipy.optimize as opt 
import scipy.constants as cst



#Définition des paramètres généraux

Tc= 1040  
k=cst.Boltzmann 
muB= 9.27e-24


init_T = 300   #La valeur initiale de la température sur le slider 




# La fonction à tracer avec son paramètre (ici T)
def f(m,T):
    return np.tanh((Tc/T)*m )




#On crée l'axe des abscisses (ici l'aimantation m)
m = np.linspace(-5, 5, 1000)


# Création du plot principal
fig, ax1 = plt.subplots()
line, = ax1.plot(m, f(m, init_T), lw=2,color='red',label='tanh(m*Tc/T)')
ax1.set_xlabel('m', fontsize=15)
ax1.plot(m,m,color='black', label='m')
ax1.set_xlim(-1.5,1.5)
ax1.set_ylim(-1.5,1.5)
plt.legend()


# Ajustement de la position du plot pour faire de la place pour le slider
fig.subplots_adjust(left=0.1, bottom=0.25)

# Un slider horizontal pour controler la température
axT = fig.add_axes([0.25, 0.1, 0.65, 0.03])
temp_slider = Slider(
    ax=axT,
    label='Température [K]',
    valmin=250,
    valmax=1500,
    valinit=init_T,
)



# La fonction qui sera appelée à chaque variation du slider pour mettre à jour la valeur
def update(val):
    line.set_ydata(f(m, temp_slider.val))
    fig.canvas.draw_idle()


# Enregistre la variation du slider
temp_slider.on_changed(update)



# Créé un bouton reset à l'aide du widget 'Button' de matplotlib
resetax = fig.add_axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', hovercolor='0.975')

def reset(event):
    temp_slider.reset()
    
button.on_clicked(reset)



plt.show()


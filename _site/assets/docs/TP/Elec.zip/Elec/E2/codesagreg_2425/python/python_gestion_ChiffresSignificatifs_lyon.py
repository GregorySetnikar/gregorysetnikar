#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Écriture avec le 'bon' nombre de chiffres significatifs d'un nombre ou d'une paire (mesure, incertitude) de nombres.
'Chiffre significatif' signifie ici 'chiffre après la virgule' dans l'écriture sous la forme X.YeZ, où |X| désigne
un chiffre \in {1,2,..,8,9,10}.

Dépendances:

Pas d'usage direct a priori, mais peut être facilement importé et utilisé dans un script extérieur sous la forme:
   >>> from python_gestion_ChiffresSignificatifs_lyon import *
   >>> print(format_single_withCS(3,299792458))                                # retourne 2.998e8
   >>> print(format_pair_withCS(0,137.035999084,0.000000021))                  # retourne ['1.3703599908e2', '0.0000000002e2']
   >>> print(format_pair_withCS(1,137.035999084,0.000000021,share_exp=False))  # retourne ['1.37035999084e2', '2.1e-8']

Auteurs: C. Winisdoerffer (15/03/2024)
"""

# Importation des librairies
import numpy as np

# Définition des fonctions
def format_single_withCS(n_cs,x):
   """ Représente un nombre sous la forme X.YeZ, où |X| est un chiffre \in {1,2,..,8,9,10}, Y un nombre avec n_cs chiffres, et
       Z la puissance de 10 nécessaire """
   # Récuperation de la puissance
   xexp = int("{:.3e}".format(x)[-3:])
   # Formattage
   xtxt = np.format_float_positional(x/10**(xexp),precision=n_cs,unique=False)
#   if abs(float(xtxt)) >= 10:
#      xexp += 1 
#      xtxt = np.format_float_positional(x/10**(xexp),precision=n_cs,unique=False)
   if xexp == 0:
      xform = "{}".format(xtxt)
   else:
      xform = "{}e{}".format(xtxt,xexp)
   return xform

def format_pair_withCS(n_cs,x,dx,share_exp=True):
   """ Représente deux nombres sous la forme X.YeZ [cf format_single_withCS pour la signification de X, Y et Z], avec un
       nombre de chiffres significatifs compatible. En pratique, x est la mesure et dx son incertitude... 
       L'argument optionnel share_exp permet (si == True) d'avoir la même puissance pour le formatage de dx et x. """
   # Écriture
   xform = format_single_withCS(n_cs,x)
   dxform = format_single_withCS(n_cs,dx)
   # Récuperation des puissances
   xexp = int(xform.split('e')[-1]) if 'e' in xform else 0
   dxexp = int(dxform.split('e')[-1]) if 'e' in dxform else 0
   # Reécriture si nécessaire
   if abs(x) < abs(dx):
      dxform = format_single_withCS(n_cs+dxexp-xexp,dx)
      if share_exp:
         xsign = '-' if x < 0 else ''
         xform = '{}0.{}{}'.format(xsign,'0'*(dxexp-xexp-1),xform.replace('-','').replace('.','').split('e')[0])
         if 'e' in dxform: xform = '{}e{}'.format(xform,dxform.split('e')[-1])
   else:
      xform = format_single_withCS(n_cs+xexp-dxexp,x)
      if share_exp:
         dxsign = '-' if dx < 0 else ''
         dxform = '{}0.{}{}'.format(dxsign,'0'*(xexp-dxexp-1),dxform.replace('-','').replace('.','').split('e')[0])
         if 'e' in xform: dxform = '{}e{}'.format(dxform,xform.split('e')[-1])
   return [xform,dxform]
      
def test_format_single_withCS():
   """ Pour tester la fonction format_single_withCS """
   xarray = np.array([4.948229506274645, 0.055517678712867786, 0.9983506957747142, -0.013018784817777785])
   for coeff in [1,1000,1/1000]:
      for x in xarray:
         x *= coeff
         print(x)
         for n_cs in [0,1,2,3,4]:
            xform = format_single_withCS(n_cs,x)
            print('{} {:>14}'.format(n_cs,xform))
   return

def test_format_pair_withCS():
   """ Pour tester la fonction format_pair_withCS """
   xarray = np.array([4.948229506274645, 0.055517678712867786, 0.9983506957747142, -0.013018784817777785])
   for coeff in [1,1000,1/1000]:
      for x,dx in zip(xarray,np.roll(xarray,1)):
         x  *= coeff
         dx *= coeff
         print(x,dx)
         for n_cs in [0,1,2,3,4]:
            xform,dxform = format_pair_withCS(n_cs,x,dx)
            print('{} {:>14} {:>14}'.format(n_cs,xform,dxform))
   return
      
# Programme principal
if __name__ == "__main__":
   if True: test_format_single_withCS()
   if True: test_format_pair_withCS()
   


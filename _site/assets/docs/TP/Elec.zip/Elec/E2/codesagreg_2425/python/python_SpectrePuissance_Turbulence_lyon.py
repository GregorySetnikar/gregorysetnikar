#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Densité spectrale de puissance d'un signal

Le script calcule et affiche la densité spectrale de puissance d'un signal dont l'acquisition a été faite au préalable.
Dans le cas d'un écoulement turbulent échantillonné à l'aide d'un anémomètre à fil chaud, il permet de discuter (sous
l'hyp. de turbulence gelée) la densité spectrale d'énergie cinétique par unité de masse E(k) en fonction du nombre
d'onde k = 2*pi/l, où l désigne la taille des tourbillons, et retrouver ainsi un spectre en loi de puissance 'à la 
Kolmogorov (Obukhov)' dans la région inertielle.
Format des données: temps, signal (obtenues sous Latis-Pro et exportées en format csv, le séparateur correspondant au
                                   caractère ";", et les en-têtes étant respectivement 'Temps' et 'EA0')

Références: Turbulence, Bailly C. & Comte-Bellot G., chap. Techniques expérimentales [CNRS Editions, 2003]

Dépendances:

Usage: python python_SpectrePuissance_Turbulence_lyon.py

Auteurs: Agrégatifs de physique 2023-2024
"""

# Importation des librairies
import sys, glob                # import des librairies sys et glob
import pandas as pd             # import. de la librairie pandas, raccourci pd
import numpy as np              # import. de la librairie numpy, raccourci np
import matplotlib.pyplot as plt # import. de la (sous-)librairie matplotlib.pyplot


# Définition des fonctions
def getrawdata(fname):
   """ Lecture des données contenues dans le fichier fname """
   try:
      rawdata = pd.read_csv(fname,sep=";",decimal=",")
      t = np.array(rawdata["Temps"])
      u = np.array(rawdata["EA0"])
      return t,u
   except:
      print("La lecture du fichier {} ne s'est pas déroulée convenablement. \n"
            "Vérifiez que le fichier existe et/ou qu'il est conforme au format attendu. \n")
      raise

# Programme principal
if __name__ == "__main__":
   # Paramètres associés à l'étalonnage de l'anémomètre à fil chaud (effectué séparément de ce script)
   # Loi de King : U^2 = a*sqrt(V) + b, où U est la tension mesurée, et V la vitesse du flot
   a = 2.06          # en V^2.m^{-1/2}.s^{1/2}
   b = 2.29          # en V^2
   raw2data = True   # booleen permettant d'ignorer ou non la conversion entre les données brutes et le signal à analyser
   # Liste de fichiers à analyser
   fnames = ['signal_fil_chaud_1.csv']
   if True: # récupération de l'ensemble des fichiers présents dans un répertoire (pour s'épargner de constituer
            # la liste à la main, dans le cas où les données seraient enregistrées en plusieurs fois).
            # Attention, dans ce cas, le pas d'échantillonnage temporel du signal et la durée totale d'acquisition sont
            # supposés identiques pour les différentes expériences.
      fnames = glob.glob('./signal_fil_chaud_*.csv')
   
   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Verification qu'au moins un fichier a été lu...
   if not len(fnames):
      print("Aucun fichier de données n'a été trouvé")
      sys.exit(1)
   # Initialisation d'une liste conservant les différents spectres
   E_fullset = []
   # Traitement des données
   for fname in fnames:
      t,u = getrawdata(fname)
      if raw2data: # conversion des données brutes vers le signal à analyser
         s = ((u**2-b)/a)**2   # conversion tension --> vitesse à l'aide de la loi de King
      else:
         s = u
      # Calcul de la transformée de Fourier du signal
      ndata = t.size
      dt = t[1]-t[0]
      sFFT = np.abs(np.fft.fftshift(np.fft.fft(s-np.mean(s))))  # module de la TF de s
      freq = np.fft.fftshift(np.fft.fftfreq(ndata,dt))          # fréquences échantillonnées
      # Calcul de la densité spectrale de puissance et du spectre
      delta = t[-1]-t[0]   # durée totale de l'acquisition
      dsp = sFFT**2/delta  # densité spectrale de puissance
      E   = np.mean(s)*dsp/(4*np.pi)   # spectre en nombre d'onde
      k   = 2*np.pi*freq/np.mean(s)
      E_fullset.append(E)
   E_fullset = np.array(E_fullset)
   # Figure
   fig = plt.figure(figsize=(12, 6))
   if len(fnames) > 1:
      ax = fig.add_subplot(1,2,1)
   else:
      ax = fig.add_subplot(1,1,1)
   # Plot principal
   ax.loglog(k,np.mean(E_fullset,axis=0))
   # Visualisation d'un spectre à la Kolmogorov (portion de droite de pente -5/3 dans le plan log-log)
   if True: ax.loglog(k[(k>50) & (k<5000)],3e10*k[(k>50) & (k<5000)]**(-5/3))
   # Decorum
   ax.set_ylim(100,1e8)
   ax.set_title("Spectre turbulent - Vérification de la loi en -5/3",fontsize=14)
   ax.set_xlabel(r"$k \mathrm{(m^{-1})}$")
   ax.set_ylabel(r"$E(k) \mathrm{(m^{3}.s^{-2})}$")
   # Subplots
   if len(fnames) > 1:
      nmax = min(3,len(fnames))
      for ii, E in enumerate(E_fullset[:nmax]):
         ax = fig.add_subplot(nmax,2,2*(ii+1))
         ax.loglog(k,E)
         # Decorum
         ax.set_ylim(100,1e8)
         ax.set_title("Acquisition n.{}".format(ii+1))
   plt.tight_layout()
   if True:
      plt.savefig('spectre_Kolmogorov.png')
   plt.show()
   


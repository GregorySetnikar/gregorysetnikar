"""
01/05/2020

Auteur : Francis Pagaud et Gauthier Legrand @ ENS lyon

But : Faire un graphe evolutif de l'instabilite de Rayleigh-Plateau 2D, où la surpression de Laplace est affichee en niveaux de couleurs. 
"""

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=18) 
matplotlib.rc('ytick', labelsize=18) 
matplotlib.rcParams.update({'font.size': 18})

##

R0 = 0.01       #Rayon initial du cylindre en m
eps = 0.001     #Amplitude de perturbation
lamb = 0.05     #longueur d'onde de la perturbation
gamma = 0.072   #tension de surface


def R(R0, eps, lamb, x) :
    '''Donne le profil du cylindre perturbé'''
    prof = R0 + eps*np.cos(2*np.pi/lamb*x)
    return prof

def dp(gamma, R0, eps, lamb, x) :
    '''Surpression en fonction de x'''
    deltap = gamma*eps*np.cos(2*np.pi/lamb*x)*((2*np.pi/lamb)**2-1/R0**2)
    return deltap


##Le graphe

stepx = 0.001      #SI CA RAME, CHANGER LE NB DE PTS
stepy = 0.00005
(miny, maxy) = (-0.015, 0.015)

x = np.arange(0, 0.1, stepx)           #longueur analysee      
y = np.arange(miny, maxy, stepy)    #largeur du graphe

im = np.ones((len(y), len(x)))*-4         #image

profil = R(R0, eps, lamb, x)
deltap = dp(gamma, R0, eps, lamb, x)

for i in range(len(x)) :
    min = -profil[i]
    max = profil[i]
    min1 = (maxy-max)/stepy
    max1 = (maxy-min)/stepy
    im[int(min1):int(max1)+1,i] = deltap[i]


fig = plt.figure('Instabilité de Rayleigh-Plateau')
plt.clf()


axeps = plt.axes([0.15, 0.105, 0.75, 0.03])	# Slider M, on fait varier le param i2
axlam = plt.axes([0.15, 0.075, 0.75, 0.03])	# Slider M, on fait varier le param i2
slamb = Slider(axlam, '$\lambda$ (cm)', 1, 10, valinit=lamb*100, valfmt='%0.1f')
seps = Slider(axeps, '$\epsilon$ (mm)', 0, 5, valinit=eps*1000, valfmt='%0.2f')

fig.text(0.40, 0.025, '$R = 1 \mathrm{cm}$', fontsize = 24)
fig.text(0.5, 0.025, '$\gamma = 72 \mathrm{mN/m}$', fontsize = 24)


def update(val):
    axe_princ.clear()
    eps2 = (seps.val)/1000
    lamb2 = (slamb.val)/100

    
    axe_princ.set_ylabel('y (m)', fontsize = 32)
    axe_princ.set_xlabel('x (m)', fontsize = 32)
    
    profil = R(R0, eps2, lamb2, x)
    deltap = dp(gamma, R0, eps2, lamb2, x)
    
    
    im = np.ones((len(y), len(x)))*-4         #image
    for i in range (len(x)) :
        min = -profil[i]
        max = profil[i]
        min1 = (maxy-max)/stepy
        max1 = (maxy-min)/stepy
        im[round(min1):round(max1)+1,i] = deltap[i]
    imm = axe_princ.pcolormesh(x, y, im)
    imm.set_clim(-2, 2)
    
seps.on_changed(update)
slamb.on_changed(update)


axe_princ = plt.axes([0.15, 0.25, 0.7, 0.7])
axe_cbar = plt.axes([0.9, 0.25, 0.02, 0.7])

imm = axe_princ.pcolormesh(x, y, im)
axe_princ.set_ylabel('y (m)', fontsize = 32)
axe_princ.set_xlabel('x (m)', fontsize = 32)
cbar = plt.colorbar(mappable = imm,cax = axe_cbar, ticks = [-2, -1, 0, 1, 2]) 
imm.set_clim(-2, 2)
cbar.set_label('Surpression (Pa)', rotation=270, fontsize = 20, weight = 'bold')
plt.show()
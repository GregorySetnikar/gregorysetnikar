# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 16:37:10 2025

@author: ens
"""

import numpy as np
import matplotlib.pyplot as plt
import python_DataAnalysisUtils_lyon as DAU

M = 0.586
L = 54.5e-2
L_err = 0.5e-2
g = 9.81
d_err = 0.01e-3

# Tige fine Inox

d_fin = 1.45e-3

longueur = np.array([25.5, 6.1, 11.1, 16.0])*1e-2
longueur_err = np.array([0.5, 0.5, 0.5, 0.5])*1e-2
Periode = np.array([17.22, 16.41, 16.8, 17.03])/10
Periode_err = np.array([0.1, 0.1, 0.1, 0.1])/10

Periode_vide = 17.66/10
Periode_vide_err = 0.2/10

omega = 2*np.pi/Periode
omega_err = omega*Periode_err/Periode

omega_0 = 2*np.pi/Periode_vide

x = 1/longueur
y = omega**2-omega_0**2

x_err = x*longueur_err/longueur
y_err = 2*omega_err*omega

fig, ax = DAU.make_fig(r'$1/l (m^{-1})$', r'$\omega^2-\omega_0^2$ (rad/s)^2')
DAU.plot(ax, x, y)

results_fit = DAU.regression(x, y, xerr=x_err, yerr=y_err, ax=ax)

pente = results_fit['a']
pente_err = results_fit['u_a']

G = (pente*32*M*g*L)/(np.pi*d_fin**4*omega_0**2)
G_err = G*np.sqrt((pente_err/pente)**2+(L_err/L)**2+16*(d_err/d_fin)**2)
String2print, vals = DAU.format_value_with_uncertainty(G, G_err)

print('Inox fin')
print(f'G = {String2print} Pa')


# Tige épaisse Inox

d_epais = 2.90e-3


longueur = np.array([23.7, 19.5, 13, 9.0])*1e-2
longueur_err = np.array([0.5, 0.5, 0.5, 0.5])*1e-2
Periode = np.array([13.72, 13.28, 12.93, 11.69])/10
Periode_err = np.array([0.1, 0.1, 0.1, 0.1])/10

Periode_vide = 17.56/10
Periode_vide_err = 0.2/10

omega = 2*np.pi/Periode
omega_err = omega*Periode_err/Periode

omega_0 = 2*np.pi/Periode_vide

x = 1/longueur
y = omega**2-omega_0**2

x_err = x*longueur_err/longueur
y_err = 2*omega_err*omega

fig, ax = DAU.make_fig(r'$1/l (m^{-1})$', r'$\omega^2-\omega_0^2$ (rad/s)^2')
DAU.plot(ax, x, y)

results_fit = DAU.regression(x, y, xerr=x_err, yerr=y_err, ax=ax)

pente = results_fit['a']
pente_err = results_fit['u_a']

G = (pente*32*M*g*L)/(np.pi*d_epais**4*omega_0**2)
G_err = G*np.sqrt((pente_err/pente)**2+(L_err/L)**2+16*(d_err/d_epais)**2)
String2print, vals = DAU.format_value_with_uncertainty(G, G_err)

print('Inox épais')
print(f'G = {String2print} Pa')



# Tige épaisse Cuivre

d_epais = 2.90e-3


longueur = np.array([25.6, 19.6, 15.3, 9.2])*1e-2
longueur_err = np.ones(len(longueur))*0.5e-2
Periode = np.array([14.94, 14.47, 13.97, 13.00])/10
Periode_err = np.ones(len(Periode))*0.1/10

Periode_vide = 17.56/10
Periode_vide_err = 0.1/10

omega = 2*np.pi/Periode
omega_err = omega*Periode_err/Periode

omega_0 = 2*np.pi/Periode_vide

x = 1/longueur
y = omega**2-omega_0**2

x_err = x*longueur_err/longueur
y_err = 2*omega_err*omega

fig, ax = DAU.make_fig(r'$1/l (m^{-1})$', r'$\omega^2-\omega_0^2$ (rad/s)^2')
DAU.plot(ax, x, y)

results_fit = DAU.regression(x, y, xerr=x_err, yerr=y_err, ax=ax)

pente = results_fit['a']
pente_err = results_fit['u_a']

G = (pente*32*M*g*L)/(np.pi*d_epais**4*omega_0**2)
G_err = G*np.sqrt((pente_err/pente)**2+(L_err/L)**2+16*(d_err/d_epais)**2)
String2print, vals = DAU.format_value_with_uncertainty(G, G_err)

print('Cuivre épais')
print(f'G = {String2print} Pa')



# Tige fine Cuivre

d_fin_Cu = 2.05e-3


longueur = np.array([17.8, 13.8, 3.5, 24.5, 13.5, 10.2])*1e-2
longueur_err = np.ones(len(longueur))*0.5e-2
N = np.array([10, 10, 4, 10, 10, 10])
Periode = np.array([16.47, 15.96, 5.88, 16.56, 16.0, 15.75])/N
Periode_err = np.ones(len(Periode))*0.1/N

Periode_vide = 17.56/10
Periode_vide_err = 0.1/10

omega = 2*np.pi/Periode
omega_err = omega*Periode_err/Periode

omega_0 = 2*np.pi/Periode_vide

x = 1/longueur
y = omega**2-omega_0**2

x_err = x*longueur_err/longueur
y_err = 2*omega_err*omega

fig, ax = DAU.make_fig(r'$1/l (m^{-1})$', r'$\omega^2-\omega_0^2$ (rad/s)^2')
DAU.plot(ax, x, y)

results_fit = DAU.regression(x, y, xerr=x_err, yerr=y_err, ax=ax, xmax=15)

pente = results_fit['a']
pente_err = results_fit['u_a']

G = (pente*32*M*g*L)/(np.pi*d_fin_Cu**4*omega_0**2)
G_err = G*np.sqrt((pente_err/pente)**2+(L_err/L)**2+16*(d_err/d_fin_Cu)**2)
String2print, vals = DAU.format_value_with_uncertainty(G, G_err)

print('Cuivre fin')
print(f'G = {String2print} Pa')




# Tige épaisse Cuivre V2

d_epais = 2.90e-3


longueur = np.array([27.3, 25.2, 23.7, 20.1])*1e-2
longueur_err = np.ones(len(longueur))*0.5e-2
Periode = np.array([15.0, 14.92, 14.75, 14.44])/10
Periode_err = np.ones(len(Periode))*0.1/10

Periode_vide = 17.56/10
Periode_vide_err = 0.1/10

omega = 2*np.pi/Periode
omega_err = omega*Periode_err/Periode

omega_0 = 2*np.pi/Periode_vide

x = 1/longueur
y = omega**2-omega_0**2

x_err = x*longueur_err/longueur
y_err = 2*omega_err*omega

fig, ax = DAU.make_fig(r'$1/l (m^{-1})$', r'$\omega^2-\omega_0^2$ (rad/s)^2')
DAU.plot(ax, x, y)

results_fit = DAU.regression(x, y, xerr=x_err, yerr=y_err, ax=ax)

pente = results_fit['a']
pente_err = results_fit['u_a']

G = (pente*32*M*g*L)/(np.pi*d_epais**4*omega_0**2)
G_err = G*np.sqrt((pente_err/pente)**2+(L_err/L)**2+16*(d_err/d_epais)**2)
String2print, vals = DAU.format_value_with_uncertainty(G, G_err)

print('Cuivre épais')
print(f'G = {String2print} Pa')













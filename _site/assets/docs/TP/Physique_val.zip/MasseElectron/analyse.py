# -*- coding: utf-8 -*-
"""
Created on Wed Apr 30 15:38:22 2025

@author: Valentin
"""

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt


def I2B(I, I_err):
    a = 4304.2e-6
    b = -36.0e-6
    a_err = 4.1e-6
    b_err = 2.7e-6
    
    B = a*I+b
    
    interm = a*I
    interm_err = interm*np.sqrt((a_err/a)**2+(I_err/I)**2)
    
    B_err = np.sqrt(b_err**2+interm_err**2)
    return B, B_err
    
### Paramètres

UA = 4.9675e3 # tension d'accélération 
UA_err = 0.0005e3

e = 1.6e-19 # charge de l'électron
m_e = 9.1e-31 # masse de l'électron

#%% Calibrage

file_path = "Calibrage.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

I = np.array(df["I"])
B = np.array(df["B"])*1e-3
I_err = 0.002*np.ones(len(I))
B_err = np.array(df["B_err"])*1e-3

fig, ax = DAU.make_fig(r"$I$ (A)", r"$B$ (T)")
DAU.plot(ax, I, B)
result_fit = DAU.regression(x=I, y=B, xerr=I_err, yerr=B_err, ax=ax)

a = result_fit["a"]
a_err = result_fit["u_a"]
b = result_fit["b"]
b_err = result_fit["u_b"]




#%% Reading data

file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

I = np.array(df["I"])
I_err = np.array(df["i_err"])
r = np.array(df["r"])*1e-2

B, B_err = I2B(I, I_err)


fig2, ax2 = DAU.make_fig(r"$1/r$ (m$^{-1}$)", r"$B$ (T)")
result_fit = DAU.regression(x=1/r, y=B, yerr=B_err, ax=ax2, xmin=-15, xmax=15)

pente = result_fit['a']
pente_err = result_fit['u_a']

m = pente**2*e/(2*UA)
m_err = m*np.sqrt((pente_err/pente)**2+(UA_err/UA)**2)
String2print, vals = DAU.format_value_with_uncertainty(m, m_err)
print(f'm = {String2print} kg')

z_score = abs(m-m_e)/m_err

plt.xlim(-15, 15)
plt.ylim(-4e-3, 4e-3)

plt.show()
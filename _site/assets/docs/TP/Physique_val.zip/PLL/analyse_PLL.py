# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 03:58:19 2025

@author: ens
"""

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres

k = 0.1
kappa = 20 # en kHz/V
R = 10.04e3
C = 21.69e-9
 

### Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

PlageVerr = np.array(df["f_verr_1"]) - np.array(df["f_verr_2"])
PlageCapt = np.array(df["f_capture_1"]) - np.array(df["f_capture_2"])
Ae = np.array(df["Ae"])/2
As = np.array(df["As"])/2



fig, ax = DAU.make_fig(r"$A_s$ (V)", r"$\Delta f_v (kHz)$")
DAU.plot(ax, As, PlageVerr, label='Verrouillage')
plt.title('Plage de verrouillage')
result_fit = DAU.regression(As, PlageVerr, ax=ax)

PenteAttendue = np.mean(k*kappa*Ae)
print(result_fit["a"])
print(f'A comparer avec {PenteAttendue}')



fig2, ax2 = DAU.make_fig(r"$\Delta f_v$ (kHz)", r"$\Delta f_c^2$ (kHz$^2$)")
DAU.plot(ax2, PlageVerr, PlageCapt**2, label='Capture')
plt.title('Plage de capture')
result_fit = DAU.regression(PlageVerr, PlageCapt**2, ax=ax2, xmax=8)

f_F = 1e-3/(2*np.pi*R*C)
PenteAttendue = 2*f_F

print(result_fit["a"])
print(f'A comparer avec {PenteAttendue}')







plt.show()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Influence du rapport stoechiométrique M sur le temps de passage dans un RPAC nécessaire pour avoir un taux de conversion donné.

pour une réaction A+B -> P avec nB=M*nA et une réaction d'ordre 1 par rapport à chacun des réactifs

tracé en fonction de x pour différents avancements

Attention, pour le tracé, en abscisse c'est 1-X qui est indiqué et pas X pour avoir un tracé intéressant en échelle logarithmique

Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def rapportTauMtau1(x,M):
    return (1-x)/(M-x)
# Programme principal
if __name__ == "__main__":
    #Name of the output file
    fileOutput = "rapport_tau_stoechio-x.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(1e-3,1-1e-3,1000)
    M =np.linspace(1,20,1000)
    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0])
    #plot a vertical line at zero to give a hint on where it lies
    ax1.axhline(0,color='#cccccc')
    colors = ['#e66101','#fdb863','#4d4d4d','#b2abd2','#5e3c99']
    ls=[':','--','-','-.',(0, (3, 1, 1, 1, 1, 1))]
    liste = [1,1.1,2,5,30]
    for i,el in enumerate(liste) :
        ax1.plot(1-x,rapportTauMtau1(x,el), color = colors[i],ls=ls[i] ,label='$M = {}$'.format(el))


    ax1.legend(loc='lower right')
    ax1.set_yscale('log')
    ax1.set_xscale('log')
    #labels for the axis and title of the graph
    ax1.set_xlabel('$1-X_\\mathrm{A}$')
    ax1.set_ylabel('$\dfrac{\\tau_{M}}{\\tau_{1}}(X_\\mathrm{A})$')
    #set limits to the plotted data (to crop for example)
    ax1.set_xlim(1e-3,1)
    #show or hide the bounding axes
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


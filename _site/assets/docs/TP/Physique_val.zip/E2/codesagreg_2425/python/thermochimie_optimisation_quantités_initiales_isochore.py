"""
Python code provided as is.
Based on a code made by Vincent Wieczny and adapted by Thibault Fogeron, from Chemistry Department, ENS de Lyon, France.
This code is under licence CC-BY-NC-SA. It enables you to reuse the code by mentioning the orginal author and without making profit from it.
This code allow to see the effect of the initial ammount of reageats and products in isochore conditions on the reaction : N2 + 3 H2 = 2 NH3


"""

#Librairies
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import widgets
import time

############
### Data ###
############

# Data from https://www.job-stiftung.de/index.php?id=54,153,0,0,1,0

# Data related to N2
mu_std_N2=0.0 # N2(g) standard chemical potential (J/mol) at T=298 K
dev_mu_N2=-191.50 # temperature dependence of N2(g) standard chemical potential (J/mol/K)

# Data related to H2

mu_std_H2=0.0 # H2(g) standard chemical potential (J/mol) at T=298 K
dev_mu_H2=-130.57 # temperature dependence of H2(g) standard chemical potential (J/mol/K)

# Data related to NH3

mu_std_NH3=-16.48e3 # NH3(g) standard chemical potential (J/mol) at T=298 K
dev_mu_NH3=-192.34  # temperature dependence of NH3(g) standard chemical potential (J/mol/K)

#Standard pressure (bar)
P_std=1.0

#Gas constant
R=8.31416


#Volume and temperature are fixed
T = 650
V= 1000


## Modulated parameters : Initial ammount of each compound

parameters = {
            'n0_N2' : widgets.FloatSlider(value=1, description='$n_{0; N_2}$', min=0.01, max=5),
             'n0_H2' : widgets.FloatSlider(value=3, description='$n_{0; H_2}$', min=0.01, max=5),
            'n0_NH3' : widgets.FloatSlider(value=0, description='$n_{0; NH_3}$', min=0, max=2.5),

}



#################
### Functions ###
#################


# Standard chemical potential at T
def mu_std(mu_std_T0,dev_mu,T):
    T0=298.0
    return mu_std_T0+dev_mu*(T-T0)

# Determination of maximal extent of reaction
def max_extent(n_N2,n_H2,n_NH3):
    xi_1=n_N2*1.0
    xi_2=n_H2/3.0
    return min(xi_1,xi_2)

# Determination of minimal extent of reaction
def min_extent(n_N2,n_H2,n_NH3):
    return -n_NH3/2

# Determination of the free Gibbs energy of the system at a specific extent of reaction ; an additional term is needed to consider the variation of pression
def G(xi, n0_N2, n0_H2, n0_NH3):
    n_N2=n0_N2-xi
    n_H2=n0_H2-3*xi
    n_NH3=n0_NH3+2*xi
    n_tot=n_N2+n_H2+n_NH3
    P=R*T*n_tot/V


    mu_N2=mu_std(mu_std_N2,dev_mu_N2,T)+R*T*np.log(n_N2/n_tot*P/P_std)

    mu_H2=mu_std(mu_std_H2,dev_mu_H2,T)+R*T*np.log(n_H2/n_tot*P/P_std)

    mu_NH3=mu_std(mu_std_NH3,dev_mu_NH3,T)+R*T*np.log(n_NH3/n_tot*P/P_std)

    return n_N2*mu_N2+n_H2*mu_H2+n_NH3*mu_NH3 - n_tot*R*T

# Determination of the free Gibbs energy of reaction at a specific extent of reaction
def D_r_G(xi, n0_N2, n0_H2, n0_NH3):
    n_N2=n0_N2-xi
    n_H2=n0_H2-3*xi
    n_NH3=n0_NH3+2*xi
    n_tot=n_N2+n_H2+n_NH3
    P=R*T*n_tot/V


    mu_N2=mu_std(mu_std_N2,dev_mu_N2,T)+R*T*np.log(n_N2/n_tot*P/P_std)

    mu_H2=mu_std(mu_std_H2,dev_mu_H2,T)+R*T*np.log(n_H2/n_tot*P/P_std)

    mu_NH3=mu_std(mu_std_NH3,dev_mu_NH3,T)+R*T*np.log(n_NH3/n_tot*P/P_std)

    return - mu_N2 - 3*mu_H2 + 2*mu_NH3

# Determination of the standard free Gibbs energy of reaction
def D_r_Go(T):

    mu_N2=mu_std(mu_std_N2,dev_mu_N2,T)

    mu_H2=mu_std(mu_std_H2,dev_mu_H2,T)

    mu_NH3=mu_std(mu_std_NH3,dev_mu_NH3,T)

    return - mu_N2 - 3*mu_H2 + 2*mu_NH3


# Determination of the equilibrium state
def xi_eq(xi,G):
    counter=0
    position=0
    minG=min(G)
    for i in range(0,len(G)):
        if G[i]>minG:
            counter=counter+1
        else:
            position=counter
    return xi[position]




######################
### Graphical data ###
######################

# Graph initialization

fig=plt.figure(figsize=(18,6))
ax1 = fig.add_axes([0.15, 0.2, 0.35, 0.75])
ax2 = fig.add_axes([0.60, 0.2, 0.35, 0.75])




# Axis label

ax1.set_xlabel(r'$\xi$ $\mathrm{(mol)}$')
ax1.set_title(r'$G$',fontsize=20,ha='center')
ax1.get_yaxis().set_visible(False)

ax2.set_xlabel(r'$\xi$ $\mathrm{(mol)}$')
ax2.set_title(r'$\Delta_rG$',fontsize=20,ha='center')
ax2.get_yaxis().set_visible(False)



#################
### Animation ###
#################

#===========================================================
# --- Plot of the updated curves ---------------------------
#===========================================================



# This function is called when the sliders are changed

def plot_data(n0_N2, n0_H2, n0_NH3):

 #Updated values

    xi=np.arange(0.001+min_extent(n0_N2,n0_H2,n0_NH3),max_extent(n0_N2,n0_H2,n0_NH3),0.001)

    ax1.set_xlim(-0.5,1.5)
    ax1.set_ylim(min(G(xi, n0_N2, n0_H2, n0_NH3))*1.05,max(G(xi, n0_N2, n0_H2, n0_NH3)))
    ax2.set_xlim(-0.5,1.5)
    ax2.set_ylim(-100000,200000)
    ax2.plot([xi.min(), xi.max()],[0,0],':',lw=1,color='grey')


    xi_equilibre_update=xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3))



    lines['$G$'].set_data(xi,G(xi, n0_N2, n0_H2, n0_NH3))
    lines['${\Delta_rG}$'].set_data(xi,D_r_G(xi, n0_N2, n0_H2, n0_NH3))

    lines_2['$x_eq1$'].set_data([xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3)),xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3))],[min(G(xi, n0_N2, n0_H2, n0_NH3))-100000,min(G(xi, n0_N2, n0_H2, n0_NH3))])
    lines_2['$x_eq2$'].set_data([xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3)),xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3))],[0,min(D_r_G(xi, n0_N2, n0_H2, n0_NH3))-100000])

    texts['DrG0'].set_text('$\Delta_rG^o= {:.3e}$'.format(D_r_Go(T)))
    texts['xeq_1'].set_text('$\\xi_{{\\mathrm{{eq}}}}= {:.3e}$'.format(xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3))))
    texts['xeq_2'].set_text('$\\xi_{{\\mathrm{{eq}}}}= {:.3e}$'.format(xi_eq(xi,G(xi, n0_N2, n0_H2, n0_NH3))))

    fig.canvas.draw_idle()



#########################

lines = {}
lines['$G$'], = ax1.plot([], [],color='red',lw=2)
lines['${\Delta_rG}$'], = ax2.plot([], [],color='blue',lw=2)

lines_2 = {}
lines_2['$x_eq1$'], = ax1.plot([], [],'--',color='grey',lw=2,label='')
lines_2['$x_eq2$'], = ax2.plot([], [],'--',color='grey',lw=2,label='')

texts = {}
texts['DrG0']=   fig.text(0.78, 0.90, '${\Delta_rG^°}$', fontsize=12,ha='center')
texts['xeq_1']=   fig.text(0.32, 0.3, '${\Delta_rG^°}$', fontsize=12,ha='center')
texts['xeq_2']=   fig.text(0.72, 0.3, '${\Delta_rG^°}$', fontsize=12,ha='center')


ax1.legend()



param_widgets = widgets.make_param_widgets(parameters, plot_data, slider_box=[0.20, 0.05, 0.35, 0.05])
choose_widget = widgets.make_choose_plot(lines, box=[0.01,0.2,0.05, 0.2])
reset_button = widgets.make_reset_button(param_widgets,box=[0.85, 0.05, 0.10, 0.05])

if __name__=='__main__':
    plt.show()

plt.show()
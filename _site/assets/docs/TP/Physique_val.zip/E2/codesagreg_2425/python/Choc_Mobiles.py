#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN
Version du 12/10/2022
"""

# Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

# Définition de fonctions pour effectuer une modélisations affine À NE PAS MODIFIER
def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre :
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
    
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

# Paramètres À MODIFIER
filename1 = 'data1.txt' # nom du fichier avec x, y en m (mobile 1)
filename2 = 'data2.txt' # nom du fichier avec x, y en m (mobile 2)
T = 0.04 # période des impulsions en s
u_x = 0.05 # incertitude sur x en m
u_y = 0.05 # incertitude sur y en m
m1 = 1. # masse du mobile 1 en kg
m2 = 1. # masse du mobile 2 en kg

# Importation des données
data1 = np.genfromtxt(filename1)
data2 = np.genfromtxt(filename2)
x1 = data1[:,0]
y1 = data1[:,1]
x2 = data2[:,0]
y2 = data2[:,1]
u_x1 = u_x * np.ones(len(x1)) # incertitude sur l'abscisse du premier mobile, etc.
u_x2 = u_x * np.ones(len(x2))
u_y1 = u_y * np.ones(len(y1))
u_y2 = u_y * np.ones(len(y2))
t = np.arange(0, len(x1)) * T # tableau des temps
u_t = np.zeros(len(t)) # incertitude sur le temps
vx1 = np.diff(x1) / T # vitesse instantanée selon x du premier mobile, etc.
vx2 = np.diff(x2) / T
vy1 = np.diff(y1) / T
vy2 = np.diff(y2) / T

# Calcul des vitesses avant et après le choc
j_choc = 10 # position du choc À MODIFIER
param_affine_x1_avant = modele_affine(t[:j_choc],x1[:j_choc],u_t[:j_choc],u_x1[:j_choc],1.,0.)
param_affine_x2_avant = modele_affine(t[:j_choc],x2[:j_choc],u_t[:j_choc],u_x2[:j_choc],1.,0.)
param_affine_y1_avant = modele_affine(t[:j_choc],y1[:j_choc],u_t[:j_choc],u_y1[:j_choc],1.,0.)
param_affine_y2_avant = modele_affine(t[:j_choc],y2[:j_choc],u_t[:j_choc],u_y2[:j_choc],1.,0.)
param_affine_x1_apres = modele_affine(t[j_choc:],x1[j_choc:],u_t[j_choc:],u_x1[j_choc:],1.,0.)
param_affine_x2_apres = modele_affine(t[j_choc:],x2[j_choc:],u_t[j_choc:],u_x2[j_choc:],1.,0.)
param_affine_y1_apres = modele_affine(t[j_choc:],y1[j_choc:],u_t[j_choc:],u_y1[j_choc:],1.,0.)
param_affine_y2_apres = modele_affine(t[j_choc:],y2[j_choc:],u_t[j_choc:],u_y2[j_choc:],1.,0.)
vx1_avant = param_affine_x1_avant[0]
u_vx1_avant = param_affine_x1_avant[2] 
vx2_avant = param_affine_x2_avant[0]
u_vx2_avant = param_affine_x2_avant[2] 
vy1_avant = param_affine_y1_avant[0]
u_vy1_avant = param_affine_y1_avant[2] 
vy2_avant = param_affine_y2_avant[0]
u_vy2_avant = param_affine_y2_avant[2] 
vx1_apres = param_affine_x1_apres[0] 
u_vx1_apres = param_affine_x1_apres[2] 
vx2_apres = param_affine_x2_apres[0]
u_vx2_apres = param_affine_x2_apres[2] 
vy1_apres = param_affine_y1_apres[0]
u_vy1_apres = param_affine_y1_apres[2] 
vy2_apres = param_affine_y2_apres[0]
u_vy2_apres = param_affine_y2_apres[2] 

# Calcul de l'impulson du centre de masse avant et après le choc
px_avant = m1 * vx1_avant + m2 * vx2_avant
u_px_avant = np.sqrt( ( m1 * u_vx1_avant ) ** 2 + ( m2 * u_vx2_avant ) ** 2 )
px_apres = m1 * vx1_apres + m2 * vx2_apres
u_px_apres = np.sqrt( ( m1 * u_vx1_apres ) ** 2 + ( m2 * u_vx2_apres ) ** 2 )
py_avant = m1 * vy1_avant + m2 * vy2_avant
u_py_avant = np.sqrt( ( m1 * u_vy1_avant ) ** 2 + ( m2 * u_vy2_avant ) ** 2 )
py_apres = m1 * vy1_apres + m2 * vy2_apres
u_py_apres = np.sqrt( ( m1 * u_vy1_apres ) ** 2 + ( m2 * u_vy2_apres ) ** 2 )
print('Impulsion du centre de masse selon x avant le choc = ({0:.2f} \pm {1:.1f}) kg.m/s'.format(px_avant, u_px_avant))
print('Impulsion du centre de masse selon y avant le choc = ({0:.2f} \pm {1:.1f}) kg.m/s'.format(py_avant, u_py_avant))
print('Impulsion du centre de masse selon x apres le choc = ({0:.2f} \pm {1:.1f}) kg.m/s'.format(px_apres, u_px_apres))
print('Impulsion du centre de masse selon y apres le choc = ({0:.2f} \pm {1:.1f}) kg.m/s'.format(py_apres, u_py_apres))

# Tracé des différentes trajectoires
x_I = (m1 * x1 + m2 * x2) / (m1 + m2) # abscisse du centre d'inertie
y_I = (m1 * y1 + m2 * y2) / (m1 + m2) # ordonnée du centre d'inertie
plt.figure()
plt.errorbar(x1,y1,u_y * np.ones(len(y1)),u_x * np.ones(len(x1)),'^',label = 'Mobile 1')
plt.errorbar(x2,y2,u_y * np.ones(len(y1)),u_x * np.ones(len(x1)),'v',label = 'Mobile 2')
plt.errorbar(x_I,y_I,u_y * np.ones(len(y1)),u_x * np.ones(len(x1)),'o',label = 'Centre de masse')
plt.xlabel(r'$x$ (m)')
plt.ylabel(r'$y$ (m)')
plt.legend()
plt.show()

# Calcul des différentes énergies
E1 = 0.5 * m1 * ( vx1 * vx1 + vy1 * vy1 ) # énergie cinétique du premier mobile
E2 = 0.5 * m2 * ( vx2 * vx2 + vy2 * vy2 ) # énergie cinétique du second mobile
Etot = E1 + E2 # énergie cinétique totale
plt.figure()
plt.plot(t[:-1],E1,'^',label = 'Mobile 1')
plt.plot(t[:-1],E2,'v',label = 'Mobile 2')
plt.plot(t[:-1],Etot,'o',label = 'Centre de masse')
plt.xlabel(r'$t$ (s)')
plt.ylabel(r'$E$ (J)')
plt.legend()
plt.show()

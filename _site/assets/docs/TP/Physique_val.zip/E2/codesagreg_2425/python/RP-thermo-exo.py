#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

Lien entre avancement et température dans un RP pour une réaction d'ordre 1 exothermique réversible en fonction du temps de passage

pour une réaction A-> P et une réaction d'ordre 1 par rapport à chacun des réactifs


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.constants as sc
import scipy.optimize as opti
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def KT(T,A,Ea,B,Eb):
    ka=A*np.exp(-Ea/(sc.R*T))
    kb=B*np.exp(-Eb/(sc.R*T))
    return ka/kb


def derxt2(T,dT,A,Ea,B,Eb,tau,T2,gradX):
    indixT = np.argmin(np.abs(T2-T))
    return gradX[indixT] 

def xttau(T,A,Ea,B,Eb,tau):
    K = KT(T,A,Ea,B,Eb)
    ka=A*np.exp(-Ea/(sc.R*T))
    Xeq = K/(1+K)
    return Xeq*(1-np.exp(-ka*tau/Xeq))
    

if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RP-thermo-KT.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(0,1,1000)
    T,dT =np.linspace(250,420,1000,retstep = True)
    taus=np.logspace(-3,3,1000,)
    deltas = taus[1:] - taus[0:-1]


    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0])
 

    A = 2.95e7
    B = 1.57e18
    Ea = 46.4e3
    Eb = 118.4e3
    ToptYield = []
    optYield = []

    T2,dT2 =np.linspace(250,420,1000,retstep = True)

    #on cherche le point de dérivée nulle 
    for idx,tau in enumerate(taus):
        XT = xttau(T2,A,Ea,B,Eb,tau)
        gradX = np.gradient(XT,dT2) 
        if idx==0:
            sol = opti.brentq(derxt2,300,500,args=(dT,A,Ea,B,Eb,tau,T2,gradX)) 
        else:
            sol = opti.brentq(derxt2,ToptYield[idx-1]-20,ToptYield[idx-1]+10,args=(dT,A,Ea,B,Eb,tau,T2,gradX)) 
        ToptYield.append(sol)
        optYield.append(xttau(sol,A,Ea,B,Eb,tau))
    
    K = KT(T,A,Ea,B,Eb)
    Xeq = K/(1+K)

    colors = ['#bfd3e6','#8c96c6','#8c6bb1','#88419d','#810f7c','#4d004b']
    ls=[(0, (3, 1, 1, 1, 1, 1)),':','--','-','-.']
    #temps de passage
    liste = [1e-2,0.1,1,10,20]
    ax1.plot(T,Xeq, color ='#000000' ,ls='-',label = '$X_\mathrm{eq}$')# ,label='$\\tau = {}$'.format(liste[i]))
    for i in range(len(liste)) :
        xtau = xttau(T,A,Ea,B,Eb,liste[i])
        ax1.plot(T,xtau, color = colors[i],ls=ls[i],label = '{}'.format(liste[i]))

    ax1.plot(ToptYield,optYield, color = 'gray',ls='-',label = '$T_\mathrm{th}$')
    
    

    ax1.legend(loc='upper right')
    #labels for the axis and title of the graph
    ax1.set_xlabel('$T$')
    ax1.set_ylabel('$X$')
    #set limits to the plotted data (to crop for example)
    ax1.set_xlim(min(T),max(T))
    #show or hide the bounding axes
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


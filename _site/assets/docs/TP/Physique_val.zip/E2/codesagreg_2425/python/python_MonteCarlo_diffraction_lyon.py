#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Régression linéaire Y = a * X + b par méthode des moindres carrés et propagation des incertitudes par méthode de Monte-Carlo.
Les incertitudes sont designées par u_X et u_Y

Dépendances:

Usage: python python_MonteCarlo_diffraction_lyon.py

Auteurs: Agrégatifs de physique 2023-2024
"""

# Importation des librairies
import numpy as np              # import. de la librairie numpy, raccourci np
import scipy.optimize as scopt  # import. de la (sous-)librairie scipy.optimize
import scipy.stats as scstat    # import. de la (sous-)librairie scipy.stats
import matplotlib.pyplot as plt # import. de la (sous-)librairie matplotlib.pyplot

# Definition des fonctions
def get_rawdata_default():
   """ Exemple de données expérimentales (sur une manip. de diffraction par une fente) """
   # Mesures
   b = np.array([100e-6, 70e-6, 40e-6])      # largeur de la fente (m)
   L = np.array([2.58e-3, 3.57e-3, 6.60e-3]) # largeur de la tache centrale de diffraction (m)
   # Incertitudes
   u_b = 1e-6            # incertitude sur b (m)
   u_L = 0.4e-3          # incertitude sur L (m)
#   D_b = u_b*np.sqrt(3)  # demi-etendue pour une distribution rectangle
#   D_L = u_L*np.sqrt(3)  # demi-etendue pour une distribution rectangle
   return b,u_b,L,u_L

def rawdata2XY(m,um,M,uM):
   """ Conversion entre les mesures et leurs incertitudes (m,um,M,uM) et les abscisses/ordonnées sur lesquelles sera
   effectuée la modélisation affine """
   X  = 1/m
   uX = 1/m-1/(m+um)
   Y  = M
   uY = uM
   return X,uX,Y,uY

def residuals(coeff,X,uX,Y,uY):
   """ Residuals to be used in lsq fitting """
   err = (Y-(coeff[0]*X+coeff[1])) / np.sqrt((coeff[0]*uX)**2+uY**2)
   return err

# Programme principal
if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales brutes. Un exemple
   # est donné dans la fonction get_data_default()
   # La fonction rawdata2XY() effectue ensuite la conversion entre les données brutes et les abscisses/ordonnées sur
   # lesquelles sera effectué la modélisation affine
   if True:
       m,um,M,uM = get_rawdata_default()
       X,uX,Y,uY = rawdata2XY(m,um,M,uM)
   else:
       m  = np.array([])
       um = np.array([])
       M  = np.array([])
       uM = np.array([])
       X,uX,Y,uY = rawdata2XY(m,um,M,uM)
   # Noms des axes et unites des coefficients du fit y = ax+b
   xlabel = r"$1/b \mathrm{(m^{-1})}$"
   ylabel = r"$L \mathrm{(m)}$"
   a_unit = r"$\mathrm{(m^{2})}$"
   b_unit = r"$\mathrm{(m)}$"
   # Nombre de tirages aléatoires générant des données simulées à partir des mesures expérimentales [supposées suivre
   # des lois normales (avg, std) = (m, um) ou (M, uM)]
   n_MC = 1000

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Modélisation affine
   coeff = np.polyfit(X, Y, 1)  # initial guess
   lsq = scopt.leastsq(residuals, coeff, args=(X,uX,Y,uY), full_output=True)
   if False: print('Best fit parameters: {}'.format(lsq[0]))
   a  = lsq[0][0]             # extraction de la pente
   b  = lsq[0][1]             # extraction de l'ordonnée à l'origine
   ua = np.sqrt(lsq[1][0,0])  # extraction de l'incertitude sur la pente
   ub = np.sqrt(lsq[1][1,1])  # extraction de l'incertitude sur l'ordonnée à l'origine
   chi2r  = np.sum((residuals(lsq[0],X,uX,Y,uY))**2)/(X.size-lsq[0].size)
   uchi2r = np.sqrt(2./(X.size-lsq[0].size))
   print("Modelisation affine y = ax + b, avec :"+"\n"+
         "    a = {} +/- {}".format(a,ua)+"\n"+
         "    b = {} +/- {}".format(b,ub))

   # Plot
   fig = plt.figure(figsize=(10, 8))
   plt.errorbar(X,Y,xerr=uX,yerr=uY,fmt='none',ecolor='red',capsize=10)
   plt.plot(X,a*X+b,'-b',label="modélisation affine y = ax+b\n a={:.2e}\n b={:.2e}".format(a,b))
   plt.xlabel(xlabel,fontsize=15)
   plt.ylabel(ylabel,fontsize=15)
   plt.legend(fontsize=15)
   if True: plt.savefig('donnees.png')
   plt.show()

   # Monte-Carlo
   seed = 1691989345            # seed pour initialiser le generateur de nombres aleatoires
   np.random.seed(seed)         # initialisation du random generator
   lsq_MC = np.empty((n_MC,2))  # initialisation du tableau stockant les paires (a,b)
   # Loop
   for i in range(n_MC):
      mfake = m + um*(np.random.randn(m.size)-1/2)
      Mfake = M + uM*(np.random.randn(M.size)-1/2)
      X,uX,Y,uY = rawdata2XY(mfake,um,Mfake,uM)
      coeff = np.polyfit(X, Y, 1)  # initial guess
      lsq = scopt.leastsq(residuals, coeff, args=(X,uX,Y,uY), full_output=True)
      if False: print('Best fit parameters: {}'.format(lsq[0]))
      lsq_MC[i] = lsq[0]
   # Plot
   fig, axes = plt.subplots(2,1,figsize=(10,12))
   for i,coeff_name in enumerate(['a','b']):
      histo = axes[i].hist(lsq_MC[:,i])
      hist, bins = histo[:2]
      bin_width  = bins[1]-bins[0]
      # Fit de l'histogramme
      mfit, sfit = scstat.norm.fit(lsq_MC[:,i])
      refbins = np.linspace(bins[0],bins[-1])
      best_fit   = scstat.norm.pdf(refbins, mfit, sfit)
      axes[i].plot(refbins, best_fit*np.sum(hist)*bin_width,
                   label='Mod. loi normale\n (avg, std) = ({:4.3e},{:4.3e})'.format(mfit,sfit))
      axes[i].set_title("Histogramme du coeff. '{}' de la modelisation affine".format(coeff_name))
      axes[i].legend()
   if True: plt.savefig('MC.png')
   plt.show()


   

   

   



#-----------------------------------------------------------------------
# Animation d'une onde stationnaire dûe à une réflexion totale
#
# L'onde arrive de la gauche et se réfléchit intégralement
#
# Le première graphe montre seulement l'onde incidente,
# le second seulement l'onde réfléchie et le troisième leur somme
#
# Il est possible de choisir une extrémité droite fixe ou libre
#-----------------------------------------------------------------------
# Renseignements/bugs : Guillaume Dewaele <agreg(at)sci-phy.org>
#-----------------------------------------------------------------------

# Paramètres modifiables

# Nombre de périodes actives
Na = 20

# Nombre de périodes inactives
Ni = 20

# Longueur d'onde
lamb = 1

# Célérité de l'onde
c = 1

# Extrémité fixe (True) ou libre (False)
fixe = True

# Afficher ou non la zone à droite de l'extrémité
droite = False

#-----------------------------------------------------------------------

# Bibliothèques utilisées

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as ani
from itertools import count

#-----------------------------------------------------------------------

def Onde(x, t) :
    x = (-x + c*t)/lamb

    x = x % (Na+Ni)

    if x<Na :
        return np.sin(2*np.pi*x)
    else :
        return 0.0


# coefficient pour la réflexion

coeff = -1.0 if fixe else 1.0

# Détection utilisation hors Pyzo

if '__iep__' not in globals() :
    matplotlib.interactive(False)

# Zones pour les ondes

plt.figure(figsize=(13,9))

X1 = np.linspace(-5.0, 5.0, 500)
X2 = np.linspace(5.0, 10, 500)

# Onde incidente

plt.subplot(2, 1, 1)
plt.xlabel('x [ua]')
plt.ylabel('y [ua]')
#plt.title("Onde incidente")
crv11, = plt.plot(X1, np.vectorize(lambda x : Onde(x, 0.0))(X1), 'r', linewidth=2, label = 'onde incidente')
crv12, = plt.plot(X2, np.vectorize(lambda x : Onde(x, 0.0))(X2), 'r', linewidth=2)

#if droite :
    #plt.axvspan(5.0, 8.0, facecolor='k', alpha=0.3)
plt.xlim(0.0, 10 if droite else 5.0)
plt.ylim(-3, 3)

# Onde réfléchie

#plt.title("Onde réfléchie")
crv21, = plt.plot(X1, np.vectorize(lambda x : coeff*Onde(10.0-x, 0.0))(X1), 'b', linewidth=2, label = 'onde réfléchie')
crv22, = plt.plot(X2, np.vectorize(lambda x : coeff*Onde(10.0-x, 0.0))(X2), 'b', linewidth=2)
plt.axvline(5, linewidth=8, color='gray')

plt.legend()

#if droite :
    #plt.axvspan(5.0, 8.0, facecolor='k', alpha=0.3)
plt.xlim(0.0, 10 if droite else 5.0)
plt.ylim(-3,3)

# Somme des deux ondes

plt.subplot(2, 1, 2)
plt.xlabel('x [ua]')
plt.ylabel('y [ua]')
#plt.title("Somme des deux ondes")
crv31, = plt.plot(X1, np.vectorize(lambda x : Onde(x, 0.0)+coeff*Onde(10.0-x, 0.0))(X1), 'k', linewidth=2, label = 'onde totale')
crv32, = plt.plot(X2, np.vectorize(lambda x : Onde(x, 0.0)+coeff*Onde(10.0-x, 0.0))(X2), 'k', linewidth=2)

#if droite :
    #plt.axvspan(5.0, 8.0, facecolor='k', alpha=0.3)
plt.xlim(0.0, 10 if droite else 5.0)
plt.ylim(-3,3)


plt.axvline(5, linewidth=8, color='gray')
plt.legend()

# Animation

def SizeChanged(ax, old=[]) :
    current = [ ax.bbox.width, ax.bbox.height ]
    if old != current :
        old[:] = current
        return True
    return False

def Update(t) :
    crv11.set_data(X1, np.vectorize(lambda x : Onde(x, t))(X1))
    crv12.set_data(X2, np.vectorize(lambda x : Onde(x, t))(X2))
    crv21.set_data(X1, np.vectorize(lambda x : coeff*Onde(10.0-x, t))(X1))
    crv22.set_data(X2, np.vectorize(lambda x : coeff*Onde(10.0-x, t))(X2))
    crv31.set_data(X1, np.vectorize(lambda x : Onde(x, t)+coeff*Onde(10.0-x, t))(X1))
    crv32.set_data(X2, np.vectorize(lambda x : Onde(x, t)+coeff*Onde(10.0-x, t))(X2))
    if SizeChanged(plt.gca()) :
        plt.gcf().canvas.draw()
    return [crv11, crv12, crv21, crv22, crv31, crv32]

def Init() :
    crv11.set_data(X1, np.ma.array(X1, mask=True))
    crv12.set_data(X2, np.ma.array(X2, mask=True))
    crv21.set_data(X1, np.ma.array(X1, mask=True))
    crv22.set_data(X2, np.ma.array(X2, mask=True))
    crv31.set_data(X1, np.ma.array(X1, mask=True))
    crv32.set_data(X2, np.ma.array(X2, mask=True))
    return [crv11, crv12, crv21, crv22, crv31, crv32]

anim = ani.FuncAnimation(plt.gcf(), Update, count(0.0, c/50.0), interval=20, blit=True, init_func=Init)

# Détection utilisation hors Pyzo

if '__iep__' not in globals() :
    plt.show()


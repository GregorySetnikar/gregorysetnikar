#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Code permettant le tracking des oscillations d'une balle dans un flux vertical
avec une acquisition vidéo, à faire avec une caméra ximea (fichier .xiseq). 
Il faut modifier le nom du fichier .xiseq (séquence d'images), ainsi que la 
fréquence d'acquisition.
Il renvoit d'une part les oscillations verticales et longitudinales de la balle,
une chronophotographie avec le suivi de son centre en rouge, et le spectre des 
oscillations longitudinales.

L'analyse des fréquences d'oscillations permet de remonter par exemple à la vitesse
du fluide, avec la relation St = f*v/D ~0.2 où St est le nombre de Strouhal.

"""

# Importation des librairies
import numpy as np
from PIL import Image
import os
import cv2 as cv
from matplotlib import pyplot as plt
from scipy.signal import periodogram 


# Definition des fonctions
def load_seq(base):
    '''
    Permet de charger la séquence d'image.
    Prend en argument le nom du dossier contenant la séquence,
    et renvoie la séquence d'images chargées

    '''
    paths = os.listdir(base)
    paths = sorted(paths)
    
    seq = []
    for path in paths:
        #if ".tif" not in path:
        #    continue
        seq.append(np.array(Image.open(base+"/"+path)))#[:,:512])
    seq = np.array(seq)
    print("Successfully loaded {} images of shape {}".format(seq.shape[0], seq.shape[1:]))
    
    return seq

def track(seq,i):
    im = seq[i] # 299
    circles = cv.HoughCircles(im, cv.HOUGH_GRADIENT, 1, 100, param1=50, param2=20, minRadius=100, maxRadius=500)
    cx, cy, r = circles[0][0]
    im = cv.circle(im, (int(cx), int(cy)), int(r), 255, 3)
    cv.imshow("result", im)
    cv.waitKey(0)
    cv.destroyAllWindows()
    #return xy
    
def trackAll(seq):
    '''
    Tracking du centre de la balle dans chacune des images de la séquence, à l'aide
    de la méthode de Hough de détection de cercles (dans la librairie opencv).
    Renvoie la liste des coordonnées du centre et le rayon des cercles détectés.

    '''
    ls_cx = []
    ls_cy = []
    ls_r = []
    
    errors = []
    corrects=[]
    for i,im in enumerate(seq):
        circles = cv.HoughCircles(im, cv.HOUGH_GRADIENT, 1, 100, param1=50, param2=30, minRadius=50, maxRadius=300)
        if circles is None:
            errors.append(i)
            continue
        corrects.append(i)
        cx, cy, r = circles[0][0]
        ls_cx += [cx]
        ls_cy += [cy]
        ls_r += [r]
    cx = np.array(ls_cx)
    cy = np.array(ls_cy)
    r = np.array(ls_r)
    #print(cx)
    #print(cy)
    #print(r)
    #if len(errors)!=0:
    #    print('Circle detection errors in images {}'.format(errors))
    #print(corrects)
    return cx, cy, r

def plot(f, cx, cy, r):
    
    '''
    Trace les oscillations de la balle
    '''
    
    ##Echelle
    t=np.arange(len(cx))/f
    R=np.mean(r)
    scale=3.93/R
    cx=(cx-np.mean(cx))*scale
    cy=(cy-np.mean(cy))*scale
    #plot
    plt.plot(t, cx, label='Oscillations transverses')
    plt.plot(t, cy, label='Oscillations longitudinales')
    plt.title('Suivi des positions du centre de la balle', fontsize=13)
    plt.xlabel('Temps (s)', fontsize=10)
    plt.ylabel('Ecart par rapport à la position moyenne (cm)', fontsize=10)
    plt.legend()
    
    #plt.scatter(cx, cy)
    return

def chronophoto(seq, cx, cy, r):
    '''
    
    Réalise la chronophotographie de la séquence d'image, centrée sur le centre 
    de la balle.
    '''
    
    
    slices = np.array([seq[i,:,int(cx[i])] for i in range(len(seq))])
    print(np.std(cx), np.std(cy), np.mean(cx), np.mean(cy))
    slices = slices.T
    #plt.subplot(2, 1, 2)
    print(slices.shape)
    l=len(cy)
    plt.imshow(slices[:800,:], cmap="gray")#, axes=None)
    #plt.plot(cx-np.mean(cx)+750)
    #t=(np.arange(l)/25)[l//3:(2*l)//3] 
    plt.plot(cy,color='r')
    plt.title('Chronophotographie des oscillations\nlongitudinales de la balle ', fontsize= 18)
    plt.xlabel('Frames', fontsize=15)
    plt.ylabel('Position ', fontsize= 15)
    #return res
    
def spectre(data,f):
    '''
    Calcule et trace le spectre d'un signal data avec une fréquence 
    d'échantillonage 

    '''
    fd, pd = periodogram(data, fs=f)
    i=np.argmax(pd)
    fmax= fd[i]
    plt.plot(fd[:90],pd[:90])
    plt.xlabel('Fréquences (Hz)', fontsize= 15)
    plt.ylabel('Densité spectrale', fontsize= 13)
    plt.title('Spectre des oscillations longitudinales ', fontsize= 17)
    #plt.annotate('Fréquence des oscillations de {} Hz'.format(round(fmax,2))
                 #, xy=(fd[i],pd[i]),xytext=(0.2,0.7),
                 #textcoords='axes fraction',
                 #arrowprops=dict(facecolor='black', shrink=0.05),
                 #horizontalalignment='left', verticalalignment='top')    
    plt.show()

def circle(i):
    x=round(cx[i]); y=round(cy[i]) ; R=round(r[i]) ; im=seq[i]
    
    im_col= cv.cvtColor(im,cv.COLOR_GRAY2BGR)
    im_c=cv.circle(im_col,(x,y),R,(0, 0,255),2)
    im_c=cv.line(im_c,(x-10,y),(x+10,y),(255,0,0),2)
    im_c=cv.line(im_c,(x,y-10),(x,y+10),(255,0,0),2)
    plt.imshow(im_c)
    plt.axis('off')
    plt.show()
    cv.imwrite('Image_circle.png',im_c)
    #plt.savefig('Cercle({})'.format(i))
    

# Programme principal
if __name__ == "__main__":
    
    
    #Chargement de la séquence d'images
    seq = load_seq("./Vert2_50Hz_30s_files")
    f=50
    #track(seq)
    
    if True :
        #Récupération des coordonnées du centre de la balle
        cx, cy, r = trackAll(seq)
        
        #tracé des oscillations 
        plt.figure(1)
        plot(f, cx, cy, r)
        
        #Tracé du spectre des oscillations longitudinales
        plt.figure(2)
        spectre(cy,f)
        
        #Tracé de la chronophotographie
        plt.figure(3)
        chronophoto(seq, cx, cy, r)
        
    if False:
        track(seq)
 

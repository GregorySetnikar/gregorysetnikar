#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Angle de Brewster
Auteur : Francis Pagaud

"""
# Importation des librairies
import numpy as np
import scipy.optimize as spo
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
from matplotlib import patches
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})

# Définition des fonctions
def tt(i, n1, n2) :
    '''Obtient l'angle de refraction'''
    
    return np.arcsin(n1/n2*np.sin(i))

def r(i, n1, n2) :
    """ 
    Calcul de coefficient de reflexion
    """
    ttt = tt(i, n1, n2)
    return (np.tan(i-ttt)/np.tan(i+ttt))**2

if __name__=="__main__":
    
    #--------------------------------------------#
    # Valeur initiales des différentes grandeurs #
    #--------------------------------------------#
    
    x1 = np.array([-1, 0])          # Coordonnées du rayon incident
    x2 = np.array([0, 1])           # Coordonnées du rayon réfléchi

    n1 = 1                          # Indice optique du premier milieu
    n2 = 1.5                        # Indice optique du second milieu

    i = np.pi/4                     # Angle incident
    t = tt(i, n1, n2)               # Angle réfracté

    ang_step = 0.005
    theta = np.arange(0.005, np.pi/2, ang_step)
    theta_r = tt(theta, n1, n2)


    theta_affich = np.arange(0.005, np.pi/2, ang_step)
    x_theta_affich = -0.1*np.sin(theta[0:round(i/ang_step)])
    y_theta_affich = 0.1*np.cos(theta[0:round(i/ang_step)])



    #------#
    # Plot #
    #------#
    
    
    fig, ax = plt.subplots()
    plt.suptitle('Brewster')
    ax.remove()
    # Fenêtre des rayons lumineux
    axe_refr = plt.axes([0.1, 0.25, 0.37, 0.65])        #creation de la fenetre des rayons lumineux
    axe_refr.set_xlabel('x (m)')
    axe_refr.set_ylabel('y (m)')
    axe_refr.add_artist(patches.Rectangle((-1,-1), 2, 1, facecolor = 'gray', fill = True, zorder = 0))
    axe_refr.axis([-1, 1, -1, 1])
    axe_refr.text(-0.95, 0.07, 'Air, $n_1 = 1$')
    axe_refr.text(-0.95, -0.15, 'Diélectrique, $n_2$')

    
    # Fenêtre du calcul du temps de trajet
    axe_R = plt.axes([0.57, 0.25, 0.37, 0.65])
    axe_R.set_xlabel('$\Theta$')
    axe_R.set_ylabel('$R$')
    axe_R.axis([0, 80, 0, 0.4])

    R = r(theta, n1, n2)

    # Tracé des rayons lumineux
    l1, = axe_refr.plot(x1, [1/np.tan(i), 0], '-r', lw = 4)      
    l2, = axe_refr.plot(x2, [0, 1/np.tan(i)], '-r', lw = 4, alpha = np.sqrt(r(i, n1, n2)))
    l3, = axe_refr.plot(x2, [0, 1/-np.tan(t)], '-r', lw = 4, alpha = np.sqrt(1-r(i, n1, n2)))
    interf, = axe_refr.plot([-1, 1],[0, 0], '-k', lw=3)
    sep, = axe_refr.plot([0, 0], [-0.3, 0.3], '--r', lw=3)
    angle, = axe_refr.plot(x_theta_affich, y_theta_affich, '-k', lw=2, zorder=0)
    axe_refr.text(-0.1, 0.13, '$\Theta$', color = 'k')

    # Tracé de la courbe de coefficient de reflexion
    la, = axe_R.plot(theta*180/np.pi, R, '-r', linewidth = 4)    #Points des rayons
    M, = axe_R.plot(i*180/np.pi, r(i, n1, n2), 'ob', markersize = 20, markeredgewidth = 1)

    # Sliders pour modifier les parmètres
    axi = plt.axes([0.12, 0.025, 0.78, 0.03])	# Slider M, on fait varier le param s
    axn2 = plt.axes([0.12, 0.075, 0.78, 0.03])	# Slider M, on fait varier le param s
    si = Slider(axi, '$\Theta$ (°)', 1, 90, valinit=i/np.pi*180, valfmt='%0.1f')
    sn2 = Slider(axn2, '$n_2$', 1, 2, valinit=n2, valfmt='%0.2f')


    def update(val):
        """
        Mise à jour des différents tracés lorsque les sliders sont modifiés
        """
        thetaval = si.val/180*np.pi
        n2val = sn2.val
        thetarval = tt(thetaval, n1, n2val)
        theta_affich = np.arange(0.005, thetaval, 0.005)
        
        l1.set_ydata([1/np.tan(thetaval), 0] )
        l2.set_ydata([0, 1/np.tan(thetaval)] )
        
        angle.set_data(-0.1*np.sin(theta[0:round(thetaval/ang_step)]), 0.1*np.cos(theta[0:round(thetaval/ang_step)]))
        
        if thetarval < np.pi/2 :
            l3.set_ydata([0, 1/-np.tan(thetarval)])
        
        M.set_xdata(thetaval*180/np.pi)
        M.set_ydata(r(thetaval, n1, n2val))
        
        l2.set_alpha( np.sqrt(r(thetaval, n1, n2val)) )
        l3.set_alpha( np.sqrt(1-r(thetaval, n1, n2val)) )
        
        Rnew = r(theta, n1, n2val)
        la.set_ydata(Rnew)
        
        fig.canvas.draw_idle()

    # Update des valeurs des sliders
    si.on_changed(update)
    sn2.on_changed(update)
    resetax = plt.axes([0.01, 0.08, 0.06, 0.04])
    button = Button(resetax, 'Reset', hovercolor='0.975')
    
    def reset(event):
        si.reset()
        sn2.reset()
    button.on_clicked(reset)
    
    plt.show()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Résolution graphique pour le cas d'une réaction endothermique


pour une réaction A-> P et une réaction d'ordre 1 par rapport à chacun des réactifs


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""


# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.constants as sc
import scipy.optimize as opti
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import scipy.integrate as integrate
from scipy import interpolate
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True
# Definition des fonctions
def KT(T,A,Ea,B,Eb):
    ka=A*np.exp(-Ea/(sc.R*T))
    kb=B*np.exp(-Eb/(sc.R*T))
    return ka/kb

def derxttau(T,dT,A,Ea,B,Eb,tau,T2,gradX):
    indixT = np.argmin(np.abs(T2-T))
    return gradX[indixT] 


def r(T,A,Ea,B,Eb,x):
    K = KT(T,A,Ea,B,Eb)
    Xeq = K/(1+K)
    ka=A*np.exp(-Ea/(sc.R*T))
    return ka*(1-x/Xeq)

def invr(x,T,A,Ea,B,Eb):
    return 1/r(T,A,Ea,B,Eb,x)

def xttau(T,A,Ea,B,Eb,tau):
    K = KT(T,A,Ea,B,Eb)
    ka=A*np.exp(-Ea/(sc.R*T))
    Xeq = K/(1+K)
    return Xeq*(1-np.exp(-ka*tau/Xeq))

if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RP-endo.svg"
    #Range of values where the data will be evaluated
    x1 =np.logspace(-20,np.log10(0.1),1001)
    x2 =np.linspace(0.1+1e-4,1,1001)
    x =np.concatenate(([0],x1,x2))
    #print(x)
    x=np.linspace(0,1,1000)
    T,dT =np.linspace(200,500,1000,retstep = True)
    tauss=np.logspace(-3,3,1000)

    xx,TT = np.meshgrid( x, T, indexing='ij')

    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)#,  width_ratios=(1, 1), height_ratios=(2, 1), left=0.08, right=0.95, bottom=0.05, top=0.95, wspace=0.18, hspace=0.3
    ax2 = fig.add_subplot(gs[0,0])
 


    B = 2.95e7
    A = 1.57e18
    Eb = 46.4e3
    Ea = 118.4e3



    K = KT(T,A,Ea,B,Eb)
    Xeq = K/(1+K)
    ToptYield = []
    optYield = []
    fullR= r(TT,A,Ea,B,Eb,xx)
    derTr = np.gradient(fullR,dT,axis=1) 
    
    T2,dT2 =np.linspace(250,420,1000,retstep = True)

    Tpot = []
    rTpot = []

    #compute the value which maximizes the yield
    for idx,xsol in enumerate(x):
        iTopt = np.argmax(fullR[idx,:])
        Topt = T[iTopt]
        Tpot.append(Topt)
    rTpot = r(np.asarray(Tpot),A,Ea,B,Eb,x)

    Tpot=np.asarray(Tpot)

    taus=[]
    #tau opti pour une conversion donnée : on intègre numériquement l'inverse de la vitesse le long de la POT
    for idx,xsol in enumerate(x[1:]):
        tau = integrate.simps(1/rTpot[x<xsol], x[x<xsol])
        taus.append(tau)
    taus= np.asarray(taus)

   #plot a vertical line at zero to give a hint on where it lies
    #ax1.axhline(1,color='#cccccc')
    colors = ['#80cdc1','#35978f','#01665e','#003c30','#dfc27d','#bf812d','#8c510a','#543005']    
    ls=[(0, (3, 1, 1, 1, 1, 1)),':','--','-','-.','-','-','-','-']

    liste = [260,320,340,360,370,380,390,400]

    liste = [1e-4,1e-3,0.01,0.1,0.5,1]
    for i,el in enumerate(liste) :
        ax2.plot(T,xttau(T,A,Ea,B,Eb,el),ls=ls[i],lw=1.5,label = '{}'.format(el), color = colors[i])


    ax2.plot(T,Xeq,lw=2,label='$X_{eq}(T)$',color='#543005') 


    ax2.legend(loc='upper left')
    #labels for the axis and title of the graph
    ax2.set_xlabel('$T$')
    ax2.set_ylabel('$X$')
    #set limits to the plotted data (to crop for example)
    ax2.set_ylim(0,1)
    ax2.set_xlim(min(T),max(T))
    #show or hide the bounding axes
    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


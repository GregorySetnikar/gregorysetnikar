#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Visualisation de la notion de cohérence temporelle dans les anneaux du Michelson
à travers le tracé des profils d'intensité des interferences de deux faisceaux
dont les longueurs d'ondes sont proches.
Auteur : Agrégatifs de Lyon 2022-2023
"""


# Importation des librairies
import numpy as np

import matplotlib.pyplot as plt
plt.rc('font', size=14)

from matplotlib.widgets import Slider, Button
# Definition des fonctions

def delta(r, e, f = 1):
    """
    Calcul de déphasage en lame d'air pour le michelson où
    l'on a fait l'approximation cos x = 1 - x^2/2
    """
    return 2 * e * np.cos(1 - (r/f)**2)

def intensite(r, lambd, e, Io = 1, f=1):
    """
    Intensite en fonction de la distance r au centre de la figure d'intereference
    """
    return 2*Io * (1+np.cos(2*np.pi*delta(r, e, f)/lambd))

def anneaux(r, lambd, delta, e):
    """
    Anneaux observes pour 2 sources mono chromatiques de longueurs d'ondes lambd
    et lambd + delta
    """
    X, Y = np.meshgrid(r, r)
    R = np.sqrt(X**2+ Y**2)
    I1 = intensite(R, lambd, e)
    I2 = intensite(R, lambd + delta, e)
    return I1 + I2

if __name__=='__main__':

    # Paramètres
    r = np.linspace(-0.1, 0.1, 500)
    lambd = 589e-9  # Ici la longueur d'onde de la raie du sodium
    delta_lambd = 1e-9
    init_e = 1e-4

    # Profils d'intensité initiaux
    I = intensite(r, lambd, init_e)
    I2 = intensite(r, lambd+delta_lambd, init_e)

    # Anneaux initiaux
    somme = anneaux(r, lambd, delta_lambd, init_e)

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))
    plt.subplots_adjust(bottom=0.22)
    plt.suptitle("Cohérence temporelle interférences (Michelson)")

    # Profils d'intensités en fonction de la distance au centre
    line00, = ax[0].plot(r, I, label = "Profil $\lambda_0$")
    line01, = ax[0].plot(r, I2, label = "Profil $\lambda_0 + \delta \lambda$")
    ax[0].legend(loc='upper left')
    ax[0].set_xlabel("r (m)")
    ax[0].set_ylabel("I(r)")
    ax[0].set_xlim([0, np.max(r)])

    # Anneaux observés
    dx = (r[1]-r[0])/2
    line1 = ax[1].imshow(somme, extent = [-r[-1]-dx, r[-1] + dx,-r[-1]-dx, r[-1] + dx])
    ax[1].set_yticklabels([])
    ax[1].set_ylabel("Y")
    ax[1].set_xlabel("X (m)")

    # Slider pour pouvoir chariotter (augmenter la distance entre les miroirs)
    axe = fig.add_axes([0.2, 0.08, 0.6, 0.03])
    e_slider = Slider(
        ax=axe,
        label='e (m)',
        valmin=1e-2,
        valmax=1,
        valinit=init_e*1e3,
    )

    # Slider pour augmenter la différence de longueur d'onde
    axlambd = fig.add_axes([0.2, 0.02, 0.6, 0.03])
    lambd_slider = Slider(
        ax=axlambd,
        label='$\delta \lambda$ (nm)',
        valmin=0.1,
        valmax=10,
        valinit=delta_lambd*1e9,
    )


    def update(val):
        """
        Update des courbes avec les nouvelles valeurs des sliders
        """
        I = intensite(r, lambd, e_slider.val*1e-3)
        I2 = intensite(r, lambd+lambd_slider.val*1e-9, e_slider.val*1e-3)
        line01.set_ydata(I2)
        line00.set_ydata(I)
        line1.set_data(anneaux(r, lambd, lambd_slider.val*1e-9, e_slider.val*1e-3))
        ax[0].autoscale_view()
        ax[1].autoscale_view()


    e_slider.on_changed(update)
    lambd_slider.on_changed(update)
    plt.show()

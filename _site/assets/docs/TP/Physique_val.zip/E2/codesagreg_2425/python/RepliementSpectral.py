#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import os
import sys

'''
Illustration de l'echantillonnage d'un signal et des effets de repliement spectral.
Le programme trace un signal de frequence 440 Hz, sa version echantillonnee et la fft du signal echantillonne.
L'utilisateur peut changer la frequence d'echantillonnage ('fe1') pour constater les effets sur le spectre.
'''


#change directory to current directory
plt.style.use('bmh')


#signal analogique: sinus à 440 Hz
def f(t):
    return np.sin(2*np.pi*440*t)


t_tot = 61/440 #temps total n/440 où n est le nombre de périodes d'oscillations
disp = 10 #nombre d'oscillations affichées

#signal réel
t=np.linspace(0,t_tot,50000)
y=f(t)
freq = np.fft.rfftfreq(len(t), t[1]-t[0])
sp = np.abs((np.fft.rfft(y)))**2
sp /= sp.max()

#echantillonnage
fe1=7000
t_1=np.arange(0,t_tot,1/fe1)
y_1=f(t_1)

freq_1 = np.fft.fftfreq(len(t_1), 1/fe1)
sp_1 = np.abs((np.fft.fft(y_1)))**2
sp_1 /= sp_1.max()


xlabel = 't[s]'
ylabel = 'Signal [a.u.]'
legend = 'legend'
title = 'titre'

if __name__ == "__main__":

    # construction de la figure
    f, (ax1, ax2) = plt.subplots(1,2)
    plt.grid(color='w', linestyle='solid')

    # décorations
    ax1.set_title('Signal temporel', fontsize=17)
    ax1.set_xlabel(xlabel,fontsize=17)
    ax1.set_ylabel(ylabel,fontsize=17)

    ax2.set_title('Spectre', fontsize=17)
    ax2.set_xlabel('Fréquence f [Hz]',fontsize=17)
    ax2.set_ylabel('Spectre [u.a.]',fontsize=17)


    #plot
    ax1.plot(t, y, label='sinusoide 440 Hz', zorder =1)

    ax1.scatter(t_1, y_1, label=r'échantillon à $f_e=$'+'{} Hz'.format(fe1), color = 'C1', s= 10, marker = 'o', zorder = 5)
    ax1.set_xlim((0,disp/440))
    ax1.set_ylim((-1.5,2.5))
    ax1.legend(prop={'size': 15})

    ax2.plot(freq_1[freq_1>=0], sp_1[freq_1>=0], zorder = 2,  color = 'C1')
    ax2.plot(freq_1[freq_1<0], sp_1[freq_1<0], zorder = 2,  color = 'C1')


    #police des graduations
    plt.tick_params(axis='x', labelsize=15)
    plt.tick_params(axis='y', labelsize=15)


    #affichage du plot

    plt.show()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Influence du rapport stoechiométrique M sur le temps de passage dans un RP nécessaire pour avoir un taux de conversion donné.

pour une réaction A+B -> P avec nB=M*nA et une réaction d'ordre 1 par rapport à chacun des réactifs

tracé en fonction de M pour différents avancements


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def rapportTauMtau1(x,M):
    return 1/(M-1)*np.log((M-x)/(M*(1-x)))*(1-x)/x
# Programme principal
if __name__ == "__main__":
    #Name of the output file
    fileOutput = "rapport_tau_stoechio-m-RP.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(1e-3,1-1e-3,1000)
    M =np.linspace(1+1e-5,20,1000)
    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)
    ax1 = fig.add_subplot(gs[0,0])
    #plot a vertical line at zero to give a hint on where it lies
    ax1.axhline(0,color='#cccccc')
    colors = ['#c51b7d','#e9a3c9','#41ab5d','#005a32']
    ls=[':','--','-','-.',(0, (3, 1, 1, 1, 1, 1))]
    liste = [0.1,0.5,0.9,0.999]
    for i,el in enumerate(liste) :
        ax1.plot(M,rapportTauMtau1(el,M), color = colors[i],ls=ls[i] ,label='$x = {}$'.format(el))


    ax1.legend(loc='upper left')
    ax1.set_yscale('log')
    #labels for the axis and title of the graph
    ax1.set_xlabel('$M$')
    ax1.set_ylabel('$\dfrac{\\tau_{M}}{\\tau_{1}}$')
    #set limits to the plotted data (to crop for example)
    ax1.set_xlim(min(M),max(M))
    #show or hide the bounding axes
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    plt.savefig(fileOutput)
    plt.show()


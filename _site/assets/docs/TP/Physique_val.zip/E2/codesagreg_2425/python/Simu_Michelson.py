#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Auteur : ClÃ©ment de la Salle
# AgrÃ©gation de physique, ENS de Lyon, 2019-2020
#
# Vu qu'on n'a pas moyen de manipuler du vrai matos (Covid oblige), voici une roue de secours pour le Michelson...
# Un peu de doc Ã  la fin pour comprendre le fonctionnement

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
from time import time
from matplotlib.widgets import Slider, Button, RadioButtons

## ParamÃ¨tres

# La plupart de ces paramÃ¨tres ont Ã©tÃ© optimisÃ©s mais on peut toujours s'amuser Ã  les modifier...

Lx, Ly = 20, 20             # Taille de l'Ã©cran
lo = 380                    # Longueur d'onde initiale
d = .2                      # Double de la distance de la source aux miroirs
N = 500                     # Nombre de pixel dans chaque direction. Ce nombre peut Ãªtre diminuÃ© si le programme devient trop lent (ajout de nombreuses raies)
w = 2e5                     # Conversion des longueurs d'onde Ã  l'Ã©chelle de l'interfÃ©romÃ¨tre...
monochro = True             # Initialement, la source est monochromatique si monochro = True
source_ponctuelle = True    # Ã‡a j'avoue qu'il va me falloir une grosse dÃ©ter pour prendre en compte l'Ã©tendue spatiale. Pour l'instant ce boolÃ©en ne sert Ã  rien.


## Michelson

source_lo = []
couleurs = []

class color :
    
    '''
    Classe permettant de traiter les couleurs... Finalement je n'en n'ai pas eu besoin mais je la laisse au cas oÃ¹ :)
    On peut donner une couleur RVB en entrÃ©e, ou bien TLS en ajoutant l'argument 'TLS'.
    La fonction d'initialisation permet de calculer les autres coordonnÃ©es (RVB to TLS ou TLS to RVB)
    Les fonctions set_ permettent de changer un paramÃ¨tre sans affecter les autres du groupe (modifier R sans bouger V, B ou bien modifier L sans bouger T,S)
    La fonction add permet d'ajouter des couleurs entre elles (selon un algorithme sorti de ma tÃªte) renvoie une couleur (classe color) ou bien simplement les coordonnÃ©es RVB dans un tableau si on donne en plus l'argument output = 'RVB')
    '''
    
    def __init__(self, a, b, c, *args) :
        
        if 'TLS' in args :
        
            self.T, t = a, a
            self.L, l = b, b
            self.S, s = c, c
            
            if l < 1/2 : q = l * (1 + s)
            else : q = l + s - l * s
            
            p = 2 * l - q
            RVB = []
            for tC in [t + 1/3, t, t - 1/3] :
                
                if tC < 0 : tC += 1
                elif tC > 1 : tC -= 1
                
                if tC < 1/6 : RVB.append(p + ((q - p) * 6 * tC))
                elif tC >= 1/6 and tC < 1/2 : RVB.append(q)
                elif tC >= 1/2 and tC < 2/3 : RVB.append(p + ((q - p) * 6 * (2/3 - tC)))
                else : RVB.append(p)
            
            [self.R, self.V, self.B] = RVB
            
            
        else :
        
            self.R = a
            self.V = b
            self.B = c
            
            M = max(a, b, c)
            m = min(a, b, c)
            
            if M == m : t = 0
            elif M == a : t = 60 * abs(b - c) / (M - m)
            elif M == b : t = 60 * abs(c - a) / (M - m) + 120
            elif M == c : t = 60 * abs(a - b) / (M - m) + 240
            t = t / 360
            
            l = 1/2 * (M + m)
            
            if M == m : s = 0
            elif l <= 1/2 : s = (M - m) / (2 * l)
            elif l > 1/2 : s = (M - m) / (2 - 2 * l)
            s = s
            
            self.T = t
            self.L = l
            self.S = s
        
        self.RVB = np.array([self.R, self.V, self.B])
        self.TLS = np.array([self.T, self.L, self.S])
        self.frac_RVB = self.RVB / self.RVB.sum()
    
    def add(self, *colors, **kwargs) :
        
        output_color = True
        if 'output' in kwargs :
            if kwargs['output'] == 'RVB' or kwargs['output'] == 'rvb' :
                output_color = False
        
        colors = [self] + list(colors)
        C = np.array([col.RVB for col in colors])
        D = C / C.sum(axis = 0)
        D[np.isnan(D)] = 0
        C = (C * D).sum(axis = 0).astype(np.float)        
        if output_color : return color(*C)
        else : return C
    
    def set_R(self, R) :
        self.__init__(R, self.V, self.B)
    def set_V(self, V) :
        self.__init__(self.R, V, self.B)
    def set_B(self, B) :
        self.__init__(self.R, self.V, B)
    def set_T(self, T) :
        self.__init__(T, self.L, self.S, 'TLS')
    def set_L(self, L) :
        self.__init__(self.T, L, self.S, 'TLS')
    def set_S(self, S) :
        self.__init__(self.T, self.L, S, 'TLS')


def WavelengthToRGB(Wavelength):
    
    '''Convertit une longueur d'onde en couleur RVB (fonction trouvÃ©e sur Internet'''
    
    Gamma = 0.80
    IntensityMax = 255
    
    def Adjust(Color, Factor):
        if Color == 0: return 0
        else: return round(IntensityMax * pow(Color * Factor, Gamma))
 
    if 380 <= Wavelength <= 440:
        R = -(Wavelength - 440) / (440 - 380)
        G = 0
        B = 1
    elif 440 <= Wavelength <= 490:
        R = 0
        G = (Wavelength - 440) / (490 - 440)
        B = 1
    elif 490 <= Wavelength <= 510:
        R = 0
        G = 1
        B = -(Wavelength - 510) / (510 - 490)
    elif 510 <= Wavelength <= 580:
        R = (Wavelength - 510) / (580 - 510)
        G = 1
        B = 0
    elif 580 <= Wavelength <= 645:
        R = 1
        G = -(Wavelength - 645) / (645 - 580)
        B = 0
    elif 645 <= Wavelength <= 780:
        R = 1
        G = 0
        B = 0
    else:
        R = 0
        G = 0
        B = 0
 
    if 380 <= Wavelength <= 420: Factor = 0.3 + 0.7 * (Wavelength - 380) / (420 - 380)
    elif 420 <= Wavelength <= 701: Factor = 1
    elif 701 <= Wavelength <= 780: Factor = 0.3 + 0.7 * (780 - Wavelength) / (780 - 700)
    else: Factor = 0
 
    R = Adjust(R, Factor)
    G = Adjust(G, Factor)
    B = Adjust(B, Factor)    
 
    return R / 255, G / 255, B / 255


def add_figure_interference(*figures) :
    
    '''Pour ajouter les figures d'interfÃ©rences de diffÃ©rentes couleurs (toujours avec mon algorithme)'''
    
    C = np.array(figures)
    D = C / C.sum(axis = 0)
    D[np.isnan(D)] = 0
    return (C * D).sum(axis = 0).astype(np.float)


def tracer(event) :
    
    '''Fonction principale qui modifie l'image sur l'Ã©cran'''
    
    # Calcul des positions des sources secondaires
    S1 = np.array([-2 * se.val, 0, 0])
    S2 = d * (np.array([1 - np.cos(sangle.val), np.sin(sangle.val), 0]))
    
    # Calcul des distances entre chaque point de l'Ã©cran et chaque source
    r1 = ecran - S1
    r1 = np.sqrt(r1[:, :, 0] ** 2 + r1[:, :, 1] ** 2 + r1[:, :, 2] ** 2)
    r2 = ecran - S2
    r2 = np.sqrt(r2[:, :, 0] ** 2 + r2[:, :, 1] ** 2 + r2[:, :, 2] ** 2)
    
    if monochro : # Pour une source monochromatique
        if source_ponctuelle :
            intensite = 1/2 * (1 + np.cos(2 * np.pi / slo.val * (r2 - r1) * w))
        total = np.kron(intensite, np.array(WavelengthToRGB(slo.val))).reshape(N, N, 3)
    
    else : # Pour une source polychromatique
        if len(source_lo) >= 1 :
            figures = []
            for l, c in zip(source_lo, couleurs) :
                if source_ponctuelle :
                    intensite = 1/2 * (1 + np.cos(2 * np.pi / l * (r2 - r1) * w))
                figures.append(np.kron(intensite, c.RVB).reshape(N, N, 3))
            total = add_figure_interference(*figures)
        else : total = np.zeros((N, N, 3))
    
    total[total > 1] = 1.
    image.set_data(total)
    
    plt.draw()


def change_lo(event) :
    
    global source_lo, couleurs
    
    lo = slo.val
    selec_lo.set_xdata([lo, lo])
    preview.set_data([[np.array(WavelengthToRGB(lo))]])
    tracer(1)
    
    plt.draw()


def change_L(event) :
    
    global ecran
    value = sL.val
    (Sx, Sy) = (x.shape, y.shape)
    ecran = np.concatenate((np.ones((N, N, 1)) *value, np.concatenate((x.reshape(Sx, 1), y.reshape(Sy, 1)), axis = 2)), axis = 2)
    tracer(1)

def ajout_lo(event) :
            
    source_lo.append(slo.val)
    couleurs.append(color(*WavelengthToRGB(slo.val)))
    raies.append(ax_spectre_source.plot([slo.val, slo.val], [0, 1], color = couleurs[-1].RVB)[0])
    tracer(1)
    
def retrait_lo(event) :
    
    global source_lo, couleurs, raies
        
    source_lo = source_lo[:raie_selec] + source_lo[raie_selec + 1:]        
    couleurs = couleurs[:raie_selec] + couleurs[raie_selec + 1:]        
    raies = []
    ax_spectre_source.cla()
    ax_spectre_source.set_xlim(380, 780)
    ax_spectre_source.set_ylim(0, 1)
    for l, c in zip(source_lo, couleurs) :
        raies.append(ax_spectre_source.plot([l, l], [0, 1], color = c.RVB)[0])
    tracer(1)
    

def gerer_spectre(event) :
    
    global raie_selec
    
    if event.xdata > 380 and len(source_lo) > 0 and event.ydata > 0 :
        
        k = np.abs(np.array(source_lo) - event.xdata).argmin()
        for i in range(len(raies)) :
            raies[i].set_linewidth(1.5)
        raies[k].set_linewidth(10)
        raie_selec = k
    
    tracer(1)

def touche(event) :
    
    if event.key == 'a' : ajout_lo(1)
    elif event.key == 'z' : retrait_lo(1)

def mono_poly(event) :
    
    global monochro
    monochro ^= True
    tracer(1)

fig = plt.figure()
ax = fig.add_subplot(121, xlim = (-Lx / 2, Lx / 2), ylim = (-Ly / 2, Ly / 2))
position = list(ax.get_position().bounds)
position[2] += 0.15
ax.set_position(position)
ax.set_aspect('equal')

ax_spectre = fig.add_axes([.6, .51, .28, .1])
ax_preview_color = fig.add_axes([.92, .51, .05, .1])
ax_preview_color.xaxis.set_visible(False)
ax_preview_color.yaxis.set_visible(False)
ax_spectre.yaxis.set_visible(False)
map = np.zeros((1, 500, 3))
for k, l in enumerate(np.linspace(380, 780, 500)) :
    map[0, k] = np.array(WavelengthToRGB(l))

ax_spectre.imshow(map, aspect = 'auto', extent = (380, 780, -1, 0))
selec_lo, = ax_spectre.plot([lo, lo], [-1, 0], ':', color = 'black', linewidth = 2)

slo = Slider(ax_spectre, r'$\lambda$', 380, 780, alpha = 0, linestyle = ':', valstep = 1)
slo.on_changed(change_lo)

preview = ax_preview_color.imshow([[np.array(WavelengthToRGB(lo))]])

ax_spectre_source = fig.add_axes([.6, .41, .28, .1])
ax_spectre_source.xaxis.set_visible(False)
ax_spectre_source.yaxis.set_visible(False)
ax_spectre_source.set_facecolor('black')
ax_spectre_source.set_xlim(380, 780)
ax_spectre_source.set_ylim(0, 1)
raies = []

ax_ajout_lo = fig.add_axes([.92, .46, .05, .05])
ax_ajout_lo.set_xlim(0, 1)
ax_ajout_lo.set_ylim(.5, 1)
bouton_ajout_lo = Button(ax_ajout_lo, '+')
bouton_ajout_lo.on_clicked(ajout_lo)
ax_retrait_lo = fig.add_axes([.92, .41, .05, .05])
ax_retrait_lo.set_xlim(0, 1)
ax_retrait_lo.set_ylim(0, .5)
bouton_retrait_lo = Button(ax_retrait_lo, '-')
bouton_retrait_lo.on_clicked(retrait_lo)
fig.canvas.mpl_connect('key_press_event', touche)
fig.canvas.mpl_connect('button_press_event', gerer_spectre)

ax_mono_poly = fig.add_axes([.69, .34, .12, .05])
bouton_monopoly = Button(ax_mono_poly, 'Mono / Polychromatique')
bouton_monopoly.on_clicked(mono_poly)

ax_chariot = fig.add_axes([.6, .83, 0.28, .04])
se = Slider(ax_chariot, r'$e$', -.1, .1, valinit = 0)
se.on_changed(tracer)

ax_angle = fig.add_axes([.6, .76, 0.28, .04])
sangle = Slider(ax_angle, r'$\theta$', -.4, .4, valinit = 0)
sangle.on_changed(tracer)

ax_L = fig.add_axes([.6, .69, 0.28, .04])
sL = Slider(ax_L, r'$L$', 0, 50, valinit = 10)
sL.on_changed(change_L)

# ax_R = fig.add_axes([.6, .27, 0.28, .04])
# sR = Slider(ax_R, r'$R$', 0, 5, valinit = 1)
# sR.on_changed(tracer)

x, y = np.mgrid[-Lx/2:Lx/2:complex(0, N), -Ly/2:Ly/2:complex(0, N)]
value = sL.val
Sx, Sy = x.shape, y.shape
ecran = np.concatenate((np.ones((N, N, 1)) * value, np.concatenate((x.reshape(* Sx, 1), y.reshape(* Sy, 1)), axis = 2)), axis = 2)
image = ax.imshow(np.zeros((N, N, 3)), extent = (-Lx / 2, Lx / 2, -Ly / 2, Ly / 2))

# mng = plt.get_current_fig_manager()       # Vous pouvez dÃ©commenter Ã§a si vous utilisez 'TkAgg'
# mng.window.state('zoomed')
plt.show()


## Doc

# Interface :
#
#   - Ã‰cran : il occupe toute la partie gauche et donne la figure d'interfÃ©rence observÃ©e
#
#   - ParamÃ¨tres du Michelson :
#       e = Chariotage
#       theta = Angle des miroir (theta = 0 pour lame d'air)
#       L = Position de l'Ã©cran (source ponctuelle donc on peut observer les interfÃ©rences partout)
#
#   - Construction de la source : Il existe deux modes (switcher avec le bouton mono/polychromatique)
#       /Mode monochromatique/
#           Les modifications sont visibles directement sur l'Ã©cran. Faire glisser ou cliquer sur le spectre pour choisir une longueur d'onde.
#       /Mode polychromatique/
#           SÃ©lectionner une longueur d'onde sur le spectre et cliquer sur '+' (raccourcis clavier 'a') pour l'ajouter au spectre de la source.
#           Pour retirer une raie du spectre, cliquer sur celle-ci dans le spectre de la source puis sur '-' (raccourcis clavier 'z')
#
# Quelques trucs rigolos Ã  faire :
#
#   - Cliquer partout et regarder ce qu'il se passe
#   - Source blanche : ajouter Ã  la main une dizaine de raies Ã  la source... On voit bien apparaÃ®tre le blanc d'ordre supÃ©rieur, surtout en coin d'air !
#   - Doublet du sodium : bon lÃ  pour voir quelque chose se passer, vaut mieux choisir un dÃ©calage d'une trentaine de nm. On voit bien la perte de cohÃ©rence pÃ©riodique.
#
# Fonctionnement
#
#   Il s'agit d'une rÃ©solution exacte, pas de formule prÃ©-rentrÃ©e ou autre tricherie dans le genre !
#   L'idÃ©e c'est qu'on calcule la position de chaque point de l'Ã©cran dans R^3 en fonction de L, Lx et Ly.
#   On calcule ensuite la position des sources secondaires fictives en fonction des paramÃ¨tres e et theta.
#   Ensuite, chaque point de l'Ã©cran est associÃ© Ã  une diffÃ©rence de marche entre les deux sources.
#   Il reste plus qu'Ã  associer Ã  chaque point une couleur RVB.
#   Pour une source polychromatique, on ajoute "simplement" les figures d'interfÃ©rence de chaque longueur d'onde...
#   Alors cela n'a pas Ã©tÃ© si simple, pour additionner des couleurs, je n'ai trouvÃ© aucune doc satisfaisante.
#   J'ai donc inventÃ© mon propre petit algorithme d'addition des couleurs, et il a l'air de donner des rÃ©sultats convenables.

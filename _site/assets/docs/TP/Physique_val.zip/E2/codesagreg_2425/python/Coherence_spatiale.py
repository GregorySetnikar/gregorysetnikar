#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Visualisation de la cohérence spatiae
Auteur: Francis Pagaud
"""
# Importation des librairies

import numpy as np
from numpy import loadtxt
import random

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc('xtick', labelsize=24)
matplotlib.rc('ytick', labelsize=24)
matplotlib.rcParams.update({'font.size': 22})

if __name__=="__main__":
    #-------------------------------#
    # Largeur de cohérence spatiale #
    #-------------------------------#


    b = np.linspace(0, 5, 10**3)  # b représente directement le facteur normalisé ab / Llambda.
    gamma = np.sinc(b)

    fig1 = plt.figure()
    plt.suptitle("Evolution du contraste")
    plt.axes([0.12, 0.15, 0.78, 0.75])
    plt.plot(b, gamma,'--',  label=r'$\Gamma$', color='black', linewidth = 3)
    plt.plot(b, np.abs(gamma), label=r'$C=|\Gamma|$', color='red', linewidth = 3)
    plt.legend()

    plt.xlabel(r'$\frac{ab}{\lambda L} $', fontsize = 28)
    plt.ylabel(r'$\Gamma$')

    plt.ylim(-0.25, 1.02)
    plt.xlim([0,5])
    y=[-0.4, 1.5]
    y=[0, 0.5, 1, 1.5]


    plt.scatter(y, np.abs(np.sinc(y)), color='black', zorder=100)

    #---------------------#
    # Intensité sur ecran #
    #---------------------#

    x= np.linspace(0, 6, int(1e3))

    # Calcul des profils d'ampltiude pour chaque valeur de ab/Llambda
    amplitude = np.array([np.ones(np.shape(x)[0])+np.sinc(b0)*np.cos(2 * np.pi * x) for b0 in b])

    valeurs=['0', '0.5', '1', '1.5']
    # Choix des profils d'amplitude que l'on va afficher ici pour b = 0, 0.5, 1, 1.5
    Num=[0, np.where(b>0.5)[0][0], np.where(b>1)[0][0], np.where(b>1.5)[0][0]]
    n= len(Num)

    fig2 = plt.figure()
    plt.suptitle("Exemples de figures observables")
    for k in range(n):
        num=Num[k]
        # Translation suivant la verticale pour élargir le profil en 2D
        M = np.zeros((150,x.shape[0]))
        for i in range(np.shape(M)[0]):
            M[i, :]=amplitude[num]/2

        plt.subplot(n, 1, k+1)
        plt.imshow(M, cmap= 'gray', vmin=0, vmax=1)
        plt.yticks([])
        plt.xticks([0, 200, 400, 600, 700, 800, 1e3], ['', '', '', '', '', '', ""])

        plt.ylabel(r'$\frac{ab}{\lambda L}=$'+valeurs[k], rotation =0, fontsize=20 )

        ax = plt.gca()
        ax.yaxis.set_label_coords(-0.15, 0.15)

    plt.xticks([0, 200, 400, 600, 800, 1e3], [0, 1, 2, 3, 4, 5])
    plt.text(-1, -1000, r'$\Gamma$')
    plt.xlabel(r'$\frac{ax}{\lambda D}$')
    plt.show()

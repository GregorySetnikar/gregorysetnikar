#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN
Version du 28/07/2022
"""

# Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt

# Paramètres À MODIFIER
filename = 'signal_sommateur.txt' # nom du fichier avec t, v(t)
fc = 1e4 # fréquence de coupure (Hz)

# Importation des données
data = np.genfromtxt(filename)
t = data[:,0]
v = data[:,1]
v_filter = np.zeros(len(t))
v_filter[0]=v[0]
Te = t[1] - t[0]
wTe = 2. * np.pi * fc * Te
for i in range(1,len(t)):
    v_filter[i] = wTe * v[i] + v_filter[i-1]
    v_filter[i] /= ( 1. + wTe )

# Calcul du spectre
vTF = np.fft.rfft(v)
v_filterTF = np.fft.rfft(v_filter)
freq = np.fft.rfftfreq(len(t),Te)

# Tracé des spectres
plt.figure()
plt.loglog(freq,np.absolute(vTF))
plt.loglog(freq,np.absolute(v_filterTF))
plt.xlabel('f (Hz)')
plt.ylabel('FFT')
plt.show()

# Tracé des données
plt.figure()
plt.plot(t,v)
plt.plot(t,v_filter,label='filtre')
plt.xlabel('t (s)')
plt.ylabel('v(t) (V)')
plt.show()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Filtrage linéaire

Dépendances:

Usage: python python_Filtrage_numerique_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""


# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
plt.rc('font', size=14)
from matplotlib.widgets import Slider, Button

# Definition des fonctions
class filtre:
    """
    Définition d'une classe filtre qui contient les différentes fonction applicables
    sur un filtre.
    """
    def __init__(self, type, Te, args):
        """
        type : passe_bas_numerique ou passe_bande_numerique
        Te : Période d'échantillonage
        args : paramètres du filtre [fc] pour un passe bas et [fc, Q] pour un
        passe bande
        """
        self.type = type
        self.Te = Te
        self.args = args

    def sortie(self, e):
        """
        Calcul la sortie temporelle du filtre correspondant à l'entrée e
        """
        return self.type(e, self.Te, *self.args)

    def fonction_transfert(self, N):
        """
        Calcul de la fonction de transfert grâce à la méthode de la réponse
        impulsionnelle: on applique une entrée e nulle sauf en un point ce qui
        correspond à une impulsion. On calcule la sortie puis sa transformée de
        Fourier correspond à la fonction de transfert.

        N: nombre de points pour la transformée de Fourier
        """

        N = int(N)
        # Génération de l'impulsion
        e = np.zeros(N)
        e[2] = 1
        # Calcul de la sortie
        s = self.type(e, self.Te, *self.args)[2:]
        # FFT et fréquences associées
        TF = np.fft.rfft(s[2:])
        freq = np.fft.rfftfreq(len(s[2:]), d=self.Te)
        return TF, freq

    def calc_gain(self, N):
        TF, freq = self.fonction_transfert(N)
        return freq, (20 * np.log(np.abs(TF)))

    def calc_phase(self, N):
        TF, freq = self.fonction_transfert(N)
        return freq, np.angle(TF)

    def plot_gain(self,N):
        TF, freq = self.fonction_transfert(N)
        plt.xlabel("$f/f_0$ (log)")
        plt.ylabel("Gain (dB)")
        plt.grid(True, which="both", ls="-", color='0.65')
        plt.plot(np.log(freq[freq>0]/self.args[0]), 20 * np.log(np.abs(TF[freq>0])))
        plt.show()

    def plot_phase(self, N):
        TF, freq = self.fonction_transfert(N)
        plt.xlabel("$f/f_0$ (log)")
        plt.ylabel("Déphasage")
        plt.yticks([np.pi/2, np.pi/4, 0, -np.pi/4, -np.pi/2], [r'$\frac{\pi}{2}$', r'$\frac{\pi}{4}$', "0", r'$-\frac{\pi}{4}$', r'$-\frac{\pi}{2}$'])
        plt.grid(True, which="both", ls="-", color='0.65')
        plt.plot(np.log(freq[freq>0]/self.args[0]), np.angle(TF[freq>0]))
        plt.show()


def passe_bas_numerique(e, Te, f):
    """
    Utilise une expression discretisé de l'équation différentielle d'un passe bas
    d'ordre 1 pour réaliser un passe bas sur un signal numérique
    Variables:
        - e: Signal d'entrée
        - fo: fréquence caractéristique du filtre
        - Te: Période d'acquisition

    """
    s = [0]
    for ek in e[1:]:
        s += [(1/(f*Te))/(1 + 1/(f*Te)) * s[-1] + ek/(1 + 1/(f*Te))]
    return np.array(s)

def passe_bande_numerique(e, Te, f0, Q):
    """
    Utilise une expression discretisé de l'équation différentielle d'un passe bande
    d'ordre 2pour réaliser un passe bande sur un signal numérique
    Variables:
        - e: Signal d'entrée
        - f0: frequence propre du filtre
        - Q: facteur de qualité
        - Te: Période d'acquisition
    """
    s = [0, 0]
    w0 = 2*np.pi*f0
    for i in range(2, len(e)):
        s += [2*s[-1] - s[-2]*(1+(w0*Te)**2) + (w0*Te/Q)*(e[i-1] - e[i-2] - s[-1] + s[-2])]
    return np.array(s)

def creneau(Te, f, t_acquisition, A=1, largeur=0.5):
    """
    Produit un signal créneau
    Arguments:
        - Te: période d'échantillonage
        - f: fréquence du créneau
        - N: Nombre de périodes
        - A: Amplitude du créneau
        - largeur: proportion de la période occupée par le créneau
    """
    N = int(t_acquisition*f)
    N_periode = int(1/(f*Te))
    c = np.ones(int(N*N_periode))
    for i in range(N):
        c[i*N_periode:i*N_periode + int(largeur*N_periode)] = 0
    return c

# Programme principal
if __name__ == "__main__":

    ## Filtre passe bas pour illuster le filtrage du bruit

    # Initiation des paramètres
    f = 1
    f1 = 1
    te = 0.01
    N = 1000
    t = np.arange(N) * te

    # Génération d'un signal bruité avec un bruit gaussien
    e = np.sin(2*np.pi*f1*t) + np.random.normal(0, 0.1, N)

    # Création du filtre
    PB = filtre(passe_bas_numerique, te, [f])

    # Slider pour la fréquence
    fig, ax = plt.subplots()
    plt.title("Effet du passe-bas d'ordre 1 numérique ")
    plt.subplots_adjust(bottom=0.22)

    ax.plot(t, e, label="Sinus à f=1Hz bruité")
    ax.set_xlabel("t")
    line, = ax.plot(t, PB.sortie(e), label="Sortie")
    ax.legend()

    # Sliders pour modifier la fréquence de coupure du filtre
    axfreq = fig.add_axes([0.2, 0.06, 0.6, 0.03])
    f_slider = Slider(
        ax=axfreq,
        label='fréquence de coupure (Hz)',
        valmin=0.1,
        valmax=10,
        valinit=f,
    )
    f_slider.label.set_position([0.8, -1])


    def update(val):

        # Bode gain
        PB.args = [f_slider.val]
        line.set_ydata(PB.sortie(e))
        fig.canvas.draw_idle()


    f_slider.on_changed(update)
    plt.show()


    ## Filtre passe bande et diagramme de bode

    init_Te = -2
    init_f = -1
    init_Q = 5
    init_N = 4

    init_fc = 0.1
    init_tacq = 1

    fig, ax = plt.subplots(nrows=2, ncols=2, figsize = (10, 5))
    plt.suptitle("Filtre numérique passe bande d'ordre 2")
    plt.tight_layout()

    FILTRE = filtre(passe_bande_numerique, 10**init_Te, [10**init_f, init_Q])

    # Diagramme de bode en gain
    freq, gain = FILTRE.calc_gain(10**init_N)
    line1, = ax[0][1].plot(np.log(freq[1:]/10**init_f), gain[1:], lw=2)
    ax[0, 1].set_ylabel("Gain (dB)", labelpad = -6)

    # Diagramme de bode en phase
    freq, phase = FILTRE.calc_phase(10**init_N)
    line4, = ax[1][1].plot(np.log(freq[1:]/10**init_f), phase[1:], lw=2)

    ax[1, 1].set_ylim([-2, 2])
    ax[1,1].set_yticks([np.pi/2, np.pi/4, 0, -np.pi/4, -np.pi/2], [r'$\frac{\pi}{2}$', r'$\frac{\pi}{4}$', "0", r'$-\frac{\pi}{4}$', r'$-\frac{\pi}{2}$'])
    ax[1,1].set_ylabel("Déphasage")
    ax[1, 1].set_xlabel("$f/f_0$ (log)")
    ax[1, 1].axhline(-np.pi/2, ls="dashed", color="black")
    ax[1, 1].axhline(np.pi/2, ls="dashed", color="black")

    # Réponse temporelle à un échelon
    e = creneau(10**init_Te, 10**(init_f - 1), 2/10**(init_f - 1))
    s = FILTRE.sortie(e)
    line2, = ax[0][0].plot(10**init_Te*np.arange(len(e)), e, label="Entrée")
    line3, = ax[0][0].plot(10**init_Te * np.arange(len(e)), s, label="Sortie")
    ax[0, 0].set_xlabel("t")
    ax[0, 0].legend(loc=(0.05,0.6))

    # adjust the main plot to make room for the sliders
    #fig.subplots_adjust(left=0.1, bottom=0.28)
    ax[0][1].grid(True, which="both", ls="-", color='0.65')
    ax[1][1].grid(True, which="both", ls="-", color='0.65')

    # Slider pour la fréquence (logarithmique)
    axfreq = fig.add_axes([0.1, 0.28, 0.3, 0.03])
    f_slider = Slider(
        ax=axfreq,
        label='log(f)',
        valmin=-2,
        valmax=0,
        valinit=init_f,
    )

    # Slider Période d'échantillonage (logarithmique)
    axTe = fig.add_axes([0.1, 0.22, 0.3, 0.03])
    Te_slider = Slider(
        ax=axTe,
        label="log($T_e$)",
        valmin=-4,
        valmax=0,
        valinit=init_Te
    )

    # Slide facteur de qualité
    axQ = fig.add_axes([0.1, 0.16, 0.3, 0.03])
    Q_slider = Slider(
        ax=axQ,
        label="Q",
        valmin=0.01,
        valmax=10,
        valinit=init_Q
    )

    # Slider nombre de point fft (logarithmique)

    axN = fig.add_axes([0.1, 0.1, 0.3, 0.03])
    N_slider = Slider(
        ax=axN,
        label="log($N_{FFT}$)",
        valmin=3,
        valmax=5,
        valinit=init_N
    )
    ax[1, 0].remove()

    def update(val):

        # Bode gain
        FILTRE.Te = 10**Te_slider.val
        FILTRE.args = [10**f_slider.val, Q_slider.val]
        freq, gain = FILTRE.calc_gain(10**N_slider.val)
        line1.set_xdata(np.log(freq[1:]/(10**f_slider.val)))
        line1.set_ydata(gain[1:])
        fig.canvas.draw_idle()
        ax[0][1].set_xlim([np.log(freq[1]/(10**f_slider.val)), np.log(freq[-1]/(10**f_slider.val))])


        # Diagramme de bode en phase
        _, phase = FILTRE.calc_phase(10**N_slider.val)
        line4.set_xdata(np.log(freq[1:]/(10**f_slider.val)))
        line4.set_ydata(phase[1:])
        fig.canvas.draw_idle()
        ax[1][1].set_xlim([np.log(freq[1]/(10**f_slider.val)), np.log(freq[-1]/(10**f_slider.val))])

        # Réponse temporelle
        e = creneau(10**Te_slider.val, 10**(f_slider.val - 1), 2/10**(f_slider.val - 1))
        s = FILTRE.sortie(e)
        line2.set_xdata(10**Te_slider.val*np.arange(len(e)))
        line2.set_ydata(e)
        line3.set_xdata(10**Te_slider.val*np.arange(len(e)))
        line3.set_ydata(s)
        fig.canvas.draw_idle()
        ax[0][0].set_xlim([0, 10**Te_slider.val*len(e)])
        ax[0][0].autoscale_view()

    # Update des sliders
    f_slider.on_changed(update)
    Te_slider.on_changed(update)
    Q_slider.on_changed(update)
    N_slider.on_changed(update)


    plt.show()

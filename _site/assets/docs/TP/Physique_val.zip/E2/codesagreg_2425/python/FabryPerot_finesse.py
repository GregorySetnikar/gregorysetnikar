#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script d'analyse des données obtenues à l'aide d'un interféromètre de Fabry-Pérot éclairé par un laser: l'ajustement affine
entre la "largeur" d'un anneau brillant et la "distance" entre l'anneau précédent et suivant permet de déterminer la finesse
de la cavité.
Les incertitudes sont évaluées à l'aide de la méthode des moindres carrés.

Dépendances:

Usage: python python_FabryPerot_finesse_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt

def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    Auteur: B. Guiselin
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
   
    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    # print("Résultats de l'ajustement :")
    # print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    # print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   if True:
      # Valeurs relevées en préparation
      # Rayons des anneaux (relevées sur ImageJ) et incertitudes associées [px] 
      Ri = np.array([])
      u_Ri = 
      # Largeurs des anneaux (relevées sur ImageJ) et incertitudes associées [px]
      dRi = np.array([])
      u_dRi = 
      # Ordre de l'anneau (au centre, i=0) et incertitudes associées
      i = np.array([])
      u_i = 
   else:
      # Valeurs relevées lors de la présentation
      pass

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Variables pertinentes pour la modélisation R(i+1)-R(i-1) = a*2*delta_R(i) + b
   X   = 2*dRi[1:-1]
   u_X = np.sqrt(2)*u_dRi
   Y   = Ri[2:]-Ri[:-2]
   u_Y = u_Ri 

   # Ajustement affine (pour obtenir un premier guess...)
   reglin = np.polyfit(X, Y, 1)
   # Modélisation affine (avec la prise en compte des incertitudes)
   A_guess = reglin[0]
   B_guess = reglin[1]
   [A_opti, B_opti, u_A_opti, u_B_opti, chi2] = modele_affine(X,Y,u_X,u_Y,A_guess,B_guess)

   # Affichage des résultats de la modélisation
   print("finesse = a =", A_opti, '+/-', u_A_opti)
   print("b =", B_opti, "+/-", u_B_opti, "px")
   print("chi2 =", chi2)

   # Plot
   plt.figure()
   plt.errorbar(X, Y, xerr=u_X, yerr=u_Y, fmt='b+')
   tmp = np.array([np.min(X),np.max(X)]) # pour tracer une droite, 2 points suffisent...
   plt.plot(tmp, A_opti*tmp+B_opti, 'r-')
   plt.xlabel('2*delta_R(i) (px)')
   plt.ylabel('R(i+1)-R(i-1) (px)')
   plt.show()




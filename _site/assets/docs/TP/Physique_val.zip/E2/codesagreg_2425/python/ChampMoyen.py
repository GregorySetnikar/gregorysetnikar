#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Transition ferro-para: solution graphique dans l'approximation de champ moyen.
Ce programme permet de trouver graphiquement le moment magnetique moyen pour une valeur donnee de temperature et de champ magnetique
"""

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})
    

# -----------------------------------------
# Definition des variables
# -----------------------------------------

N = 2048
x = np.linspace(-1., 1., N) # valeurs du moment magnetique adimensionne a sa valeur maximale m0

def f(a,t,b):
    ''' 
    Fonction issue de l'etude de champ moyen. 
    Le moment magnetique est solution de l'equation autocoherente f(x,t,b)=x
    '''
    return np.tanh((a+b)/t)

t = 0.5 # temperature adimensionnee a Tc
b = 0 # champ magnetique adimensionne a kB*Tc/m0


# -----------------------------------------
# Programme principal
# -----------------------------------------

if __name__ == "__main__":

    val_f = f(x,t,b)

    # trace de la figure
    fig = plt.figure()

    plt.clf()

    ax1 = plt.axes([0.15, 0.22, 0.35, 0.7])
    ax2 = plt.axes([0.58, 0.22, 0.35, 0.7])

    # sliders pour changer la valeur de t et b
    axb = plt.axes([0.12, 0.02, 0.58, 0.03])	
    axt = plt.axes([0.12, 0.06, 0.58, 0.03])	
    st = Slider(axt, r'$T/T_c$', 0.05, 1.5, valinit=t, valfmt='%0.2f')
    sb = Slider(axb, r'$B/B_0$', 0., 1., valinit=b, valfmt='%0.2f')
    
    # liste qui garde les valeurs des solutions pour le tracé du diagramme x(t)
    liste_t = []
    liste_x = []
 
    # fonction de remise à zéro du diagramme x(t)
    def reset_values(self):
        global liste_t, liste_x
        liste_t = []
        liste_x = []
        trace.set_xdata([])
        trace.set_ydata([])
        fig.canvas.draw_idle()

    def update(val):
        ''' Mise a jour de la figure a partir des nouvelles valeurs de t et b '''
        t = st.val
        b = sb.val
        
        val_f = f(x,t,b)
        
        # reperage de la solution graphique
        ind = np.argwhere((np.abs(val_f-x)<0.0004) & (x > 0.0001) )[-1,0]
        ptx = x[ind]
        
        # mise a jour des donnees tracees
        l1.set_ydata(val_f)
        p1.set_xdata(ptx)
        p1.set_ydata(ptx)
        p2.set_xdata(t)
        p2.set_ydata(ptx)
        
        liste_t.append(t)
        liste_x.append(ptx)
        trace.set_xdata(liste_t)
        trace.set_ydata(liste_x)
        
        fig.canvas.draw_idle()
        
        
    # mise a jour des valeurs de b, t
    st.on_changed(update)
    sb.on_changed(update)
    
    # reperage de la solution x
    ind = np.argwhere((np.abs(val_f-x)<0.0005) & (x> 0.0001) )[-1,0]
    ptx = x[ind]


    # mise en forme de la figure
    ax1.set_xlabel(r'$x=\langle m \rangle / m_0$', fontsize = 26)
    ax1.set_ylabel('$y$', fontsize = 26)
    ax1.set_xlim(-1.1,1.1)
    ax1.set_ylim(-1.1,1.1)

    ax2.set_xlabel(r'$T/T_c$', fontsize = 26)
    ax2.set_ylabel(r'$x=\langle m \rangle / m_0$', fontsize = 26)
    ax2.set_xlim(0.,1.5)
    ax2.set_ylim(-0.1,1.2)

    l1, = ax1.plot(x, val_f, '-r', lw = 4, label=r'$y=\tanh (\frac{T_{c}}{T} (x+\frac{B}{B_0}))$')
    l2, = ax1.plot(x, x, '-b', lw = 4, label=r'$y=x$')
    ax1.legend()

    p1, = ax1.plot(ptx, ptx, 'o', color = 'orange', markersize = 15, zorder=5)
    p2, = ax2.plot(t, ptx, 'o', color = 'orange', markersize = 8, zorder=5)
    trace, = ax2.plot(liste_t, liste_x, color='k', marker='+', ls="")
    ax2.axvline(1.,color = 'gray')

    ax1.grid()
    ax2.grid()    
    
    # bouton de remise à zéro
    ax3 = fig.add_axes([0.785,0.02,0.1,0.075])
    bouton = Button(ax3, 'Reset')
    bouton.on_clicked(reset_values)
    
    mng = plt.get_current_fig_manager()
    mng.window.showMaximized()
    plt.show()


    

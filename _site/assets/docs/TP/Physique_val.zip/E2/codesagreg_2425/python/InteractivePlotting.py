#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Programme permettant de tracer une courbe en modifiant un (des) paramètre(s) de manière interactive.

Dépendances: python_Widgets_lyon.py (modifier en conséquence la variable d'environnement PYTHONPATH ou placer ces
                                     deux fichiers dans le même répertoire)

Usage: python python_InteractivePlotting_lyon.py

Adapté d'un programme de M. Vérot (https://github.com/MartinVerot/pyChromato)
    et d'un programme de A. Raoux (https://github.com/araoux/python_agregation/blob/master/programmes_lecons/programmes_lecons/widgets.py)
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy as sc
import scipy.constants as constants
import itertools
import python_Widgets_lyon as widgets


# Definition des fonctions
def fonction_test(X,T) :
    """ Une fonction simple pour faire des essais """
    # Recuperation de constantes physiques
    c = constants.c
    h = constants.h
    k = constants.Boltzmann

    # Conversion d'unites
    X = X*1e-6

    prefactor = 1. # mettre h, c, np.pi...
    A= prefactor / X**5
    B = np.exp(h*c/(X*k*T))-1
    C = A/B
    return C 

#======================================================================================
# Definition des formes fonctionnelles pour les différentes courbes.
# Il s'agit de la partie critique du script pour les aspects "discussion physique".
#======================================================================================
def plot_data(T):
    """ Fonction qui sera appelée à chaque fois pour rafraichir les courbes. """
    # Definition de la courbe associée au 1er nom
    lines[noms[0]].set_data(X ,fonction_test(X, T)/fonction_test(X, 6000).max())
    # Definition de la courbe associée au 2eme nom
    lines[noms[1]].set_data(X ,fonction_test(X, T)/fonction_test(X, T).max())
    # A poursuivre si necessaire
    fig.canvas.draw_idle()
    return

# Programme principal
if __name__ == "__main__":
    # Definition des parametres associes a des widgets
    # Syntaxe: 'nom du param' : widgets.FloatSlider(valeur=valeur initiale (un float), \
    #                                               description='description (un str)', \
    #                                               min=valeur minimale (un float), \
    #                                               max=valeur maximale (un float))
    parameters = {
        'T' : widgets.FloatSlider(value=5, description='T', min=288, max=6000),
        }

    # Figure
    fig = plt.figure(figsize=(12,6))
    fig.suptitle("Un beau titre")

    # Definition de l'espace occupe par le graphique a proprement parler (fig. units)
    ax = fig.add_axes([0.1, 0.3, 0.85, 0.6])
    if True:  ax.set_xscale('log')
    if False: ax.set_yscale('log')

    # Légende des axes
    if True:  ax.set_xlabel("Longueur d'onde ($\mu$m)")
    if False: ax.set_ylabel('Ordonnée')

    # Noms des différentes courbes qui seront tracées
    noms = []
    noms.append('nom de la courbe 1')
    noms.append('nom de la courbe 2')

    # Abscisses et ordonnées
    X = np.linspace(0.2, 60, 10000)
    ax.set_xlim(X.min(), X.max())
    ax.set_ylim(-0.1, 1.1)

    #=========================================================================================
    # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
    #=========================================================================================
    # Construction du dictionnaire associé
    lines = {}
    colors = ['r', 'g', 'b', 'm']
    c_colors = itertools.cycle(colors)
    for nom in noms:
       lines[nom], = ax.plot([], [], lw=2, color=next(c_colors), visible=True)
    
    # Creation des widgets associés aux paramètres définis précédemment
    param_widgets = widgets.make_param_widgets(parameters, plot_data, slider_box=[0.3, 0.07, 0.65, 0.15])
    # Création des boutons pour afficher (ou non) les différentes courbes
    choose_widget = widgets.make_choose_plot(lines, box=[0.01, 0.07, 0.15, 0.15])
    # Bouton de reset pour revenir aux valeurs par défaut des paramètres
    reset_button = widgets.make_reset_button(param_widgets)
    # Visualisation
    plt.show()




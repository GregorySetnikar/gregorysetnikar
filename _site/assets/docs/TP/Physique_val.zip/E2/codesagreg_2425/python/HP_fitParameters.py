#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-traitement des données permettant la caractérisation des paramètres physiques d'un HP modélisé sous la forme
d'une impédance électromotionnelle dont l'expression est donnée par Donnini & Quaranta, BUP 777, 1627 (1995)

Le principe de l'expérience repose sur l'étude du déplacement de la fréquence de résonance du filtre passe-bande que
constitue (avec cette modélisation) le HP lorsque l'on ajoute des masses sur la membrane vibrante. Ces données sont
supposées avoir été obtenues au préalable, et doivent être renseignées dans ce script.

Dépendances:

Usage: python python_HP_fitParameters_lyon.py

Auteurs: M. Boselli & F. Vialla (21/02/2023)
         C. Winisdoerffer (22/03/2023)
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as scopt

# Definition des fonctions
def fres_asafuncof_k_and_mass_v1(m,k,m0):
   """ Modélisation de la fréquence comme f = 1/2\pi times sqrt(k/m) """
   fres = np.sqrt(k/(m+m0))/(2.*np.pi)
   return fres

def fres_asafuncof_k_and_mass_v2(m,k,m0):
   """ Modélisation de la fréquence comme 1/f^2 = (2\pi)^2 times m/k """
   jnk = (2.*np.pi)**2*(m+m0)/k
   return jnk

def get_HP_params(masses,fres,fres_err,R,R_err,numer,numer_err,Q,Q_err):
   """ Modélisation des paramètres "traditionnels" d'un HP """
   # Conversion du type des données par commodité
   masses   = np.array(masses)
   fres     = np.array(fres)
   fres_err = np.array(fres_err)
   # Guess initial des paramètres du fit [k [N/m], m0 [g]]
   first_guess = [1000,5]
   # Curve fitting pour f = sqrt(k/m)/(2\pi)
   params_v1, cov_v1 = scopt.curve_fit(fres_asafuncof_k_and_mass_v1,masses,fres,first_guess,fres_err)
   print("Best fit parameters for fit 1: {} [au]".format(params_v1))
   # Curve fitting pour 1/f^2 = (2\pi)^2 m/k
   params_v2, cov_v2 = scopt.curve_fit(fres_asafuncof_k_and_mass_v2,masses,1./fres**2,first_guess,2*fres_err/fres**3)
   print("Best fit parameters for fit 2: {} [au]".format(params_v2))
   # Plot
   m = np.linspace(np.amin(masses), np.amax(masses))
   fig, axes = plt.subplots(2,1,figsize=(6,6))
   axes[0].errorbar(masses,fres,yerr=fres_err,fmt='o')
   txt = "Best fit\n k={:2e} [N/m]\n m0={:2f} [g]".format(params_v1[0]/1.e3,params_v1[1])
   axes[0].plot(m,fres_asafuncof_k_and_mass_v1(m,*params_v1),label=txt)
   axes[0].set_xlabel(r'$\Delta m$ [g]')
   axes[0].set_ylabel(r'$f_\mathrm{res}$ [Hz]')
   axes[0].legend()
   axes[1].errorbar(masses,1./fres**2,yerr=2*fres_err/fres**3,fmt='o')
   txt = "Best fit\n k={:2e} [N/m]\n m0={:2f} [g]".format(params_v2[0]/1.e3,params_v2[1])
   axes[1].plot(m,fres_asafuncof_k_and_mass_v2(m,*params_v2),label=txt)
   axes[1].set_xlabel(r'$\Delta m$ [g]')
   axes[1].set_ylabel(r'$1/f^2_\mathrm{res}$ [Hz$^{-2}$]')
   axes[1].legend(loc='lower right')
   plt.tight_layout()
   if True:
      plt.savefig('HP_withmasses.png')
   plt.show()
   # Détermination des paramètres du HP à partir des fits précédents et des formules du HP
   # Rq. : la propagation des incertitudes est faite en négligeant les corrélations
   for ioptim,optim in enumerate([[params_v1, cov_v1], [params_v2, cov_v2]]):
      # Conversion g --> kg
      opt = optim[0] / 1.e3
      cov = optim[1] / (1.e3)**2
      # Le fit donne k et m0
      k  = opt[0] ; k_err  = np.sqrt(cov[0,0])
      m0 = opt[1] ; m0_err = np.sqrt(cov[1,1])
      # Calcul de eta
      eta = (1/Q)*np.sqrt(k*m0)
      eta_err = np.sqrt(Q_err**2 * (1/Q**2*np.sqrt(k*m0))**2 + \
                        m0_err**2 * (1/Q*np.sqrt(k/m0)/2)**2 + \
                        k_err**2 * (1/Q*np.sqrt(m0/k)/2)**2)
      # Calcul de B\ell
      Bl = np.sqrt(numer*eta)
      Bl_err = np.sqrt(numer_err**2 * (np.sqrt(eta/numer)/2)**2 + \
                       eta_err**2 * (np.sqrt(numer/eta)/2)**2)
      # Affichage
      print('\nUsing best fit parameters for fit {}'.format(ioptim+1))
      print('k = {} +/- {} [N/m]'.format(k,k_err))
      print('m0 = {} +/- {} [g]'.format(m0*1.e3,m0_err*1.e3))
      print('eta = {} +/- {} [kg/s]'.format(eta,eta_err))
      print('Bl = {} +/- {} [Tm]'.format(Bl,Bl_err))
   return

# Programme principal
if __name__ == "__main__":
   # Pouvoir renseigner de façon pertinente les données suivantes suppose qu'une analyse de |Z|(\omega) ait été faite
   # au préalable, et cela pour différentes masses ajoutées sur la membrane vibrante.
   # L'utilisateur doit renseigner, pour chacune d'elle, la fréquence de résonance et une estimation de son incertitude.
   # En outre, il doit également fournir les paramètres du filtre passe-bande du HP non-perturbé, écrit sous la
   # forme canonique Z = R + numer/(1+jQ(f/fres-fres/f))
   # Toutes ces données sont des sorties du script python_HP_fitPasseBande_lyon.py

   # Masses ajoutées [g], avec des estimations de l'incertitude
   # Rq: les incertitudes sur les masses ne sont pas utilisées par la suite car l'optimisation repose sur
   #     la fonction scipy.optimize.curve_fit qui ne permet pas de prendre en compte l'incertitude sur l'axe des
   #     abscisses. On supposera donc que les masses utilisées sont des masses marquées, et que l'incertitude sur
   #     ces "masses étalons" joue donc un rôle négligeable.
   masses = []                           # masses ajoutées [g]
   masses_err = [] # incertitudes sur les masses ajoutées [g]
   # Fréquences de résonances obtenues par le fit de |Z| [Hz], avec des estimations de l'incertitude
   # Boselli & Vialla data
   #fres     = [133.53211709682344, 93.25770702546812, 73.37854257399127, 62.21493555270507, 47.87095771095943]
   #fres_err = [0.2096022534762294, 0.1974632310880468, 0.16660746892018236, 0.16225636585738387, 0.15397219628144007]
   # Résultats de mes fits, sur l'intervalle 20-130 Hz sauf pour le HP non perturbé (sur 0-500 Hz)
   fres     = []
   fres_err = []
   # Paramètres R, numer et Q obtenus par le fit du HP non perturbé, avec des estimations de l'incertitude
   R     =   ; R_err     = 
   numer =  ; numer_err = 
   Q     =   ; Q_err     = 

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Let's go!
   get_HP_params(masses,fres,fres_err,R,R_err,numer,numer_err,Q,Q_err)
   


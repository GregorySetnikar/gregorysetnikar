#!/usr/bin/env python3
# -*- coding: utf-8 -*-r


''' Ce code affiche l'intensité lumineuse simulée d'un fabry-pérot en
fonction de la longueur d'onde.
Les paramètres de contrôles sont le coefficient de réflexion des miroirs et
l'épaisseur de la lame. ''' 

import numpy as np
import scipy.optimize as spo
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=24)
matplotlib.rc('ytick', labelsize=24)
matplotlib.rcParams.update({'font.size': 22})

###

lambd0 = 600*10**(-9)
R0 = 0.9
l0 = 0.5

fig, ax = plt.subplots()
plt.subplots_adjust(left=0.15, bottom=0.25)
lambd = np.arange(400*10**(-9), 800*10**(-9), 0.5*10**(-10))
#R = np.arange(0.5, 1, 0.001)
#l = np.arange(0.5*10**(-6), 5*10**(-6), 0.02*10**(-6))

def phi(llambd, lx) :
    return(4*np.pi*1.5*lx/llambd)



s = 1/(1+4*R0/((1-R0)*(1-R0))*np.sin( phi(lambd, l0*10**(-6)) /2)**2)
F = np.pi*2*np.sqrt(R0)/(1-R0)

f, = plt.plot(lambd*10**9, s, lw=4)
plt.plot([400, 800], [0.5, 0.5],'r--', linewidth = 2, zorder = 1)
plt.plot([400, 800], [1, 1],'k--', linewidth = 2, zorder = 1)
plt.xlim([400, 800])
plt.ylim([-0.05, 1.1])
ax.margins(x=0)
tx = plt.text(400, 1.15, '$\mathcal{F} = $' + "%0.2f"%F, fontsize=30)
plt.yticks([0, 0.5, 1])
plt.ylabel('$I/I_0$', fontsize = 28)
plt.xlabel('$\lambda$ [nm]', fontsize = 28)



axR = plt.axes([0.15, 0.05, 0.7, 0.03])
axl = plt.axes([0.15, 0.1, 0.7, 0.03])

sR = Slider(axR, 'R', 0.7, 1, valinit=R0, valfmt='%0.3f')
sl = Slider(axl, 'n $\cdot$ e  [$\mu$m]', 0.0, 1.5, valinit=l0, valfmt='%0.2f')


def update(val):
    Rval = sR.val
    lval = sl.val
    f.set_ydata( 1/(1+4*Rval/((1-Rval)*(1-Rval))*np.sin( phi(lambd, lval*10**(-6)) /2)**2) )
    F = np.pi*2*np.sqrt(Rval)/(1-Rval)
    tx.set_text('$\mathcal{F} = $' + "%0.2f"%F)
    fig.canvas.draw_idle()


sl.on_changed(update)
sR.on_changed(update)


resetax = plt.axes([0.92, 0.08, 0.05, 0.04])
button = Button(resetax, 'Reset',  hovercolor='0.975')


def reset(event):
    sR.reset()
    sl.reset()
button.on_clicked(reset)

##
##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

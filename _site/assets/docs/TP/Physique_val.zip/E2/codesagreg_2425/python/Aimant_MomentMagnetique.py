#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Post-traitement des données permettant la caractérisation du moment magnétique et de l'aimantation d'un aimant suivant
le protocole détaillé dans la Ref. "Physique expérimentale, Optique, magnétisme, électrotechnique, mécanique, thermodynamique
et physique non linéaire", Jolidon (2021).

Dépendances:

Usage: python python_Aimant_MomentMagnetique_lyon.py

Auteurs: B. Guiselin (22/07/2022)
         C. Winisdoerffer (28/03/2023)
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as scopt
import scipy.constants as sccst

# Definition des fonctions
def modele_affine(X,Y,u_X,u_Y,a_guess,b_guess):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_guess et b_guess.
    La fonction renvoie un tableau qui contient dans l'ordre : 
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a*x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return (y-affine(x,a,b)) / np.sqrt(u_y*u_y+(a*u_x)**2)

    opt_affine = scopt.least_squares(residu_affine,np.array([a_guess,b_guess]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt(2./hessian_affine[0,0])
    u_b_opt = np.sqrt(2./hessian_affine[1,1])
    chi2_opt = np.sum(residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y)**2) / (len(X)-2)
    print("Résultats de l'ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

def get_data_BGuiselin():
   """ Exemple de données expérimentales """
   # Initialisation
   data_B = []  # pour le 1er ensemble
   data_M = {}  # pour le 2eme ensemble
   # Données relatives au 1er ensemble
   # 1er jeu
   data_set = {}
   data_set['I'] = 
   data_set['B'] = 
   data_set['x'] = 
   data_set['u_I'] = 
   data_set['u_B'] = 
   data_set['u_x'] = 
   data_B.append(data_set)
  
   # Données relatives au 2eme ensemble
   # Volume de l'aimant et son incertitude [m^3]
   data_M['V']    = 
   data_M['u_V']  = 
   # Intensités échantillonnées et leurs incertitudes [A]
   data_M['I']    = 
   data_M['u_I']  = 
   # Masses indiquées par la balance et leurs incertitudes [kg]
   data_M['Dm']   = 
   data_M['u_Dm'] = 

   return data_B, data_M

def etalonnage_bobines_antiHelmholtz(data_B):
   """ Exploitation des mesures pour obtenir la relation entre le gradient du champ B et l'intensité circulant dans
   les bobines (en configuration anti-Helmholtz) au voisinage du centre du dispositif """
   for i_set, data_set in enumerate(data_B):
      # Vérification de la compatibilité des (formats des) données
      assert np.shape(data_set['x']) == np.shape(data_set['B'])
      # Modélisation affine B = B(z)
      param_affine = modele_affine(data_set['x'],data_set['B'],data_set['u_x'],data_set['u_B'],1,0)
      a_B    = param_affine[0] # extraction de la pente
      u_a_B  = param_affine[2] # extraction de l'incertitude sur la pente
      b_B    = param_affine[1] # extraction de l'ordonnée à l'origine
      u_b_B  = param_affine[3] # extraction de l'incertitude sur l'ordonnée à l'origine
      chi2_B = param_affine[4] # extraction du chi2 réduit
      # Sauvegarde de la donnée d'intérêt, la pente
      data_B[i_set]['nablaB'] = a_B
      data_B[i_set]['u_nablaB'] = u_a_B
      # Plot
      plt.errorbar(data_set['x'],data_set['B'],data_set['u_B'],data_set['u_x'],'+')
      plt.plot(data_set['x'],a_B*data_set['x']+b_B,label='I = {} [A]'.format(data_set['I']))
   plt.xlabel('x [m]')
   plt.ylabel('B [T]')
   plt.legend()
   if True:
      plt.savefig('plot1.png')
   plt.show()

   # Extraction des paires (intensité, nablaB) et des incertitudes correspondantes
   I        = np.array([data_set['I'] for data_set in data_B])
   u_I      = np.array([data_set['u_I'] for data_set in data_B])
   nablaB   = np.array([data_set['nablaB'] for data_set in data_B])
   u_nablaB = np.array([data_set['u_nablaB'] for data_set in data_B])
   # Modélisation affine nablaB = nablaB(I) 
   param_affine = modele_affine(I,nablaB,u_I,u_nablaB,1,0)
   a_nablaB    = param_affine[0] # extraction de la pente
   u_a_nablaB  = param_affine[2] # extraction de l'incertitude sur la pente
   b_nablaB    = param_affine[1] # extraction de l'ordonnée à l'origine
   u_b_nablaB  = param_affine[3] # extraction de l'incertitude sur l'ordonnée à l'origine
   chi2_nablaB = param_affine[4] # extraction du chi2 réduit
   # Plot
   plt.errorbar(I,nablaB,u_nablaB,u_I,'+')
   plt.plot(I,a_nablaB*I+b_nablaB,label=r'pente = {0:.3e} $\pm$ {1:.1e} [T/m/A]'.format(a_nablaB,u_a_nablaB))
   plt.xlabel('I [A]')
   plt.ylabel(r'$\nabla_x B$ [T/m]')
   plt.legend()
   if True:
      plt.savefig('plot2.png')
   plt.show()

   return [a_nablaB, u_a_nablaB, b_nablaB, u_b_nablaB]

def aimant(data_M, etalonnage):
   """ Exploitation des mesures pour obtenir la relation entre le poids apparent de l'aimant et le gradient du champ
   magnétique auquel il est soumis en étant placé entre des bobines (en configuration anti-Helmholtz, au voisinage du centre
   du dispositif).
   L'étalonnage du dispositif (ie la relation entre le gradient de B et l'intensité circulant dans les bobines) est supposé
   avoir été effectué au préalable (par exemple à l'aide de la fonction etalonnage_bobines_antiHelmholtz). Les paramètres
   (pente, ordonnée à l'origine) et leurs incertitudes sont contenus dans la variable etalonnage. """
   # Conversion du type des données par commodité
   a_nablaB, u_a_nablaB, b_nablaB, u_b_nablaB = etalonnage
   # Exploitation de la relation nablaB = nablaB(I) pour calculer le gradient du champ magnétique (et son incertitude)
   # lorsque l'aimant est placé sur la balance
   GBm   = a_nablaB*data_M['I']+b_nablaB
   u_GBm = a_nablaB*data_M['I']*np.sqrt((u_a_nablaB/a_nablaB)**2+(data_M['u_I']/data_M['I'])**2)+u_b_nablaB
   # Modélisation affine g\Delta m = g\Delta m (\nabla B)
   param_affine = modele_affine(GBm,sccst.g*data_M['Dm'],u_GBm,sccst.g*data_M['u_Dm'],1,0)
   a_m    = param_affine[0] # extraction de la pente
   u_a_m  = param_affine[2] # extraction de l'incertitude sur la pente
   b_m    = param_affine[1] # extraction de l'ordonnée à l'origine
   u_b_m  = param_affine[3] # extraction de l'incertitude sur l'ordonnée à l'origine
   chi2_m = param_affine[4] # extraction du chi2 réduit
   # Exploitation du résultat pour la caractérisation de l'aimant (et son incertitude)
   M   = a_m/data_M['V']    # aimantation de l'aimant
   u_M = M*np.sqrt((u_a_m/a_m)**2+(data_M['u_V']/data_M['V'])**2)
   # Plot
   plt.errorbar(GBm,sccst.g*data_M['Dm'],sccst.g*data_M['u_Dm'],u_GBm,'+')
   plt.plot(GBm,a_m*GBm+b_m,label=r'pente = {0:.2f} $\pm$ {1:.1e} [N/(T/m)]'.format(a_m, u_a_m))
   plt.xlabel(r'$\nabla_x B$ [T/m]')
   plt.ylabel(r'g$\Delta m$ [N]')
   plt.title(r"Aimantation de l'aimant : {0:.2e}$\pm$ {1:.1e} [A/m]".format(M,u_M))
   plt.legend()
   if True:
      plt.savefig('plot3.png')
   plt.show()

# Programme principal
if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   # Le 1er ensemble, data_B, regroupe, sous la forme d'une liste de dictionnaires, les différents jeux de données permettant
   # étalonnage des bobines anti-Helmholtz.
   # Un jeu correspond à un dictionnaire dont les clefs sont (avec entre parenthèses le type de données):
   # 'I'   : intensité circulant dans les bobines (un float) [A]
   # 'u_I' : incertitude sur l'intensité (un float) [A]
   # 'x'   : positions où sont mesurés les champs B (un numpy-array de floats) [m]
   # 'u_x' : incertitudes sur les positions (un numpy-array de floats) [m]
   # 'B'   : composantes suivant x du champ magnétique (un numpy-array de floats) [T]
   # 'u_B' : incertitudes sur le champ magnétique (un numpy-array de floats) [T]
   # Le 2eme ensemble, data_M, regroupe, sous la forme d'un dictionnaire, les différents mesures effectuées lorsque l'aimant
   # est placé entre les bobines. Les clefs de ce dictionnaire sont suffisamment explicites.
   # Un exemple est donné dans la fonction get_data_BGuiselin
   if True:
      data_B, data_M = get_data_BGuiselin()
   else:
      # Initialisation
      data_B = []  # pour le 1er ensemble
      data_M = {}  # pour le 2eme ensemble
      # Données
      # A COMPLETER PAR L'UTILISATEUR

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Etalonnage du dispositif
   etalonnage = etalonnage_bobines_antiHelmholtz(data_B)

   # Exploitation des mesures avec l'aimant placé sur la balance
   aimant(data_M, etalonnage)



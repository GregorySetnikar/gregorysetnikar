#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Visualisation de la distribution spatiale de particules contenues dans une boîte de hauteur L, soumises à un champ de pesanteur
uniforme et maintenues à une température constante.
Dans la limite où L tend vers +\infty, cela correspond au modèle de l'atmosphère isotherme.

Dépendances:

Usage: python python_Atmosphere_isotherme_lyon.py

Auteurs: Agrégatifs de Lyon 2022-2023
"""


# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

# Définition des fonctions
def Boltzmann(H,L,z):
   """
   Distribution de Boltzmann \propto \exp(-z/H), avec la normalisation correspondant au probleme considere
   Input: L : dimension verticale de la boite [en unités arbitraires]
          H : hauteur caractéristique (H = RT/Mg) [en unités identiques à L]
          z : altitude(s) où est échantillonnée la loi de probabilité
   """
   dP_dz = np.exp(-z/H)/ (H * (1.-np.exp(-L/H)))
   return dP_dz

def generation(N,H,L):
   """
   Génère aléatoirement un ensemble de N positions (x,z) correspondant à la distribution de Boltzmann avec une échelle
   de hauteur H, et une dimension verticale totale de la boîte L
   La distribution des positions horizontales (x) est uniforme sur [0;1]
   """
   horizontal_pos = np.random.rand(N)
   vertical_pos   = np.random.exponential(scale=H,size=N) / (1.-np.exp(-L/H))
   return np.stack((horizontal_pos,vertical_pos))

if __name__ == "__main__":
    # Initialisations
    init_L = 10             # hauteur de la boite [unites arbitraires]
    init_H = 1              # hauteur caracteristique H = RT/Mg [unites identiques à L]
    init_N = 200            # nombre de particules 

    # Mise en place de la figure
    plt.rc('font', size=14) # consideration cosmetique
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))
    plt.suptitle('Distribution de particules\n("atmosphère isotherme" dans une boîte de dim. L={} [u.a])'.format(init_L))
    plt.subplots_adjust(bottom=0.22)

    # Tracé de la fonction de distribution
    z = np.linspace(0, init_L)
    line0, = ax[0].plot(z, Boltzmann(init_H,init_L,z))
    # Particules
    positions = generation(init_N, init_H, init_L)
    line1, = ax[1].plot(positions[0], positions[1], ls="", marker="o")

    ax[0].set_xlabel("z")
    ax[0].set_ylabel("dP/dz")
    ax[1].set_xlabel("x")
    ax[1].set_ylabel("z")
    ax[1].set_ylim([0, init_L])
    horiz = ax[1].axhline(init_H, ls = "dashed", color="black", lw=2, label="z = H")
    ax[1].legend(loc='upper right')

    # Sliders pour modifier la hauteur caractéristique et le nombre de particules
    axH = fig.add_axes([0.2, 0.02, 0.6, 0.03])
    H_slider = Slider(ax=axH, label='H', valmin=0.01, valmax=2*init_L, valinit=init_H)

    axN = fig.add_axes([0.2, 0.08, 0.6, 0.03])
    N_slider = Slider(ax=axN, label='N', valmin=10, valmax=1000, valinit=init_N)

    def update(val):
        dist = Boltzmann(H_slider.val,init_L,z)
        positions = generation(int(N_slider.val),H_slider.val,init_L)

        line0.set_ydata(dist)
        line1.set_xdata(positions[0])
        line1.set_ydata(positions[1])
        fig.canvas.draw_idle()
        ax[0].set_ylim([0, np.max(dist)])
        ax[0].autoscale_view()
        ax[1].set_ylim([0, init_L])
        ax[1].autoscale_view()
        horiz.set_data([0, 1], [H_slider.val, H_slider.val])


    N_slider.on_changed(update)
    H_slider.on_changed(update)
    plt.show()

   
   
    


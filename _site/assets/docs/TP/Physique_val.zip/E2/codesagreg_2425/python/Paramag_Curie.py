#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''01/06/2020

Francis Pagaud et Gauthier Legrand.
Tracé du paramagnétisme de Curie, comme dans le Kittel p. 276
'''


import matplotlib.pyplot as plt
import numpy as np
import matplotlib
import scipy.constants as cst
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})

##

T = 293                #Temp ambiante
k_B = cst.k
beta = 1/(k_B*T)

B_sur_T = np.arange(0, 5, 0.01)
mu_b = 9.27*10**(-24)   #Pour l'electron (A*m^2)
g = 2.0                 #Facteur de Lande de l'electron
n = 10**29              #Densite (ODG, atomes par m^3)
J = [1/2,3/2,5/2]                 #Spin total (ici choisi =1/2)


M = n*g*J[0]*mu_b*np.tanh(g*J[0]*mu_b*B_sur_T/k_B)       #Trace de la fonction gamma
B_j = []

for k in J :
    B_j.append( (2*k+1)/(2*k) * 1/np.tanh( (2*k+1)/(2*k)*g*mu_b*k*B_sur_T/k_B ) - 1/(2*k)/np.tanh( g*k*mu_b*B_sur_T/k_B/(2*k) ) )    #Dans le cas J quelconque

M_j = []
for i in range (len(J)) :
    M_j.append(n*g*J[i]*mu_b*np.array(B_j[i]))

fig = plt.figure("Paramagnétisme de Pauli")
plt.clf()

plt.plot(B_sur_T,M_j[0],'-b', lw = 4, label='J = 1/2')
plt.plot(B_sur_T,M_j[1],'-r', lw = 4, label='J = 3/2')
plt.plot(B_sur_T,M_j[2],'-g', lw = 4, label='J = 5/2')

plt.xlabel('$B/T$ [T/K]')
plt.ylabel('$M$ [A/m]', fontsize = 32)

plt.xlim([0,5])

plt.grid()
plt.legend(framealpha = 0.5, loc=2)

##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ce fichier illustre le post-traitement (visualisation + ajustement) de données dans le contexte de l'étude
des propriétés de conductivité (thermique ou électrique) des métaux. 
Le lecteur sera libre de commenter certaines parties notamment dans le cas où il doit choisir son système d'exploitation.

Dépendances:

Usage: python python_Lecture_Data_Metaux.py

Auteurs: Agrégatifs de physique 2023-2024
"""

# Importation des librairies
import os
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.optimize as scopt
import pandas as pd

# Définition des fonctions
def smooth(x,n=10):
    """ Fonction qui permet de lisser une série de données, utilise une convolution par un noyau uniforme,
    n est le nombre de points sur lequel faire le lissage """
    x=np.array(x)
    x=np.convolve(np.ones(n),x)/n
    return(x[n:-n])

def temp(rho,alpha,rho0):
    """ Forme fonctionnelle affine """
    return(alpha*rho + rho0)

def oscill(t,phi1,phi2,A0,A1,A2):
    """ Forme fonctionnelle correspondant a cste + fondamental + harmonique double """
    omega = 2*np.pi*10e-3
    return(A0 + A1*np.cos(omega*t+phi1)+A2*np.cos(2*omega*t+phi2))

# Programme principal
if __name__=='__main__':
    # PREAMBULE : 
    # SI l'ordinateur possède une version de latex, on peut améliorer l'affichage des graphiques. Il suffit alors
    # d'ajouter la lettre 'r' avant un texte affiché puis la syntaxe latex, comme par exemple r'Position, $x$ (m)'
    # SINON, il faut modifier toutes les sections d'affichage...

    # Mise en forme de l'affichage
    plt.close('all')
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amsmath} \usepackage{lmodern} \usepackage{bm} \usepackage{xcolor}')
    # Options
    params = {'text.usetex' : True,
              'font.size' : 15,
              'font.family' : 'lmodern',
              }
    plt.rcParams.update(params)
    mpl.rcParams['axes.linewidth'] = 1.
    
    ########################################################################################################################
    # Partie 1 : Conduction thermique dans les métaux
    ########################################################################################################################
    # Importation des données acquises au préalable (par ex. à l'aide de Latis Pro)
    dossier = os.listdir('... chemin à compléter...')             # Pour les systèmes Windows, ex F:/
    dossier = os.listdir('/Volumes/.... chemin à compléter....')  # Version MacOS/Linux
    filename = [f for f in dossier if f.endswith('*nom du fichier*.txt')][0] # Récupération du fichier d'intérêt
                                                                             # parmi une liste de fichiers
    data = pd.read_csv('... chemin à  compléter...'+filename,sep=';',decimal=',')
    
    # Affichage des données et ajustement au modèle donné
    plt.figure()
    cmap = plt.cm.rainbow(np.linspace(0,1,6)) # Couleurs utilisées
    # Initialisation des listes des paramètres ajustés
    A1_list = [] 
    Phi1_list = []
    # Paramètres initiaux d'ajustement
    p0_list = [(5,5,5,5,5)]+[(1,1,5e-3,5e-3,5e-3)]*4
    for i in range(0,5):
        # Attribution des données à des variables
        X = data.iloc[:,i*2].to_numpy(dtype=float)
        Y = data.iloc[:,i*2+1].to_numpy(dtype=float)
        # Lissage des données (si necessaire)
        if True:
            X= smooth(X,100)
            Y= smooth(Y,100)
        # Affichage et ajustement par la forme fonctionnelle correspondant a 'oscill'
        plt.plot(X,Y,marker=None,c=cmap[i],label='Capteur %s'%(i+1),alpha=0.5)
        param,cov = scopt.curve_fit(oscill,X,Y,p0=p0_list[i],
                                    bounds=np.array(((0,2*np.pi),(0,2*np.pi),(0,10),(0,10),(0,10))).T,maxfev=1000000)
        Phi1_list.append(param[0])
        A1_list.append(param[3])
        if False: X = np.linspace(0,np.max(X),10000) # pour un affichage plus lisse
        plt.plot(X,oscill(X,*param),ls='--',c=cmap[i],\
                 label='Capteur %s,$\phi_1 = %s$,$\phi_2 = %s$,$A_1 = %s$,$A_2=%s$'%(i+1,'{:0.3e}'.format(param[0]),\
                       '{:0.3e}'.format(param[1]),'{:0.3e}'.format(param[3]),'{:0.3e}'.format(param[4])))
    plt.xlabel('Temps (s)')
    plt.ylabel('Tension (mV)')
    plt.legend()
    plt.show()
    
    # Ajustement des paramètres extraits en fonction de la position du capteur
    plt.figure()
    Xfit = np.linspace(1,5,5)*5e-2 # Position spatiale des capteurs
    # Affichage et ajustement linéaire
    fig,ax = plt.subplots()
    ax.plot(Xfit,np.log(A1_list),marker='+',c='red',ls='None',ms=15)
    ax.set_ylabel(r'$\ln(A_1)$')
    ax1 = ax.twinx()
    ax1.set_ylabel(r'$\phi_1$')
    ax1.plot(Xfit,Phi1_list,c='blue',marker='+',ls='None',ms=15)
    ax.set_xlabel(r'$x_i$')
    ax.yaxis.label.set_color('red') 
    ax1.yaxis.label.set_color('blue')
    param,cov = scopt.curve_fit(temp,Xfit,np.log(A1_list),p0=(10,10),maxfev=10000)
    param1,cov1 = scopt.curve_fit(temp,Xfit,Phi1_list,p0=(10,10),maxfev=10000)
    ax.plot(Xfit,temp(Xfit,*param),ls='--')
    ax1.plot(Xfit,temp(Xfit,*param1),ls='--')
    # Extraction des grandeurs d'intérêt
    print('Delta (1) = %s'%(-1/param[0]))
    print('Delta (2) = %s'%(-1/param1[0]))
    print('Kappa (1) = %s x10-4'%((-1/param[0])**2*np.pi*10e-3*1e4))
    print('Kappa (2) = %s x10-4'%((-1/param1[0])**2*np.pi*10e-3*1e4))
    plt.show()
    
    # Si analyse fréquentielle utile :
    if False:
        plt.figure()
        for i in range(0,5):
            X = data.iloc[:,i*2].to_numpy(dtype=float)
            Y = data.iloc[:,i*2+1].to_numpy(dtype=float)
            # plt.plot(X,Y,marker='+',c=cmap[i],label='Capteur %s'%(i+1))
            plt.plot(np.fft.fftfreq(len(X)),np.abs(np.fft.fft(Y))**2)
        plt.show()
    
    ########################################################################################################################
    # Partie 2 : Conduction électrique dans un métal 
    ########################################################################################################################
    # Définition des grandeurs
    S = (0.80e-3/2)**2*np.pi # Section du fil [ua]
    L = 1710e-2              # Longueur du fil [ua]
    # Données expérimentales
    X = np.array(['... Températures en deg. Celsius à compléter ...'])+273.15             # Températures en Kelvin
    Y = np.array(['... Résistance en mOhms (montage à 4 fils) à compléter ...'])*1e-3*S/L # Résistivités
    
    
    # Affichage et ajustement par la forme fonctionnelle correspondant a 'temp'
    plt.figure()
    plt.plot(X,Y,marker='+',c='red',label='Exp.',ls='None')
    param,cov = scopt.curve_fit(temp,X,Y,p0=(10,10),maxfev=10000)
    if True: Xfit = np.linspace(np.min(X),np.max(X),100) # pour un affichage plus lisse
    plt.plot(Xfit,temp(Xfit,*param),ls='--',c='blue',alpha=0.4,
             label=r'Ajustement, $\alpha = %s \pm %s\, \Omega\cdot\mathrm{m}\cdot\mathrm{K}^{-1}$ , $\rho_0 = %s \pm %s\,\Omega\cdot\mathrm{m}$'%('{:0.3e}'.format(param[0]),'{:0.3e}'.format(np.sqrt(np.diag(cov)[0])),'{:0.3e}'.format(param[1]),'{:0.3e}'.format(np.sqrt(np.diag(cov)[1]))))
    plt.xlabel(r'Température,$T$ (K)')
    plt.ylabel(r'Résistivité, $\Omega \mathrm{m}$')
    plt.legend()
    plt.show()
    
    
    
    
        



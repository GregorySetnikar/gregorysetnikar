#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Effectue une régression linéaire sur un jeu de données. 
Entrée : données et incertitudes associées.
Sortie : paramètres de la régression linéaire avec incertitude, chi2/(N-p), représentation graphique des données et de la régression.

Dépendances:

Usage: python python_LinearRegression_lyon.py

Auteurs: Agrégatifs de Lyon 2021-2022
"""


import numpy as np
import matplotlib.pyplot as plt

### Fonctions ###
def Reglin(x,y,nx,ny,Delta_x,Delta_y,ymin=0,ymax=0):
    """
    x et y : np.array des données
    nx et ny : nom des données (axes)
    Delta_x et Delta_y : np.array des incertitudes
    """
    
    plt.figure(figsize=(8,6))
    plt.xlabel(nx)
    plt.ylabel(ny)
    if ymin != ymax:  #Les ordonnées extrêmales sont imposées par l'utilisateur
        plt.ylim(ymin,ymax)
    
    a,b = np.polyfit(x,y,1)   #Determination des meilleurs paramètres (a,b) pour polynôme de degré 1
    #yfit = a*x + b           #Ordonnées
    xfit=np.linspace(min(x),max(x),2) #Abscisses extêmales
    plt.plot(xfit, a*xfit + b, 'r', label='Régression linéaire') #Tracé de la régression
    
    plt.errorbar(x,y,xerr=Delta_x,yerr=Delta_y,fmt='x',label='Mesures') #Tracé des valeurs expérimentales avec leurs incertitudes
    plt.legend()
    plt.show()
    
    #Prise en compte des incertitudes
    N=10000 #Nombre de jeux de données simulés
    ta,tb=[],[]
    
    for i in range(0,N): #Génère les N jeux de données
        nbpts = len(x) 
        mx = x + Delta_x*np.random.uniform(-1,1,nbpts) #Génère une liste de x dans son intervalle d'incertitude
        my = y + Delta_y*np.random.uniform(-1,1,nbpts) #Génère une liste de y dans son intervalle d'incertitude
    
        p=np.polyfit(mx,my,1) #Régression linéaire du jeu calculé
        
        ta.append(p[0]) #Stockage des paramètres de régression (pente)
        tb.append(p[1]) #Stockage des paramètres de régression (ord. origine)
    
    
    #Moyenne et incertitude sur la pente et l'ordonnée à l'origine
    #am = np.mean(ta) #Moyenne des coefficients de la régression avec les données des N jeux
    #bm = np.mean(tb)
    u_a = np.std(ta) #Ecart-type sur ces coefficients
    u_b = np.std(tb)
    
    print ("Pente :", a ,"±", u_a)
    print ("Ordonnée à l'origine :", b ,"±", u_b)
    print ("1/ord :", 1/b ,"±", u_b/(b**2),"cm")

    #Calcul du chi2/(N-p) avec N le nombre de points considérés et p le nombre de paramètres de la régression
    r=[]
    chi2=0
    for i in range(0,len(x)):
        X=x[i]
        Y=y[i]
        R=a*X+b
        chi2 += abs((Y-R)**2/(Delta_y[i]**2))
        r.append(R)

    print('chi2/(N-p) :', chi2/(len(x)-len(p)))
    
    return(a,u_a,b,u_b)


if __name__ == "__main__":
   #Exemple avec un des quartets d'Anscombe
   x=np.array([10,8,13,9,11,14,6,4,12,7,5])
   y=np.array([8.04,6.95,7.58,8.81,8.33,9.96,7.24,4.26,10.84,4.82,5.68])
   nx="x"
   ny="y"
   Delta_x=0.02*np.ones(len(x))
   Delta_y=2*np.ones(len(y))
   Reglin(x,y,nx,ny,Delta_x,Delta_y,0,0)


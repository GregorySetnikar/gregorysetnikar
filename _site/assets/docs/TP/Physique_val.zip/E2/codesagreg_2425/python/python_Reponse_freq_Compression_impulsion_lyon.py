#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Estimation de la réponse fréquentielle d'un canal (milieu physique) ou dispositif (ex : impédance acoustique d'un haut-parleur)
à partir d'un signal d'autocorrélation piqué ('chirp' ou 'sweep' linéaire, bruit blanc, impulsion gaussienne) ayant traversé le
milieu canal.

Ce script utilise une technique de traitement du signal appelée "compression d'impulsion" qui réalise une opération
d'intercorrélation entre le signal émis et le signal reçu. Cette technique rend l'estimation très peu sensible aux
perturbations et bruits de mesure, contrairement aux méthodes conventionnelles.
(cf par exemple : https://fr.wikipedia.org/wiki/Compression_d%27impulsion)

Les données sont prises en charge au format csv pour être directement exploitables à partir du logiciel LatisPro.
Elles doivent contenir a minima les trois colonnes suivantes :

        EA0 : signal effectivement envoyé à l'entrée du canal.
        EA1 : signal reçu à la sortie du canal.
        Temps : liste des valeurs de temps communes des données EA0 et EA1.

Le script renvoie d'abord une estimation 'estimated_impulse_response' de la réponse impulsionnelle "h" telle que EA1 = h * EA0,
où * désigne l'opération de convolution. Il calcule ensuite sa transformation de Fourier pour trouver une estimation de la
réponse fréquentielle "H" (telle que Fourier[EA1] = H.Fourier[EA0], où . désigne le produit numérique).

Dépendances:

Usage: python python_Reponse_freq_Compression_impulsion_lyon.py

Auteurs: Agrégatifs de physique 2023-2024
"""


import sys
import numpy as np
import scipy.signal as scsig
import matplotlib.pyplot as plt
import pandas as pd

# ================== A MODIFIER PAR L'UTILISATEUR ==================
# Nom du dossier ("folder") et du fichier csv ("filename") à charger
folder = "C:/Users/ens/Desktop/Agrégatifs 2023-2024"

filename = "Compression_impulsion_chirp_DATA_FOR_TESTING.csv"

# Nom des colonnes contenant les données
emitted_signal = "EA0" # Signal émis (unités arbitraires)
received_signal = "EA1" # Signal reçu (unités arbitraires)
time = "Temps" # Temps [s]

# Les cases vides du tableur sont-elles à omettre ? (oui = 'True', non = 'False')
ignore_nan = True

# =================== NE DEVRAIT PAS ÊTRE MODIFIE ===================

# Lecture du fichier csv en tant que pandas.dataframe
sys.path.append(folder)
try:

    df = pd.read_csv(filename, sep = ";")
except:
    try:
        os.chdir(folder)
        df = pd.read_csv(filename, sep = ";")
    except:
        print("ERREUR : le fichier est introuvable.")

if ignore_nan:
    df = df.dropna()

# Transformation du 'pandas.dataframe' en 'numpy.array'
time = df[time] 
data1 = df[emitted_signal]
data2 = df[received_signal]
time = np.array(time)
data1 = np.array(data1)
data2 = np.array(data2)

# Calcul de la période d'échantillonnage
sampling_period = np.mean(np.diff(time)) # [s]
#sampling_period = 100*10**(-6) # [s]
sampling_frequency = 1/sampling_period # [Hz]

# "Compression d'impulsion" (intercorrélation entre les signaux émis et reçu)
N0 = len(time)
assert len(data1) == len(data2) and len(data1) == len(time), "Les données sont invalides : le signal émis (EA0) et reçu (EA1) doivent être de même taille."
estimated_impulse_response_raw = scsig.correlate(data2, data1)

# Ajout d'un point (suréchantillonnage avec un '0') pour s'assurer que le nombre de points est pair, et ainsi accélérer
# le calcul de la Transformée de Fourier directe avec l'algorithme de Transformation de Fourier Rapide FFT
estimated_impulse_response = np.concatenate((estimated_impulse_response_raw, np.array([0])))
N = len(estimated_impulse_response)

# Si une décimation est utile, indiquer ici le nombre de points à utiliser pour calculer la Transformée de Fourier discrète.
# Par défaut, le nombre de points est N = 2*N0 + 2
decimation_nb_pts = N

estimated_Fourier_transform = 1/(decimation_nb_pts*sampling_frequency)* np.fft.fftshift(np.fft.fft(estimated_impulse_response, n=decimation_nb_pts))

# Transformée de Fourier en module et en phase, réponse impulsionnelle :
Frequency_response_MODULE = np.abs(estimated_Fourier_transform)
Frequency_response_PHASE = np.unwrap(np.angle(estimated_Fourier_transform)) - np.mean(np.unwrap(np.angle(estimated_Fourier_transform)))
Impulse_response = estimated_impulse_response[round(N/2):]

# =================== AFFICHAGE DES RESULTATS ===================
plt.close("all")

#Création  d'une liste de temps de N points entre "-t_max" et "+t_max", où 't_max' désigne la valeur maximale des temps
time_lags = np.arange(-N0, N0)*sampling_period
# Création d'une liste de fréquences de N points entre "- sampling_frequency/2" et "+ sampling_frequency/2 - 1" inclus
frequency_list = np.arange(-decimation_nb_pts/2, decimation_nb_pts/2)/decimation_nb_pts*sampling_frequency

plt.figure()
plt.plot(time_lags, estimated_impulse_response)
plt.xlabel(r"Décalages en temps $\tau$ [s]")
plt.ylabel(r"$\Gamma_{EA0,EA1}(\tau)$")
plt.title("Intercorrélation des signaux")

plt.figure()
plt.plot(time, Impulse_response)
plt.xlabel(r"Temps $t$ [s]")
plt.ylabel(r"$h(t)$")
plt.title("Réponse impulsionnelle")

plt.figure()
plt.plot(frequency_list, Frequency_response_MODULE)
plt.xlabel(r"Fréquence $\nu$ [Hz]")
plt.ylabel(r"$|H|(\nu)$")
plt.title("Réponse fréquentielle en MODULE")

plt.figure()
plt.plot(frequency_list, Frequency_response_PHASE)
plt.xlabel(r"Fréquence $\nu$ [Hz]")
plt.ylabel(r"$arg[H](\nu) [rad]$")
plt.title("Réponse fréquentielle en PHASE")

plt.show()




#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
#Ce script affiche la courbe de la loi d'emission du corps noir de Planck, avec un slider pour pouvoir changer la temperature.
Il affiche egalement la couleur associée a l'émission, avec un algorithme basé sur des lois empiriques convertissant la temperature en donnees RGB

#Rq : uniquement la couleur de l'émission est représentée, par son intensité, comme elle varie en T^4 il est difficile d'afficher de telles variations sur un écran

''' 


import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.widgets import Slider, Button
import matplotlib
import scipy.constants as cst 
from matplotlib import patches
matplotlib.rc('xtick', labelsize=24) 
matplotlib.rc('ytick', labelsize=24) 
matplotlib.rcParams.update({'font.size': 22})


#Constantes-------------------------
h = cst.h
c = cst.c
k = cst.k



lamda = np.arange(0.3,10,0.001)*10**(-6)
nu = c/lamda


T = 3000
u = 8*np.pi*h*nu**3/c**3* 1 / (np.exp(h*nu/(k*T))-1)        #Densite spectrale en frequence [J*s/m^3]

ratio = u*c**3/(nu**3*8*np.pi*h)



fig = plt.figure()
plt.subplots_adjust(bottom=0.20)

ax1 = plt.axes([0.20,0.20,0.65,0.65])
ax1.plot([0, 1e15], [1, 1], '--k', lw = 2)
ax1.plot(nu,ratio, '-r', lw=4)


ax1.set_title('Emission stimulée et spontanée dans le cas du corps noir')
ax1.set_xlabel(r"$\nu (\mathrm{Hz})$")
ax1.set_ylabel(r"$N_{stimul}/N_{sponta}$")

#l1, = ax1.plot([0.4, 0.4], [0, 200], '--', color = 'gray',  zorder = 0, lw=2)
#l2, = ax1.plot([0.8, 0.8],[0, 200], '--', color = 'gray', zorder = 1, lw=2)
ax1.set_ylim([0., 2])


def rect(x,y,w,h,c) :
    polygon = plt.Rectangle((x,y), w, h, color = c)
    ax1.add_patch(polygon)

    
    
def rainbow(X, Y, cmap = plt.get_cmap("jet")) :
    dx = X[1]-X[0]
    N = float(X.size)
    
    for n, (x,y) in enumerate(zip(X,Y)) :
        color = cmap(n/N)
        rect(x,0,dx,y,color)

    
X = c/(np.arange(0.4, 0.801, 0.005)*10**(-6))
Y = ratio[99:500:5]
rainbow(X,Y)



#Slider de temperature
axTemp = plt.axes([0.20,0.04,0.65,0.03])
sTemp = Slider(axTemp, 'Temperature (en $K$)', valmin=1000, valmax=15000, valinit=T, valfmt='%0.f')
def update(val):
    yl = ax1.get_ylim()
    ax1.clear()
    T = sTemp.val
    u1 = 8*np.pi*h*nu**3/c**3* 1 / (np.exp(h*nu/(k*T))-1)
    ratio = u1*c**3/(nu**3*8*np.pi*h)
    
    ax1.plot([0, 1e15], [1, 1], '--k', lw = 2)
    ax1.plot(nu,ratio, '-r', lw=4)
    
    ax1.set_title('Emission stimulée et spontanée dans le cas du corps noir')
    ax1.set_xlabel(r"$\nu (\mathrm{Hz})$")
    ax1.set_ylabel(r"$N_{stimul}/N_{sponta}$")
    
    ax1.set_ylim(yl)
    Y = ratio[99:500:5]
    rainbow(X,Y)
sTemp.on_changed(update)



#Rescale button
axBout = plt.axes([0.35,0.6,0.1,0.05])
Breset = Button(axBout, 'Rescale')
def rescale(event):
    u = ax1.lines[0].get_ydata()
    ax1.set_ylim([0,max(u)*1.1])
Breset.on_clicked(rescale)

##mng = plt.get_current_fig_manager()     #Plein ecran
##mng.window.showMaximized()
plt.show()

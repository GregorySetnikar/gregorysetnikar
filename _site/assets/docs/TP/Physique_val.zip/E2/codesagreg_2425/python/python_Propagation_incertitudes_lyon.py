#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Propagation des incertitudes par la méthode de Monte-Carlo

Le principe consiste à déterminer une estimation de la valeur moyenne et de l'écart-type pour la loi que suit une variable
aléatoire Y définie par une forme fonctionnelle y(x1,x2,x3,...). Pour chaque variable aléatoire xi dont elle dépend,
l'utilisateur prescrit le type de la loi suivie (normale, uniforme, triangulaire symétrique), ainsi que la valeur moyenne
et l'écart-type correspondants.

Dépendances:

Usage: python python_Propagation_incertitudes_lyon.py

Auteurs: C. Winisdoerffer (13/02/2024)
"""

# Importation des librairies
import numpy as np              # import. de la librairie numpy, raccourci np
import scipy.stats as scstat    # import. de la (sous-)librairie scipy.stats
import matplotlib.pyplot as plt # import. de la (sous-)librairie matplotlib.pyplot


# Définition des classes
class RandomVariable:
   """ Classe associée à une variable aléatoire """
   def __init__(self,law='normal',mean=0,std=0.1):
      """ Constructeur """
      self.law  = law
      self.mean = mean
      self.std = std
   def generate_data(self, n_MC):
      """ Génération d'un échantillon de dimension n_MC suivant la loi prescrite """
      if self.law == 'normal':
         self.data = np.random.normal(self.mean,self.std,size=n_MC)
      elif self.law == 'uniform':
         self.data = np.random.uniform(self.mean-self.std*np.sqrt(3),self.mean+self.std*np.sqrt(3),size=n_MC)
      elif self.law == 'triangular':
         self.data = np.random.triangular(self.mean-self.std*np.sqrt(6),self.mean,self.mean+self.std*np.sqrt(6),size=n_MC)
      else:
         print('Not implemented yet !!!')
         self.data = self.mean*np.ones(n_MC)

# Définition des fonctions
def FreedmanDiaconis(x):
   """ Estimation du nombre 'optimal' de bins a considérer dans un histogramme à l'aide de la règle de Freedman-Diaconis """
   p25, p75 = np.percentile(x, [25, 75])
   width = 2*(p75-p25)/x.size**(1./3)
   nbins = int(np.ceil((x.max()-x.min())/width))
   return nbins

#=========================================================================================
# C'est à l'utilisateur de définir cette forme fonctionnelle. Un exemple est donné...
#=========================================================================================
def func(*args):
   """ Définition de la forme fonctionnelle """
   if True: # un exemple, qui depend de 5 parametres: f(a,b,c,d,e) = a*b*c/(d*np.log(1+abs(e)))
      y = args[0]*args[1]*args[2]/(args[3]*np.log(1+abs(args[4])))
   else:
      pass
   return y

# Programme principal
if __name__ == "__main__":
   # Initialisation du Monte-Carlo
   seed = 1691989345            # seed pour initialiser le générateur de nombres aléatoires
   np.random.seed(seed)         # initialisation du random generator
   # Nombre de tirages aléatoires générant des données simulées à partir des mesures expérimentales
   n_MC = 10000
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des variables aléatoires qui apparaissent
   # dans la forme fonctionnelle définie ci-dessus.  Une variable aléatoire correspond à la donnée d'une loi (parmi
   # 'uniform', 'triangular', 'normal'), d'une moyenne et d'un écart-type (avec une écriture explicite pour faciliter la
   # lecture du script...). 
   # Attention, on rappelle que pour:
   #   - une loi uniforme de support [-a;a] ie de largeur 2a, std = a/sqrt(3)
   #   - une loi triangulaire [symétrique] de support [-a;a] ie de largeur 2a, std = a/sqrt(6)
   if True:
      a = RandomVariable(law='uniform',    mean=1, std=0.1) ; a.generate_data(n_MC)
      b = RandomVariable(law='uniform',    mean=2, std=0.1) ; b.generate_data(n_MC)
      c = RandomVariable(law='triangular', mean=3, std=0.1) ; c.generate_data(n_MC)
      d = RandomVariable(law='normal',     mean=4, std=0.1) ; d.generate_data(n_MC)
      e = RandomVariable(law='normal',     mean=1, std=0.1) ; e.generate_data(n_MC)
   else:
      pass
   # Génération des données simulées selon la forme fonctionnelle prescrite précédemment. Cette ligne
   # doit etre adaptée en fonction du nombre de variables dont dépend y = y(x1,x2,x3,...)
   y = func(a.data, b.data, c.data, d.data, e.data)

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   if True: # pour vérifier que les lois sont bien celles espérées...
      for x in [a.data, b.data, c.data, d.data, e.data]:
         print(np.mean(x),np.std(x))
         nbins = FreedmanDiaconis(x)
         fig = plt.figure(figsize=(10, 8))
         plt.hist(x,bins=nbins)
         plt.title("(avg,std) = ({:.3f},{:.3f})".format(np.mean(x),np.std(x)))
         plt.show()
   # Caractérisation de la loi parente associée à la forme fonctionnelle prescrite
   print("Les estimations de la valeur moyenne et de l'ecart-type de la loi suivie par Y sont:\n"
         "      avg = {}     et      std = {}".format(np.mean(y), np.std(y)))
   # Plot
   nbins = FreedmanDiaconis(y)
   fig = plt.figure(figsize=(10, 8))
   histo = plt.hist(y,bins=nbins)
   hist, bins = histo[:2]
   bin_width  = bins[1]-bins[0]
   # Fit de l'histogramme
   mfit, sfit = scstat.norm.fit(y)
   best_fit   = scstat.norm.pdf(bins, mfit, sfit)
   plt.plot(bins, best_fit*np.sum(hist)*bin_width,
            label='Mod. loi normale\n (avg, std) = ({:4.3f},{:4.3f})'.format(mfit,sfit))
   plt.title('Propagation des incertitudes: histogramme MC')
   plt.legend()
   if True:
      plt.savefig('incertitudes.png')
   plt.show()
   
   


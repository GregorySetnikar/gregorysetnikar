#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script qui permet de determiner graphiquement "la" solution de l'equation m=tanh(m Tc/T), equation qui
apparait dans le modele d'Ising + champ moyen dans l'ensemble canonique, et qui permet de discuter la
transition ferromagnetique-paramagnetique.
Un slider permet de modifier de facon interactive la temperature T.

Dépendances:

Usage: python python_Transition_ferro-para_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button

# Definition des fonctions
def func_lhs(m):
   """ Fonction correspondant au membre de gauche de l'eq. m=tanh(m Tc/T) """
   return m

def func_rhs(m, T, Tc):
   """ Fonction correspondant au membre de droite de l'eq. m=tanh(m Tc/T) """
   return np.tanh(m * (Tc/T))

def update(val, fig, line, m, Tc):
   """ Gestion de l'interaction slider-plot """
   line.set_ydata(func_rhs(m,val,Tc))
   fig.canvas.draw_idle()
   return

def reset_wrapper(slider):
   """ Gestion de l'interaction bouton-plot """
   def clicked(event):
      slider.reset()
      return
   return clicked


# Programme principal
if __name__ == "__main__":
   # Valeurs par defaut
   default_Tc    = 1040 # Temperature critique [K], avec Tc = zJ/k_B avec les notations trad. d'Ising
   default_Tinit = 300  # Temperature initiale du slider [K]
   # Interaction avec l'utilisateur
   if True:
      jnk = input("Temperature critique [K]: ")
      try:
         Tc = float(jnk)
      except ValueError:
         Tc = default_Tc
         print('Réponse non valable --> valeur par defaut Tc= {}'.format(Tc))
      jnk = input("Temperature initiale du slider [K]: ")
      try:
         Tinit = float(jnk)
      except ValueError:
         Tinit = default_Tinit
         print('Réponse non valable --> valeur par defaut Tinit= {}'.format(Tinit))

   # Initialisation de l'intervalle de m
   m = np.linspace(-1.5, 1.5, 1000)

   # Plot
   fig, ax1 = plt.subplots()
   ax1.plot(m,func_lhs(m),color='black',label='m')
   line, = ax1.plot(m,func_rhs(m,Tinit,Tc),lw=2,color='red',label='tanh(m*Tc/T)')
   ax1.set_xlabel('m', fontsize=15)
   ax1.set_xlim(np.amin(m),np.amax(m))
   ax1.set_ylim(np.amin(m),np.amax(m))
   plt.legend()

   # Ajustement de la position du plot pour faire de la place pour les widgets
   fig.subplots_adjust(left=0.1, bottom=0.25)
   
   # Slider horizontal pour controler la temperature
   axT = fig.add_axes([0.25, 0.1, 0.65, 0.03])
   slider_T = Slider(ax=axT, label='Température [K]', \
                    valmin=Tinit/2, valmax=Tc+Tinit, valinit=Tinit)
   # Mise a jour du plot lorsque le slider est modifie
   slider_T.on_changed(lambda newval: update(newval, fig, line, m, Tc))
   # Bouton 'reset'
   resetax = fig.add_axes([0.8, 0.025, 0.1, 0.04])
   button = Button(resetax, 'Reset', hovercolor='0.975')
   # Reset du plot lorsque le bouton est modifie
   button.on_clicked(reset_wrapper(slider_T))

   # Visualisation
   plt.show()

   
   





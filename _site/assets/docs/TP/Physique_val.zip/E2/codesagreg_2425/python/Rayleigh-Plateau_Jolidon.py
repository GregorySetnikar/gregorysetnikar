#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Instabilité de Rayleigh-Plateau, script inspiré de celui présentée dans la Ref. "Physique expérimentale, Optique, magnétisme,
électrotechnique, mécanique, thermodynamique et physique non linéaire", Jolidon (2021).
Il permet de traiter une (ou plusieurs) image(s) et d'obtenir la la longueur d'onde associée.

Dépendances:

Usage: python python_Rayleigh-Plateau_Jolidon.py

Auteurs: Agrégatifs de physique 2022-2023

"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from scipy import ndimage
import os

# Definition des fonctions
def traitement_image(frame,treshold,size_min,conversionpxl_m,i1,i2,j1,j2):
    """
    On prend en entrée une image notée frame, ainsi que divers paramètres qu'il convient de régler en amont
    On obtient en sortie une valeur correspondant à la longueur d'onde moyenne d'une part, une liste contenant les tailles
    de toutes les gouttes sur l'image d'autre part
    """
      
    plt.gray()
    
    image = plt.imread(frame)
    drops = image[j1:j2, i1:i2, 0]              # On restreint l'étude au cadre (i1,i2),(j1,j2)
   
    binary = (drops > drops.mean())             # Seuillage de la figure
    img = ndimage.binary_opening(binary)        # Image nettoyée

    if (img.mean() > treshold) :  # On ne considère que les images ayant un minimum d'intensité
                                  # pour éviter de considérer les images noires
        label_im, nb_labels = ndimage.label(img)                            # On étiquette chaque goutte
    
        # On élimine les gouttes sattelites d'après la taille d'une goutte
        sizes = ndimage.sum(img,label_im,range(nb_labels+1))     # On liste la taille de toutes les gouttes observées
        mask_size = sizes < size_min                             # On sélectionne les gouttes trop petites pour les supprimer ensuite
        remove = mask_size[label_im]
        img[remove] = 0
        label_im2, nb_labels2 = ndimage.label(img)               # On étiquette à nouveau les gouttes après avoir supprimé les gouttes sattelites
        
        # On calcule les isobarycentres des gouttes restantes
        bar = ndimage.center_of_mass(img, label_im2, range(1,nb_labels2+1)) 
        
        # Calcul de la longueur d'onde moyenne de l'image
        list_bar = np.array(bar)[:,0]
        list_spaces = list_bar[1:]-list_bar[:-1]                 # On mesure l'écart (en pixels) entre deux centres de gouttes
        mean_wave = np.mean(list_spaces)/conversionpxl_m         # On récupère la longueur d'onde moyenne de l'image
        
        # Calcul du rayon des gouttes
        sizes  = np.array([size for size in sizes if size > size_min])      # On ne récupère pas les gouttes sattelites
        rays = np.sqrt(sizes/np.pi)/conversionpxl_m                         # On a S = pi*R^2 et le nombre de pixel est associé à la surface observée
    return mean_wave, rays.tolist()

#%% Définition des paramètres d'analyse (commun à toutes les images)
# Programme principal
if __name__ == "__main__":
   pix_to_m =                       # A MODIFIER : Conversion pixel/mm
   i1, i2, j1, j2 =        # A MODIFIER : Zone à étudier sur l'image
   R0 =                                 # A MODIFIER : rayon r0 (en mm) de la colonne d'eau avant déstabilisation
   treshold =                 # Permet de retirer les images noires
   size_min =                 # On ne garde que les gouttes ayant une taille minimale (on retire les gouttes satellites)


   # Analyse de toutes les images présentes dans le répetoire courant
   # (/!\ il faut que le document.py soit en tête de liste /!\)
   path = os.getcwd()                                      # On se place dans le répertoire courant
   list_images = os.listdir(path)[1:]                      # On récupère tous les fichiers sauf le document.py
   mean_wave = []
   rayons = []
   for frame in list_images :                              # On applique la fonction à toutes les images du film
       taille, rayon = traitement_image(frame, treshold, size_min, pix_to_m, i1, i2, j1, j2)
       mean_wave.append(taille)
       rayons += rayon
   
   lambd_moy = np.mean(mean_wave)                          # Moyenne de toutes les longueurs d'onde
   u_lambda = np.std(mean_wave)                            # Ecart-type de la longueur d'onde
   ray_moy = np.mean(rayons)                               # Moyenne de tous les rayons de gouttes
   u_ray = np.std(rayons)                                  # Ecart-type du rayon
   
   # Affiche de l'histogramme associé à la longueur d'onde moyenne
   plt.figure()
   plt.hist(mean_wave,25,edgecolor='k')
   plt.xlabel('$\lambda$ (mm)')
   plt.ylabel("nombre d'évènements")
   plt.axvline(lambd_moy,color='r', label=fr'$\langle \lambda \rangle$ = {lambd_moy : ^.3f} mm')
   plt.legend()
   plt.show()

   # Affichage de l'histogramme associé au rayon moyen des gouttes
   plt.figure()
   plt.xlabel('rayon des gouttes (mm)')
   plt.ylabel("nombre d'évènements")
   plt.hist(rayons, 30,edgecolor='k')
   plt.axvline(ray_moy,color='r', label=fr'$\langle r \rangle$ = {ray_moy : ^-.3f} mm')
   plt.legend()
   plt.show()
   
   #%% Vérification de la relation liant lambda et le rayon de la colonne initiale d'eau

   rapport = lambd_moy / R0
   u_rapport = rapport*u_lambda/lambd_moy

   print(f'Le rapport lambda/r est : {rapport : ^.3f} +- {u_rapport : ^.3f} \n')


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Résolution graphique pour trouver la progression optimale de température dans un RP 

4 : Xeq, POT et optimum isotherme


pour une réaction A-> P et une réaction d'ordre 1 par rapport à chacun des réactifs


Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France
Licence : Creative Commons CC-BY-NC-SA 4.0 

"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.constants as sc
import scipy.optimize as opti
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import scipy.integrate as integrate
from scipy import interpolate
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def KT(T,A,Ea,B,Eb):
    ka=A*np.exp(-Ea/(sc.R*T))
    kb=B*np.exp(-Eb/(sc.R*T))
    return ka/kb

def derxttau(T,dT,A,Ea,B,Eb,tau,T2,gradX):
    indixT = np.argmin(np.abs(T2-T))
    return gradX[indixT] 


def r(T,A,Ea,B,Eb,x):
    K = KT(T,A,Ea,B,Eb)
    Xeq = K/(1+K)
    ka=A*np.exp(-Ea/(sc.R*T))
    return ka*(1-x/Xeq)

def invr(x,T,A,Ea,B,Eb):
    return 1/r(T,A,Ea,B,Eb,x)

def xttau(T,A,Ea,B,Eb,tau):
    K = KT(T,A,Ea,B,Eb)
    ka=A*np.exp(-Ea/(sc.R*T))
    Xeq = K/(1+K)
    return Xeq*(1-np.exp(-ka*tau/Xeq))


if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RP-cmp-XT-isotherme-POT.svg"
    #Range of values where the data will be evaluated
    x1 =np.logspace(-20,np.log10(0.1),1001)
    x2 =np.linspace(0.1+1e-4,1,1001)
    x =np.concatenate(([0],x1,x2))
    #print(x)
    x=np.linspace(0,1,1000)
    T,dT =np.linspace(250,420,1000,retstep = True)
    tauss=np.logspace(-3,3,1000)

    xx,TT = np.meshgrid( x, T, indexing='ij')

    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)#,  width_ratios=(1, 1), height_ratios=(2, 1), left=0.08, right=0.95, bottom=0.05, top=0.95, wspace=0.18, hspace=0.3
    ax2 = fig.add_subplot(gs[0,0])
 
    A = 2.95e7
    B = 1.57e18
    Ea = 46.4e3
    Eb = 118.4e3

    K = KT(T,A,Ea,B,Eb)
    Xeq = K/(1+K)
    ToptYield = []
    optYield = []
    fullR= r(TT,A,Ea,B,Eb,xx)
    derTr = np.gradient(fullR,dT,axis=1) 
    
    T2,dT2 =np.linspace(250,420,1000,retstep = True)

    ToptYield = []
    #compute the value which maximizes the yield
    for idx,tau in enumerate(tauss):
        XT = xttau(T2,A,Ea,B,Eb,tau)
        gradX = np.gradient(XT,dT2) 
        if idx==0:
            sol = opti.brentq(derxttau,300,500,args=(dT,A,Ea,B,Eb,tau,T2,gradX))
        else:
            sol = opti.brentq(derxttau,ToptYield[idx-1]-20,ToptYield[idx-1]+10,args=(dT,A,Ea,B,Eb,tau,T2,gradX))
        ToptYield.append(sol)

    optYield=xttau(np.asarray(ToptYield),A,Ea,B,Eb,tauss)

    Tpot = []
    rTpot = []

    #compute the value which maximizes the yield
    for idx,xsol in enumerate(x):
        iTopt = np.argmax(fullR[idx,:])
        Topt = T[iTopt]
        Tpot.append(Topt)
    rTpot = r(np.asarray(Tpot),A,Ea,B,Eb,x)

    Tpot=np.asarray(Tpot)

    taus=[]
    #tau opti pour une conversion donnée : on intègre numériquement l'inverse de la vitesse le long de la POT
    for idx,xsol in enumerate(x[1:]):
        tau = integrate.simps(1/rTpot[x<xsol], x[x<xsol])
        taus.append(tau)
    taus= np.asarray(taus)


    tck = interpolate.splrep(x[1:],taus)
    tausSpline= interpolate.splev(optYield, tck)
  #plot a vertical line at zero to give a hint on where it lies
    #ax1.axhline(1,color='#cccccc')
    colors = ['#bfd3e6','#8c96c6','#8c6bb1','#88419d','#810f7c','#4d004b']
    ls=[(0, (3, 1, 1, 1, 1, 1)),':','--','-','-.','-','-','-','-']


    ax2.plot(T,Xeq,label='$X_{eq}(T)$') 
    ax2.plot(ToptYield,optYield,label='$T^\mathrm{opt}_\mathrm{isotherme}$') 
    ax2.plot(Tpot,x,label='$T_{\mathrm{POT}}$') 


    ax2.legend(loc='upper left')
    #labels for the axis and title of the graph
    ax2.set_xlabel('$T$')
    ax2.set_ylabel('$X$')
    #set limits to the plotted data (to crop for example)
    ax2.set_ylim(0,1.05)
    ax2.set_xlim(min(T),max(T))
    #show or hide the bounding axes

    ax2.spines['top'].set_visible(False)
    ax2.spines['right'].set_visible(False)
    plt.tight_layout()
    plt.savefig(fileOutput)
    plt.show()


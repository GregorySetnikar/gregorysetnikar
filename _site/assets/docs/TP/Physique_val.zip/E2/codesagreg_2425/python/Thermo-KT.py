#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Plot a function into a pdf file (vectorial form) from matplotlib

The most basic use is to change the function func and probably the boundaries of x 
"""

# Importation des librairies
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import scipy.constants as sc
import matplotlib.ticker as tick
#Changing the decimal separator to a comma
import locale
locale.setlocale(locale.LC_NUMERIC, "fr_FR.utf8")
mpl.rcParams['axes.formatter.use_locale'] = True

# Definition des fonctions
def func(T,A,Ea,B,Eb):
    ka=A*np.exp(-Ea/(sc.R*T))
    kb=B*np.exp(-Eb/(sc.R*T))
    return ka/kb

def xt(Xeq,tau,A,Ea):
    ka=A*np.exp(-Ea/(sc.R*T))
    return Xeq*ka*tau/(Xeq+ka*tau)

if __name__ == "__main__":
    #Name of the output file
    fileOutput = "RPAC-thermo-KT.svg"
    #Range of values where the data will be evaluated
    x =np.linspace(0,1,1000)
    T =np.linspace(250,420,1000)
    A = 2.95e7
    B = 1.57e18
    Ea = 46.4e3
    Eb = 118.4e3

    #starting the figure
    fig = plt.figure(figsize=(8,6))
    gs = fig.add_gridspec(1, 1)#,  width_ratios=(1, 1), height_ratios=(2, 1), left=0.08, right=0.95, bottom=0.05, top=0.95, wspace=0.18, hspace=0.3
    ax1 = fig.add_subplot(gs[0,0])
    #plot a vertical line at zero to give a hint on where it lies
    #ax1.axhline(1,color='#cccccc')
    colors = ['#bfd3e6','#8c96c6','#8c6bb1','#88419d','#810f7c','#4d004b']
    ls=[(0, (3, 1, 1, 1, 1, 1)),':','--','-','-.']
    liste = [1e-2,0.1,1,5,20]
    K = func(T,A,Ea,B,Eb)
    Xeq = K/(1+K)
    ax1.plot(T,Xeq, color ='#000000' ,ls='-',label = 'X_\mathrm{eq}')# ,label='$\\tau = {}$'.format(liste[i]))
    for i in range(len(liste)) :
        ax1.plot(T,xt(Xeq,liste[i],A,Ea), color = colors[i],ls=ls[i],label = '{}'.format(liste[i]))


    ax1.legend(loc='upper right')
    #ax1.set_yscale('log')
    #ax1.set_xscale('log')
    #labels for the axis and title of the graph
    ax1.set_xlabel('$T$')
    ax1.set_ylabel('$X$')
    #ax1.set_title('Potentiel de Lennard-Jones')
    #set limits to the plotted data (to crop for example)
    #ax1.set_ylim(-1.1,1.1)
    #ax1.set_ylim(min(y),max(y))
    ax1.set_xlim(min(T),max(T))
    #show or hide the bounding axes
    ax1.spines['bottom'].set_visible(True)#.set_position('zero')
    ax1.spines['top'].set_visible(False)
    ax1.spines['right'].set_visible(False)
    ax1.spines['left'].set_visible(True)
    #change the position of the ticks
    #plt.setp(ax1.get_xticklabels(), position=(-1.,0.12))
    #plt.legend(loc='upper left')
    plt.savefig(fileOutput)
    plt.show()


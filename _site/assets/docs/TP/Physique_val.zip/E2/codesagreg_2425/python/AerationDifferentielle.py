#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Python code provided as is.
Made by Vincent Wieczny, from Chemistry Department, ENS de Lyon, France
This code is under licence CC-BY-NC-SA. It enables you to reuse the code by mentioning the orginal author and without making profit from it.
This code is using python_widgets_lyon.py that you need to download in the same diretory as the main Python file.
"""

#Librairies
import matplotlib.pyplot as plt
import numpy as np
import python_widgets_lyon as widgets
import scipy.constants as constants
from matplotlib import rc


################################
### Paramater initialization ###
################################

#Physical constants
F=96500.0 #Faraday number (C/mol)
R=8.314 #Gas constant (J/K/mol)
T=298.0 #Temperature (K)

#Redox system data

#O2/H2O
pH=5
E_std_O2=1.23-0.06*pH #standard potential (V/SHE)

D_O2=1e-9


#Fe2+/Fe
E_std_Fe=-0.44 #standard potential (V/SHE)
D_Fe2=1e-9
c0_Fe2=1e-3 #titrated concentration (mol/L)

#Electrochemical setup and system
delta=1e-5 #diffuse layer thickness (m)
n=1 #number of exchanged electrons
A=1e-5 #electrode area (m²)
alpha = 0.5 #Buttler-Volmer coefficient

## Modulated parameters concentration in O2 deliberately exagerated for a better vizualisation

parameters = {'C_O2_1' : widgets.FloatSlider(value=3.0, description='${[O_2]_1}$', min=0.001, max=3),
            'C_O2_2' : widgets.FloatSlider(value=3.0, description='${[O_2]_2}$', min=0.001, max=3.0)

}

# concentration of disolved oxygen in compartiment 1 and 2 ; 2 is compartiment with less oxygen

#################
### Functions ###
#################


#Anodic diffusive controlled current
def i_a(delta,Cred,Dred):
  return n*F*A*Dred*Cred/delta

#Cathodic diffusive controlled current
def i_c(delta,Cox,Dox):
  return -n*F*A*Dox*Cox/delta

#Diffusion-limited current
def i_diff(delta,Dred,Dox,Cred,Cox,E,E_std):
    ia=i_a(delta,Cred,Dred)
    ic=i_c(delta,Cox,Dox)
    k=(E-E_std)*(n*F)/(R*T)
    return (np.exp(k)*ia+ic)/(1+np.exp(k))


def kanodicreduced(E_std,E,alpha,F,R,T):
    """
    anodic kinetic constant without the k0 prefactor see 7.16 of Girault
    """
    NernstCoeff =  F / (R * T)
    return np.exp(alpha * (E-E_std)*NernstCoeff)

def kcathodicreduced(E_std,E,alpha,F,R,T):
    """
    cathodic kinetic constant without the k0 prefactor see 7.16 of Girault
    """
    NernstCoeff =  F / (R * T)
    return np.exp(-(1-alpha) * (E-E_std)*NernstCoeff)

def currentButlerVolmer(E_std, alpha, E,F,R,T,Cred,Cox,A):

    #cathodic limit current

    fk0 = 10**(-7)
    ka = kanodicreduced(E_std,E,alpha,F,R,T)
    kc = kcathodicreduced(E_std,E,alpha,F,R,T)
    i = n * F * A * fk0 * (Cred * ka -Cox* kc )
    return i


#i-E Fe data
def iE_data_Fe(E):

        i_Fe = currentButlerVolmer(E_std_Fe, alpha, E,F,R,T,10,0,A)
        return i_Fe


#i-E of O2 data depending ofconcentration of dioxygen:
def iE_data_O2(E,C_O2):

        #Curve calculation
    i_diff_O2=i_diff(delta,0,D_O2,0,C_O2,E,E_std_O2)


    return i_diff_O2

#i-E data depending of concentration of dioxygen:
def iE_data_tot(E,C_O2):

    i_Fe=iE_data_Fe(E)
    i_O2=iE_data_O2(E,C_O2)
    i_tot=i_Fe+i_O2

    return i_tot

# Working point of the 2 electrodes together to do ?


# Working point of the 1 electrode alone

def Oxydation_one_electrode(C_O2_1):

    counter = 0
    i1=iE_data_Fe(E)
    i2=iE_data_O2(E,C_O2_1)



    for k in range(0,len(i1)):

         if  (-i2[k])>(i1[k]):
             counter=counter+1

    return [E[counter],-iE_data_O2(E,C_O2_1)[counter]]


# Working point of the battery
def battery(C_O2_1, C_O2_2):

    counter = 0
    counter_1 = 0
    counter_2 = 0
    i1=iE_data_tot(E,C_O2_1)
    i2=iE_data_tot(E,C_O2_2)
# We look for the short circuit potential of the battery
    for k in range(0,len(i1)):
        if  (-i1[k])>(i2[k]):
            counter=counter+1
# We look for the equilibrium potentiel of compartiment 2 alone (low O2 level)
    for k in range(0,len(i2)):
        if  i2[k]<0:
            counter_2=counter_2+1

# We randomly choose a value of current on i2 between the two previous potentials
    diff = int((abs(counter_2-counter))/1.2)
    i2 = iE_data_tot(E,C_O2_2)[counter_2+diff]

# We look for the potential for which i1 = i2
    for k in range(0,len(i1)):
        if  (-i1[k])> i2:
            counter_1=counter_1+1

    return [E[counter_2+diff],E[counter_1],iE_data_tot(E,C_O2_2)[counter_2+diff], iE_data_tot(E,C_O2_1)[counter_1] ]

#===========================================================
# --- Initialization of the plot ---------------------------
#===========================================================

#fig,(ax1,ax2)=plt.subplots(1,2,figsize=(16,6))
fig=plt.figure(figsize=(18,6))

fig.suptitle(r'Courbe i-E illustrating diiferential aeration')




E=np.arange(-0.6,0.2,0.0011)


ax = fig.add_axes([0.2, 0.2, 0.6, 0.75])

#ax.axhline(0, color='k')



ax.text(-0.14,2e-4,r'$\mathrm{Fe_{(s)}  \rightarrow \, Fe^{2+}_{(aq)}}+ 2e^-}$',horizontalalignment='center',
     verticalalignment='center')

ax.text(0,-3.2e-4,'$\mathrm{{H_2O}_{(l)} +4H^{+}_{(aq)}+ 4e^- \leftarrow \, {O_2}_{(aq)})}$',horizontalalignment='center',
     verticalalignment='center')

ax.plot([E.min(), E.max()],[0,0],':',lw=1,color='grey')

ax.set_xlim(E.min(), E.max())
ax.set_ylim(-5e-4,5e-4)

ax.set_xlabel('$E$ $\mathrm{(V/ESH)}$')
ax.set_ylabel('Current $i$ $\mathrm{(A)}$')






#===========================================================
# --- Plot of the updated curves ---------------------------
#===========================================================




# This function is called when the sliders are changed
# Do not display all together first curve Fe and O2_1 with oxidation then i_tot1 second select only itot1, itot2 and Working Point
def plot_data(C_O2_1,C_O2_2):

    lines['$i_\mathrm{Fe}$'].set_data(E,iE_data_Fe(E))
    lines['$i_\mathrm{O2}$'].set_data(E,iE_data_O2(E,C_O2_1))
    lines['$Oxidation$'].set_data([Oxydation_one_electrode(C_O2_1)[0],Oxydation_one_electrode(C_O2_1)[0]],[-Oxydation_one_electrode(C_O2_1)[1],Oxydation_one_electrode(C_O2_1)[1]])
    lines['$i_\mathrm{tot_1}$'].set_data(E,iE_data_tot(E,C_O2_1))
    lines['$i_\mathrm{tot_2}$'].set_data(E,iE_data_tot(E,C_O2_2))
    lines[r'$\Delta$E'].set_data([battery(C_O2_1, C_O2_2)[0],battery(C_O2_1, C_O2_2)[1]],[0,0])
    lines['$i_+,pile$'].set_data([battery(C_O2_1, C_O2_2)[0],battery(C_O2_1, C_O2_2)[0]],[battery(C_O2_1, C_O2_2)[2],0])
    lines['$i_-,pile$'].set_data([battery(C_O2_1, C_O2_2)[1],battery(C_O2_1, C_O2_2)[1]],[battery(C_O2_1, C_O2_2)[3],0])
    fig.canvas.draw_idle()

#lines['$Pile$'].set_data([battery(C_O2_1, C_O2_2)[0],battery(C_O2_1, C_O2_2)[0]],[-battery(C_O2_1, C_O2_2)[1],battery(C_O2_1, C_O2_2)[1]])
#########################

lines = {}
# Display of the Fe and O2 curve alone , O2 is trigerred by the [O2]1 concentration
lines['$i_\mathrm{Fe}$'], = ax.plot([], [],color='green',lw=2,label='$i_\mathrm{Fe}$')
lines['$i_\mathrm{O2}$'], = ax.plot([], [],color='blue',lw=2,label='$i_\mathrm{O2}$')
# Display of the equilibrium potential between Fe and O2
lines['$Oxidation$'],=ax.plot([], [],'--',color='grey',lw=2,label=r'Oxidation')
# Sum of the Fe and O2 curves, depending of the [O2]1 or [O2]2 concentrations
lines['$i_\mathrm{tot_1}$'], = ax.plot([], [], lw=3, color='red',label='$i_\mathrm{tot_1}$')
lines['$i_\mathrm{tot_2}$'], = ax.plot([], [], lw=3, color='purple',label='$i_\mathrm{tot_2}$')
lines[r'$\Delta$E'], = ax.plot([], [], '--',lw=3, color='black')
lines['$i_+,pile$'], = ax.plot([], [], '--',color='grey',lw=2)
lines['$i_-,pile$'], = ax.plot([], [], '--',color='grey',lw=2)
truc={}


ax.legend()



param_widgets = widgets.make_param_widgets(parameters, plot_data, slider_box=[0.20, 0.05, 0.35, 0.05])
choose_widget = widgets.make_choose_plot(lines, box=[0.01,0.2,0.12, 0.4])
reset_button = widgets.make_reset_button(param_widgets,box=[0.85, 0.05, 0.10, 0.05])

if __name__=='__main__':
    plt.show()

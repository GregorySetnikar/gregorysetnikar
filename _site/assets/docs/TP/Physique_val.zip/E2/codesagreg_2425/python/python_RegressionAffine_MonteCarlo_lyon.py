#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Régression linéaire Y = a * X + b par méthode des moindres carrés et propagation des incertitudes par méthode de Monte-Carlo.
Les incertitudes sont designées par uX et uY

Dépendances:

Usage: python python_RegressionAffine_MonteCarlo_lyon.py

Auteurs: Agrégatifs de physique 2023-2024
"""

# Importation des librairies
import numpy as np              # import. de la librairie numpy, raccourci np
import scipy.optimize as scopt  # import. de la (sous-)librairie scipy.optimize
import scipy.stats as scstat    # import. de la (sous-)librairie scipy.stats
import matplotlib.pyplot as plt # import. de la (sous-)librairie matplotlib.pyplot

# Definition des fonctions
def get_rawdata_default():
   """ Exemple de données expérimentales """
   # Mesures en direct
   # --> quantité "en abscisse" et son incertitude (avec l'unité appropriée)
   m_direct  = np.array([0.073]) 
   um_direct = np.array([0.0005])
   # --> quantité "en ordonnée" et son incertitude (avec l'unité appropriée)
   M_direct  = np.array([0.1])
   uM_direct = np.array([0.002/np.sqrt(3)])

   # Mesures en préparation
   # --> quantité "en abscisse" et son incertitude (avec l'unité appropriée)
   m  = np.array([0.288, 0.262, 0.233, 0.201, 0.165, 0.124])
   um = np.ones_like(m)*0.0005
   # --> quantité "en ordonnée" et son incertitude (avec l'unité appropriée)
   M  = np.array([70, 60, 50, 40, 30, 20])*0.01
   uM = np.ones_like(m)*0.002/np.sqrt(3)

   # Concatenation de toutes les mesures
   m  = np.concatenate((m,m_direct))
   um = np.concatenate((um,um_direct))
   M  = np.concatenate((M,M_direct))
   uM = np.concatenate((uM,uM_direct))
   return m,um,M,uM

def rawdata2XY(m,um,M,uM):
   """ Conversion entre les mesures et leurs incertitudes (m,um,M,uM) et les abscisses/ordonnées sur lesquelles sera
   effectuée la modélisation affine """
   X  = m
   uX = um
   Y  = M/m
   uY = np.sqrt((uM/m)**2+(M/m/m*um)**2)
   return X,uX,Y,uY

def residuals(coeff,X,uX,Y,uY):
   """ Residuals to be used in lsq fitting """
   err = (Y-(coeff[0]*X+coeff[1])) / np.sqrt((coeff[0]*uX)**2+uY**2)
   return err

def formatterScientific_to_Powerof10(x,n_dec):
   """ Convert a float from scientific notation to power of 10 (eg from 3.14e6 to 3.14\times 10^6) """
   # First step: convert float to scientific notation
   s = '{{:.{}e}}'.format(n_dec).format(x)
   # Deal with the string
   decimal_point = '.'
   positive_sign = '+'
   tup = s.split('e')
   significand = tup[0].rstrip(decimal_point)
   sign = tup[1][0].replace(positive_sign, '')
   exponent = tup[1][1:].lstrip('0')
   if exponent:
      exponent = '10^{%s%s}' % (sign, exponent)
   if significand and exponent:
      s =  r'%s{\times}%s' % (significand, exponent)
   else:
      s =  r'%s%s' % (significand, exponent)
   return "${}$".format(s)

# Programme principal
if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales brutes. Un exemple
   # est donné dans la fonction get_data_default()
   # La fonction rawdata2XY() effectue ensuite la conversion entre les données brutes et les abscisses/ordonnées sur
   # lesquelles sera effectuée la modélisation affine
   if True:
       m,um,M,uM = get_rawdata_default()
       X,uX,Y,uY = rawdata2XY(m,um,M,uM)
   else:
       m  = np.array([])
       um = np.array([])
       M  = np.array([])
       uM = np.array([])
       X,uX,Y,uY = rawdata2XY(m,um,M,uM)
   # Noms des axes et unites des coefficients du fit y = ax+b
   xlabel = r"$t_c \mathrm{(s)}$"
   ylabel = r"$h/t_c \mathrm{(m.s^{-1})}$"
   a_unit = r"$\mathrm{(m.s^{-2})}$"
   b_unit = r"$\mathrm{(m.s^{-1})}$"
   # Nombre de chiffres significatifs dans l'écriture des coefficients de la modélisation
   n_decimal = 2
   # Nombre de tirages aléatoires générant des données simulées à partir des mesures expérimentales [supposées suivre
   # des lois normales (avg, std) = (m, um) ou (M, uM)]
   n_MC = 1000

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Modélisation affine
   coeff = np.polyfit(X, Y, 1)  # initial guess
   lsq = scopt.leastsq(residuals, coeff, args=(X,uX,Y,uY), full_output=True)
   if False: print('Best fit parameters: {}'.format(lsq[0]))
   a  = lsq[0][0]             # extraction de la pente
   b  = lsq[0][1]             # extraction de l'ordonnée à l'origine
   ua = np.sqrt(lsq[1][0,0])  # extraction de l'incertitude sur la pente
   ub = np.sqrt(lsq[1][1,1])  # extraction de l'incertitude sur l'ordonnée à l'origine
   chi2r  = np.sum((residuals(lsq[0],X,uX,Y,uY))**2)/(X.size-lsq[0].size)
   uchi2r = np.sqrt(2./(X.size-lsq[0].size))
   print("Modelisation affine y = ax + b, avec :"+"\n"+
         "    a = {} +/- {}".format(a,ua)+"\n"+
         "    b = {} +/- {}".format(b,ub))


   # Conversion des nombres en chaines de caractères écrites en puissance de 10, avec le "bon" nombre de chiffres significatifs
   a_str = formatterScientific_to_Powerof10(a,n_decimal)
   b_str = formatterScientific_to_Powerof10(b,n_decimal)
   ua_str = formatterScientific_to_Powerof10(ua,n_decimal)
   ub_str = formatterScientific_to_Powerof10(ub,n_decimal)
   chi2r_str = formatterScientific_to_Powerof10(chi2r,n_decimal)

   # Plot (le dernier point de mesure [et seulement lui] est mis en exergue, c'est supposé être celui effectué en direct,
   # par opposition aux autres effectués en préparation)
   fig = plt.figure(figsize=(10, 8))
   plt.errorbar(X[:-1],Y[:-1],xerr=uX[:-1],yerr=uY[:-1],fmt='.k',label="Point en prep.",ecolor='k')
   plt.errorbar(X[-1:],Y[-1:],xerr=uX[-1:],yerr=uY[-1:],fmt='.r',label="Point en direct",ecolor='r')
   plt.plot(X,a*X+b,'-b',label="modélisation affine y = ax+b"+"\n"+
                               r"a = {}$\pm$ {} {}".format(a_str,ua_str,a_unit)+"\n"+
                               r"b = {}$\pm$ {} {}".format(b_str,ub_str,b_unit)+"\n"+
                               r"$\chi^2_r=${}".format(chi2r_str))
   plt.xlabel(xlabel,fontsize=15)
   plt.ylabel(ylabel,fontsize=15)
   plt.legend(fontsize=15)
   if True: plt.savefig('donnees.png')
   plt.show()

   # Monte-Carlo
   seed = 1691989345            # seed pour initialiser le generateur de nombres aleatoires
   np.random.seed(seed)         # initialisation du random generator
   lsq_MC = np.empty((n_MC,2))  # initialisation du tableau stockant les paires (a,b)
   # Loop
   for i in range(n_MC):
      mfake = m + um*(np.random.randn(m.size)-1/2)
      Mfake = M + uM*(np.random.randn(M.size)-1/2)
      X,uX,Y,uY = rawdata2XY(mfake,um,Mfake,uM)
      coeff = np.polyfit(X, Y, 1)  # initial guess
      lsq = scopt.leastsq(residuals, coeff, args=(X,uX,Y,uY), full_output=True)
      if False: print('Best fit parameters: {}'.format(lsq[0]))
      lsq_MC[i] = lsq[0]
   # Plot
   fig, axes = plt.subplots(2,1,figsize=(10,12))
   for i,coeff_name in enumerate(['a','b']):
      histo = axes[i].hist(lsq_MC[:,i])
      hist, bins = histo[:2]
      bin_width  = bins[1]-bins[0]
      # Fit de l'histogramme
      mfit, sfit = scstat.norm.fit(lsq_MC[:,i])
      refbins = np.linspace(bins[0],bins[-1])
      best_fit   = scstat.norm.pdf(refbins, mfit, sfit)
      axes[i].plot(refbins, best_fit*np.sum(hist)*bin_width,
                   label='Mod. loi normale\n (avg, std) = ({:4.3f},{:4.3f})'.format(mfit,sfit))
      axes[i].set_title("Histogramme du coeff. '{}' de la modelisation affine".format(coeff_name))
      axes[i].legend()
   if True: plt.savefig('MC.png')
   plt.show()


   

   

   



#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
25/05/2020

@author: Francis Pagaud et Gauthier Legrand, ENS de Lyon

Illustration des trajectoires possibles d'un corps autour d'un corps massif
suivant l'excentricité de l'hyperboloide
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import matplotlib
matplotlib.rc('xtick', labelsize=18)
matplotlib.rc('ytick', labelsize=18)
matplotlib.rcParams.update({'font.size': 22})

# Définition des fonctions

def E(e) :
    """
    Calcul de l'énergié potentielle correspondant à une excentricité
    """
    E = e**2-1/(2*m*C**2/K**2)
    return (E)

def r12(e) :
    '''Prend en argument l'excentricite. Retourne les deux valeurs de r possibles'''
    if e < 1 :
        r1 = p/(1+e)
        r2 = p/(1-e)
    else :
        r1 = p/(1+e)
        r2 = p/0.01
    return(r1, r2)

if __name__=="__main__":

    r=np.linspace(0.1,4,100)

    # Paramètres physiques
    K=2
    C=1
    m=2
    e0=0.5
    p=m*C**2/K

    # Calcul de l'énergie potentielle
    Epeff = - K/r + m*C**2/(2*r**2)


    # Initialisation de la figure
    fig = plt.figure('Coniques')
    plt.suptitle("Trajectoires gravitation")
    ax1 = plt.axes([0.1, 0.2, 0.37, 0.7])
    ax2 = plt.axes([0.55, 0.2, 0.37, 0.7])
    axe = plt.axes([0.1, 0.05, 0.83, 0.03])

    ax1.grid()

    # Tracé de l'énergie potentielle
    ax1.plot(r,Epeff, '-r', lw = 4)
    ax1.set_xlim([0,4])
    ax1.set_ylim([-2,2])

    # Valeurs limites d'Ep
    (r1,r2) = r12(e0)
    E0 = E(e0)
    l0, = l2, = ax1.plot([0, 4], [0, 0], '-k', lw = 1)
    l2, = ax1.plot([r1, r2], [E0, E0], '--', color = 'orange', lw = 2)
    p1, = ax1.plot(r1, E0, 'o', color  ='orange', markersize = 15)
    p2, = ax1.plot(r2, E0, 'o', color  ='orange', markersize = 15)

    # Trajectoire
    phi = np.linspace(0,2*np.pi,200)
    r = p/(1+e0*np.cos(phi))
    rl = p/(1+np.cos(phi))

    x=r*np.cos(phi)
    y=r*np.sin(phi)

    xl = rl*np.cos(phi)
    yl = rl*np.sin(phi)

    ax2.plot([0], [0], 'ok')
    ax2.plot(xl, yl, '--k', lw = 2, label = 'Limite de diffusion')
    l, = ax2.plot(x, y, '-r', lw = 4)

    ax2.set_xlim([-3, 1])
    ax2.set_ylim([-1.8, 1.8])


    ax1.set_xlabel(r"$r/r_{min}$")
    ax1.set_ylabel(r"$E/E_{min}$")
    ax2.set_xlabel("$x$")
    ax2.set_ylabel("$y$")
    ax2.legend(framealpha = 0.5)

    # Slider pour modifier les valeurs d'excentricité
    se = Slider(axe, 'e', 0, 1.1,valfmt='%0.2f',valinit=e0)

    def update(val):
        e = se.val
        E1 = E(e)
        (r1, r2) = r12(e)
        l.set_xdata(p/(1+e*np.cos(phi))*np.cos(phi))
        l.set_ydata(p/(1+e*np.cos(phi))*np.sin(phi))

        p1.set_xdata(r1)
        p2.set_xdata(r2)
        l2.set_xdata([r1, r2])

        p1.set_ydata(E1)
        p2.set_ydata(E1)
        l2.set_ydata([E1, E1])

        fig.canvas.draw_idle()
    se.on_changed(update)


    plt.show()

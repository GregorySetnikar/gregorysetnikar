#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ceci est un code assez basique qui permet de lire, à partir d'un fichier sur une clé USB, par exemple,
une série de données acquises par un oscilloscope, qui peuvent être analysées par la suite. 
Le lecteur sera libre de commenter certaines parties notamment dans le cas où il doit choisir son système d'exploitation.

Dépendances:

Usage: python python_Lecture_Data_Oscilloscope_lyon.py

Auteurs: Agrégatifs de physique 2023-2024
"""

# Importation des librairies
import os 
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd

# Définition des fonctions
def smooth(x,n=10):
    """ Fonction qui permet de lisser une série de données, utilise une convolution par un noyau uniforme,
    n est le nombre de points sur lequel faire le lissage """
    x=np.array(x)
    x=np.convolve(np.ones(n),x)/n
    return(x[n:-n]) 

# Programme principal
if __name__=='__main__':
    # PREAMBULE : 
    # SI l'ordinateur possède une version de latex, on peut améliorer l'affichage des graphiques. Il suffit alors
    # d'ajouter la lettre 'r' avant un texte affiché puis la syntaxe latex, comme par exemple r'Position, $x$ (m)'
    # SINON, il faut modifier toutes les sections d'affichage...
    
    # Mise en forme de l'affichage
    plt.close('all')
    plt.rc('text', usetex=True)
    plt.rc('text.latex', preamble=r'\usepackage{amsmath} \usepackage{lmodern} \usepackage{bm} \usepackage{xcolor}')
    # Options
    params = {'text.usetex' : True,
              'font.size' : 15,
              'font.family' : 'lmodern',
              }
    plt.rcParams.update(params)
    mpl.rcParams['axes.linewidth'] = 1.
    
    # Importation des données
    dossier = os.listdir('/Volumes/... chemin à compléter ...') # Version MacOS/Linux
    dossier = os.listdir('... chemin à compléter...:/')         # Version Windows, ex: F:/TP/
    filename = [f for f in dossier if f.endswith('.txt')][0]    # Permet de récupérer le premier fichier .txt/.csv
                                                                # parmi une liste de fichiers
    data = pd.read_csv('... chemin à compléter...'+filename,sep=';',decimal=',')
    
    # Attribution des données à des variables 
    Xd = data.iloc[:,0].to_numpy(dtype=float)
    Yd = data.iloc[:,1].to_numpy(dtype=float)
    # Si besoin, selection d'une plage de données :
    # X = Xd[(Xd>0) & (Xd<=0.25)] 
    # Y = Yd[(Xd>0) & (Xd<=0.25)]
    
    # Lissage :
    if True:
       X = smooth(Xd,10)
       Y = smooth(Yd,10)
    else:
       X = Xd
       Y = Yd
    
    # Affichage des données :
    plt.figure()
    plt.plot(X,Y,marker='+',c='red',ls='None',label='Exp.')
    plt.xlabel('Temps (s)')
    plt.ylabel(r'Tension, $U_{HP}$ (V)')
    plt.tight_layout()
    plt.legend()
    plt.show()
    
    # Transformée de Fourier discrète avec padding
    if True:
       plt.figure()
       nfft = 1000  # Si nfft > Xd.size, np.fft fait du padding, ie un lissage de la FFT.
       enrtime = 60 # Durée de l'enregistrement, en secondes
       plt.plot(np.fft.fftfreq(nfft,d=enrtime/nfft),np.abs(np.fft.fft(Xd,n=nfft))**2,\
                marker='+', ls='None',c='red',label='FFT')
       plt.xlabel('Fréquence, f (Hz)')
       plt.ylabel(r'$\lvert FFT(X) \rvert^2$')
       plt.legend()
       if True: plt.xlim((0.5,0.7)) # Si besoin de resserer l'affichage sur certaines fréquences
       plt.show()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


"""
RPAC en série et conséquences

Évolution de la conversion en fonction du nombre de RPAC en série pour une réaction A->B d'ordre 1. Des paramètres sont librement variables.

j : nombre de réacteurs
k : constante cinétique
Q : débit volumique


en haut à gauche : tracé de l'inverse de la vitesse pour avoir une estimation graphique du temps de passage
en haut au milieu : évolution de la concentration en A au fur et à mesure de la progression dans la suite de réacteur, \ell est l'indice du réacteur (\ell<=j)
en haut à droite : idem mais pour le taux de transformation

les droites grisées correspondent à la valeur de l'avancement (concentration) pour un réacteur piston de même temps de séjour total

Informations
------------
Author : Martin Vérot  from the ENS de Lyon, France, with the help of some scripts to create the buttons and sliders taken from https://github.com/araoux/python_agregation (written by P Cladé, A Raoux and F Levrier)
Licence : Creative Commons CC-BY-NC-SA 4.0 

WARNING this program requires the widgets.py file to work
"""

import matplotlib.pyplot as plt
import numpy as np
import widgets as widgets
import scipy.constants as constants
from matplotlib import rc
from scipy.signal import find_peaks
title = "RPAC en série de volume constant"

description = """
"""



#===========================================================
# --- Initial parameters  ---------------------
#===========================================================
maxReac= 10
parameters = {
        'j' : widgets.IntSlider(value=1, description='j', min=1, max=maxReac),
        'Q' : widgets.FloatSlider(value=100, description='Q', min=0.1, max=1000),
        'k' : widgets.FloatSlider(value=1, description='k', min=0.01, max=10),
    }

#===========================================================
# --- Initialization computations---------------------------
#===========================================================

def vitesse(k,C):
    return k*C



#===========================================================
# --- Plot of the updated curves ---------------------------
#===========================================================

# This function is called when the sliders are changed 
def plot_data(j,Q,k):
    C0=1 #moL L^-1
    Vtot = 100 # L
    
    #conversion de j en entier pour éviter d'avoir des erreurs
    jj = int(j)
    
    #initialisation des temps de passage
    taus = np.zeros(maxReac)
    #tableau des concentration en sortie du réacteur
    Cf = np.zeros(maxReac)
    #concentrations à chaque étage pour tous les nombres de réacteur possible
    Cs = []

    #calcul des concentrations pour chaque suite de réacteur
    for l in range(maxReac):
        #temps de passage correspondant au volume subdivisé
        taus[l]=Vtot/(Q*(l+1))
        #concentrations à chaque étage
        C = np.zeros(l+2)
        #initialisation de la concentration en entrée
        C[0]=C0
        #calcul de la concentration à chaque étage, cumprod permet de calculer la suite géométrique pour les concentrations
        C[1:]=1/(1+k*taus[l])
        C=np.cumprod(C)
        Cf[l]=C[-1]
        Cs.append(C)


    #plot de la courbe des vitesses
    Cplot = np.linspace(1e-10,1,500)
    v = 1/vitesse(k,Cplot)
    #on ajuste l'ordonnée de la vitesse pour garder un graph où on voit quelque chose
    thres = min(max(v),10)
    ax1.set_ylim(0,thres)


    #on met à jour la vitess de réaction
    lines['vitesse'].set_data(Cplot,v)
    #mise à jour des «rectangles» pour les temps de passage 
    lines['aire'].set_data(Cs[jj-1],1/vitesse(k,Cs[jj-1]))
    #on met à jour les limites des graphes haut milieu et haut droite 
    ax2.set_xlim(-0.1,jj+0.1)
    ax3.set_xlim(-0.1,jj+0.1)
    #calcul des données pour un RP pour pouvoir comparer
    tau = Vtot/Q
    Xmax = 1-np.exp(-k*tau)
    Cmax = C0*(1-Xmax)
    
    #tracé de la concentration et X à chaque étage de la suite de réacteurs 
    lines['Cell'].set_data(np.arange(jj+1),Cs[jj-1])
    lines['Xell'].set_data(np.arange(jj+1),1-Cs[jj-1]/C0)
    #tracé des valeurs pour le RP de même temps de passage 
    lines['Cmax'].set_data(np.arange(jj+1),Cmax)
    lines['Xmax'].set_data(np.arange(jj+1),Xmax)
    #tracé de l'évolution du taux d'avancement en fonction du nombre de réacteurs
    lines['Xf'].set_data(np.arange(1,maxReac+1),1-(Cf/C0))
    #mise à jour du point indiquant la valeur de j qu'on est en train de regarder
    lines['Xj'].set_data(jj,1-Cf[jj-1]/C0)
    fig.canvas.draw_idle()

#===========================================================
# --- Initialization of the plot ---------------------------
#===========================================================

fig = plt.figure(figsize=(12,6))
fig.suptitle(title,x=0.3)
#plot of the text
fig.text(0.01, .9, widgets.justify(description), multialignment='left', verticalalignment='top')

gs = fig.add_gridspec(2, 3,left=0.05, right=0.95, bottom=0.05, top=0.9)
#1/r = f(c)
ax1 = fig.add_subplot(gs[0,0])
#C_j 0->j
ax2 = fig.add_subplot(gs[0,1])
#X_j 0->j
ax3 = fig.add_subplot(gs[0,2])
#C_j = f(j)
ax4 = fig.add_subplot(gs[1,:])
ax4.set_xlim(0,maxReac)



lines = {}

#lines for top graph
#vitesse
lines['vitesse'], = ax1.plot([], [], linestyle='-', lw=1, color='#878787', visible=True)#, drawstyle='steps-mid'
#points de fonctionnement pour le calcul de l'aire
lines['aire'], = ax1.plot([], [], marker='o',ls='-', drawstyle='steps-pre', ms=3, color='#e08214', visible=True)#, drawstyle='steps-mid'
#lines['aire2'], = ax1.fill_between([], [], step='post', color='#e41a1c', visible=True)#, drawstyle='steps-mid'

#lines for bottom graph
#evolution de la concentration dans chaque réacteur pour j fixé
lines['Cell'], = ax2.plot([], [], linestyle='-',lw=1, drawstyle='steps-pre', color='#e08214', visible=True)
#affichage de la valeur maximale théorique pour un réacteur piston 
lines['Cmax'], = ax2.plot([], [], linestyle='-',lw=1, drawstyle='steps-pre', color='#878787', visible=True,label = 'RP')

#evolution de l'avancement dans chaque réacteur pour j fixé
lines['Xell'], = ax3.plot([], [], linestyle='-',lw=1, drawstyle='steps-pre', color='#e08214', visible=True)
#affichage de la valeur maximale théorique pour un réacteur piston 
lines['Xmax'], = ax3.plot([], [], linestyle='-',lw=1, drawstyle='steps-pre', color='#878787', visible=True,label = 'RP')


#evolution en fonction du nombre de réacteur
lines['Xf'], = ax4.plot([], [], linestyle='-',lw=1, color='#542788', visible=True)
lines['Xj'], = ax4.plot([], [], linestyle='-', marker='o', ms=3,lw=1, color='#e08214', visible=True)






#axes des graphs
ax1.set_xlabel('$C$')
ax1.set_ylabel('$1/r$')

ax2.set_ylabel('$C_\ell$')
ax2.set_xlabel('$\ell$')

ax3.set_ylabel('$X_\ell$')
ax3.set_xlabel('$\ell$')

ax4.set_ylabel('$X_f$')
ax4.set_xlabel('$j$')

param_widgets = widgets.make_param_widgets(parameters, plot_data, slider_box=[0.45, 0.91, 0.4, 0.08])

if __name__=='__main__':
    plt.show()





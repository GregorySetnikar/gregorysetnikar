#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Visualisation de l'effet de peau dans un métal avec un plot interactif
"""


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
import scipy.optimize as opt 
import scipy.constants as cst


#Création des axes des abscisses
x0 = np.linspace(-50,0,1000)
x1=np.linspace(0,100,100000)


#Initialisation des différents paramètres (init_-- vont varier, les autres 
#sont des constantes)

init_w = 5  ; init_gamma = 7 ; init_t=0
mu0 = 4*np.pi*1e-7 ; c= 3e8



#Définition des différentes fonctions à tracer

def f0(x,w,t):
    return np.sin(w*(t-(x/c)))


def f(x,w,gamma):
    d=np.sqrt(2/(gamma*mu0*w))
    return np.exp(-x/d)


def f1(x,w,t,gamma):
    d= np.sqrt(2/(gamma*w*mu0))
    
    return (np.exp(-x/d)*np.sin(w*t-2*np.pi*x/d))

def delta(w,gamma):
    return np.sqrt(2/(gamma*w*mu0))


#Création de la figure, avec les dimensions modifiées pour avoir la place
#d'ajouter les sliders


fig,ax = plt.subplots()

ax.set_ylim(-1.5,1.5)   
ax.set_xlim(-15,60)
fig.subplots_adjust(left=0.1, bottom=0.35)
ax.tick_params(axis='both',which='both',labelsize=12,width=2) #Ajuste la taille des chiffres des axes


ax.fill_between(x1,1.5,-1.5, where = x1>0 , facecolor = 'grey', alpha = 0.3) #Colore en gris la partie du métal

ax.set_xlabel('Distance [mm]',fontsize=12)


#Deux petits textes de légende
props1 = dict(boxstyle='round', facecolor='grey', alpha=0.5)
ax.text(0.5, 0.95,'Métal' , fontsize=18,
        verticalalignment='top', transform=ax.transAxes, bbox=props1)

props0 = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
ax.text(0.05, 0.95,'Vide' , fontsize=18,
        verticalalignment='top', transform=ax.transAxes, bbox=props0)


#Création des différentes courbes interactives

line0, = ax.plot(x1,f(x1*1e-3,10**init_w,10**init_gamma),color='black',linestyle='dashed')
line1,= ax.plot(x1,-f(x1*1e-3,10**init_w,10**init_gamma),color='black',linestyle='dashed')
line2, =  ax.plot(x1,f1(x1*1e-3,10**init_w,init_t,10**init_gamma),color='red',label='E')

line3 = ax.axvline(1e3*3*delta(10**init_w,10**init_gamma),color='blue',alpha=0.5,label=r'3$\delta$')
plt.legend(fontsize=15)
#line4, =  ax.plot(x0,f0(x0*1e-3,10**init_w,init_t),color='red')


#Création des différents sliders

axw = fig.add_axes([0.25, 0.2, 0.65, 0.03])
w_slider = Slider(
    ax=axw,
    label=r'log($\omega$) [rad/s]',
    valmin=3,
    valmax=10,
    valinit=init_w,
)

axt = fig.add_axes([0.25, 0.1, 0.65, 0.03])
time_slider = Slider(
    ax=axt,
    label='Temps [s]',
    valmin=0,
    valmax=1e-2,
    valinit=init_t,
)

ax_gamma = fig.add_axes([0.25, 0.15, 0.65, 0.03])
gamma_slider = Slider(
    ax=ax_gamma,
    label=r'log($\sigma_0$)[$\Omega^{-1}.m^{-1}$]',
    valmin=5,
    valmax=8,
    valinit=init_gamma,
)


#Fonction servant à mettre à jour la valeur des sliders
def update(val):
    
    #line4.set_ydata(f0(x0, w_slider.val,time_slider.val))
    
    line0.set_ydata(f(x1*1e-3, 10**w_slider.val,10**gamma_slider.val))
    line1.set_ydata(-f(x1*1e-3, 10**w_slider.val,10**gamma_slider.val))
    
    line2.set_ydata(f1(x1*1e-3, 10**w_slider.val,time_slider.val,10**gamma_slider.val))
    
    line3.set_xdata(1e3*3*delta(10**w_slider.val,10**gamma_slider.val))
    
    
    fig.canvas.draw_idle()
    

w_slider.on_changed(update)
time_slider.on_changed(update)
gamma_slider.on_changed(update)


# Créé un bouton reset à l'aide du widget 'Button' de matplotlib
resetax = fig.add_axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', hovercolor='0.975')

def reset(event):
    time_slider.reset()
    w_slider.reset()
    gamma_slider.reset()
button.on_clicked(reset)


plt.show()

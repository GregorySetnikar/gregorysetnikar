#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Représentation des oscillations de Rabi pour la molécule d'ammoniac.
Les formules sont données dans Basdevant, "Mécanique quantique" p145 en notant omega - omega_0 = delta
Agrégatifs de l'ENS de Lyon
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
import math
import matplotlib

# Mise en forme des axes
matplotlib.rc('xtick', labelsize=16)
matplotlib.rc('ytick', labelsize=16)
matplotlib.rcParams.update({'font.size': 18})

# Définition des fonctions
def Pmax(delta):
    """
    Probabilité maximale que la transition de l'état anti-symétrique en l'état symétrique se fasse
    delta : désacord entre la pulsation du champ électrique et la fréquence propre
    """
    return omega1**2/(delta**2+omega1**2)

def omegaRABI(delta):
    """
    Partie oscillante de la probabilité de transition
    """
    return math.sqrt(delta**2+omega1**2)


omega1 = 2
b=0 #ecart fréquentiel
liste_b = x = np.arange(-15.0, 15.0, 0.02)

#subplots
fig = plt.figure(figsize=(17,17))
ax1 = fig.add_subplot(121)
plt.xticks([])
plt.yticks(np.arange(2), ('0', '1'))
plt.xlabel('t (s)')
plt.ylabel('$P_{A-S}$')
plt.title(r'Probabilité de transition $|\psi_A> \rightarrow|\psi_S>$')


ax2 = fig.add_subplot(122)
plt.xticks([])
plt.yticks(np.arange(0,1))
plt.xlabel('$\delta (rad \cdot s^{-1})$')
plt.ylabel('$P_{max}$')
plt.title('Probabilité maximale des oscillations de Rabi')


plt.subplots_adjust(bottom=0.25)
x = np.arange(0.0, 1.0, 0.001)


f0 = 5




s = Pmax(b)*np.power(np.sin(omegaRABI(b) * x * 3),2)
C = Pmax(b)
G = np.sinc(math.pi*liste_b)


p1, = ax1.plot(x, s, lw=2)
p3, = ax2.plot(liste_b, Pmax(liste_b))
p4, = ax2.plot(b, Pmax(b), 'ro')

ax1.axis([0, 1, 0, 1])
ax2.axis([-10, 10, -0.5, 1.])

axcolor = 'lightgoldenrodyellow'
axb = plt.axes([0.25, 0.1, 0.65, 0.03], facecolor=axcolor)


sb = Slider(axb, '$\delta$', -10.0, 10.0, valinit=b)
sb.valtext.set_visible(False)


def update(val):
    b = sb.val
    p1.set_ydata(Pmax(b)*np.power(np.sin(omegaRABI(b) * x * 3),2) )
    p4.set_xdata(b)
    p4.set_ydata(Pmax(b))



sb.on_changed(update)


resetax = plt.axes([0.8, 0.025, 0.1, 0.04])
button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')


def reset(event):
    sb.reset()

button.on_clicked(reset)



def colorfunc(label):
    l.set_color(label)
    fig.canvas.draw_idle()

plt.show()



#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Post-traitement des données permettant la détermination du module d'Young par la méthode acoustique suivant le protocole
détaillé dans la Ref. "Physique expérimentale, Optique, magnétisme, électrotechnique, mécanique, thermodynamique et
physique non linéaire", Jolidon (2021).

Dépendances:

Usage: python python_Module_Young_lyon.py

Auteurs: Agrégatifs de physique 2022-2023
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt

# Definition des fonctions
def monte_carlo_affine(N,X,Y,u_X,u_Y):
    """
    Utilise la méthode de Monte-Carlo pour effectuer une modélisation affine Y = a * X + b, en tenant compte des incertitudes
    sur X (u_X) et sur Y (u_Y).
    La fonction repose sur la méthode de Monte-Carlo :
        - on fait une étude statistique sur N itérations,
        - pour chaque itération, on tire des valeurs de X et Y selon une loi gausienne (de moyenne X, d'écart-type u_X,
          idem pour Y).
    La fonction renvoie un tableau qui contient dans l'ordre :
        - la valeur de la pente optimisée (a_opt),
        - la valeur de l'ordonnée à l'origine optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )
    
    def N_iteration_affine(N,X,Y,u_X,u_Y):
        list_a = []
        list_b = []
        for i in range(N):
            list_X = []
            list_Y = []
            for k in range(len(X)):
                X_k = np.random.normal(X[k],u_X[k])
                Y_k = np.random.normal(Y[k],u_Y[k])
                list_X.append(X_k)
                list_Y.append(Y_k)
            a,b = np.polyfit(list_X, list_Y, 1)
            list_a.append(a)
            list_b.append(b)
        return list_a,list_b
    
    def moyenne(N,X):
        return sum(X)/N
    
    def ecart_type(X):
        return np.std(X,ddof=1)

    a_opt = moyenne(N,N_iteration_affine(N,X,Y,u_X,u_Y)[0])
    u_a_opt = ecart_type(N_iteration_affine(N,X,Y,u_X,u_Y)[0])
    b_opt = moyenne(N,N_iteration_affine(N,X,Y,u_X,u_Y)[1])
    u_b_opt = ecart_type(N_iteration_affine(N,X,Y,u_X,u_Y)[1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

# Programme principal
if __name__ == "__main__":
   # L'utilisateur doit renseigner, dans les lignes suivantes, l'ensemble des données expérimentales obtenues.
   # Ces mesures correspondent aux différentes longueurs de la barre de métal pour lesquelles a été mesurée la fréquence
   # du premier mode propre, avec les incertitudes correspondantes, ainsi que certaines caractéristiques géométriques
   # et physiques de la barre étudiée.
   if True:
      # Exemple de données expérimentales
      # Longueur de la barre de métal [cm] et incertitude correspondante [cm] (1 mm car mesure à la règle graduée)
      l = np.array([])
      u_l = 
      # Fréquence du premier mode propre [rad/s] et incertitude correspondante [rad/s] (temps d'acquisition: 1.5 s)
      omega = np.array([])
      u_omega = 
   else:
      # Valeurs relevées lors de la présentation
      # A COMPLETER
      Nprep = 10  # pour separer dans la visualisation les données obtenues en préparation et en direct
   if True:
      rho =        # Masse volumique du matériau [kg/m^3]
      u_rho =       # Incertitude sur la masse volumique [kg/m^3]
      e =     # Epaisseur de la barre [mm]
      u_e =   # Incertitude sur l'épaisseur de la barre [mm]
      b =          # Largeur de la barre [mm]
      u_b =        # Incertitude sur la largeur de la barre [mm]
      C0 =        # Coefficient de la première harmonique

   #=========================================================================================
   # L'utilisateur ne devrait pas à avoir à modifier les lignes suivantes
   #=========================================================================================
   # Variables pertinentes et propagation des incertitudes
   # 1/l
   minusl   = 1./l
   u_minusl = u_l /(l**2)
   # omega*l
   omegal   = omega*l
   u_omegal = omegal * np.sqrt((u_l/l)**2 + (u_omega/omega)**2)

   # Méthode de Monte Carlo pour déterminer la régression linéaire adéquate
   a,b,u_a,u_b,chi2 = monte_carlo_affine(5000, minusl, omegal, u_minusl, u_omegal)

   # Calcul du module d'Young E
   # On sait que omega = C0*e*(sqrt(E/(12*rho)))*(1/l^2) avec E le module d'Young, C0 le coefficient associé au premier mode
   # propre et rho la masse volumique. On a alors a = C0*(sqrt(E/rho)), d'où E = (a/(e*C0))**2 *12*rho
   E = ((a/(e*C0))**2)*rho*12
   u_E = E*np.sqrt(4*(u_a/a)**2 + 4*(u_e/e)**2 + (u_rho/rho)**2)
   print("Résultats de la modélisation :")
   print("- module d'Young E = {0:2.0f} +/- {1:1.0f} GPa".format(E/1.e9,u_E/1.e9))

   # Plot
   if True:
      plt.errorbar(minusl,omegal,u_omegal,u_minusl,'+',markersize=0,color='black', ecolor='black')
   else:
      plt.errorbar(minusl[:Nprep],omegal[:Nprep],u_omegal[:Nprep],u_minusl[:Nprep],\
                   '+',markersize=0,color='black', ecolor='black',label='préparation')
      plt.errorbar(minusl[Nprep:],omegal[Nprep:],u_omegal[Nprep:],u_minusl[Nprep:],\
                 'o',markersize = 25,fillstyle='none',color='green', ecolor='green',label='en direct')
   plt.plot(minusl,a * minusl + b, color='red', label=r' $\chi_2=${0:.2f}'.format(chi2))
   plt.xscale('linear')
   plt.yscale('linear')
   plt.xlabel(r'$1/l$ (m$^{-1}$)')
   plt.ylabel(r'$\omega_0 l$ (rad.m.s$^{-1}$)')
   plt.legend()
   plt.show()


#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Récupération, post-traitement et visualisation des données échantillonnées par un Arduino et transférées via le port série
Par défaut: nom du port série: COM3
            baudrate: 9600   (!!! doit être identique à celui défini dans le script Arduino)

Dépendances: python_ArduinoUtils_lyon.py (modifier en conséquence la variable d'environnement PYTHONPATH ou placer ces
                                          deux fichiers dans le même répertoire)

Usage: python python_ReadSerial_lyon.py [-h] [-r BAUDRATE] [-p PORT]

Exemple de spécification du port série: python python_ReadSerial_lyon.py -p '/dev/ttyACM0'
Exemple de spécification du baudrate:   python python_ReadSerial_lyon.py -r 115200

Auteurs: C. Winisdoerffer (21/03/2022)
         Révisions apportées par les agrégatifs de Lyon 2021-2022
"""

# Importation des librairies
import numpy as np
import matplotlib.pyplot as plt
import sys
import ArduinoUtils as AU
import scipy.optimize as scopt

# Definition des fonctions
def convertdata(data, Nbits=10):
   """ Conversion des données brutes (issues de l'Arduino) en données physiques """
   # Transformation affine
   data = 5.* data/(2**Nbits-1.)
   return data

def postprocess(data):
   """ Exemple de post-traitement des données : recherche d'un ajustement harmonique """
   x = data[:,0]
   y = data[:,1]
   # Initial guess
   coeff = np.array([np.mean(y), np.mean(y)/10, 1.e-4, 0.])
   # Fit
   lsq = scopt.least_squares(residuals, coeff, args=(x,y))
   lsq = lsq.x # keep only the optimized parameters among the outputs
   print('Best fit parameters: {}'.format(lsq))
   # Visualisation
   plt.plot(x,y,'-', label='data')
   plt.plot(x,functionnal(x, coeff), '-', label='initial guess')
   plt.plot(x,functionnal(x, lsq), '-', label='best fit')
   plt.legend()
   plt.show()
   return

def functionnal(x, coeff):
   """ Forme fonctionnelle pour le fit """
   # cste + A * sin(2\pi \nu x + \phi)
   res = coeff[0] + coeff[1]*np.sin(2.*np.pi*coeff[2]*x+coeff[3])
   return res

def residuals(coeff, x, y):
   """ Residuals to be used in lsq fitting """
   err = y - functionnal(x, coeff)
   return err

# Programme principal
if __name__ == "__main__":
   # Accès au port série par le script python
   serialport = AU.manage_SerialPort(sys.argv)
   # Récupération dynamique des données (pour visualisation)
   if False:
      #AU.getdata_dynamic(serialport,yrange=[0,50])
      AU.getdata_dynamic(serialport,iblck=2,yrange=[-20000,20000],Nfields=4,verbose=True)
   # Récupération statique des données (pour post-traitement)
   if True:
      data = AU.getdata_static(serialport,imax=200,Nfields=4)
   # Posttraitement
   if True:
      # Recuperation (eventuelle) des données si elles ne proviennent pas du "getdata_static" 
      if False:
         # Nom du fichier qui contient les données
         fname = 'data.16092024.txt'
         data = np.loadtxt(fname)
      # Conversion
      data = convertdata(data)
      data[:,1:] = convertdata(data[:,1:])
      # Visualisation
      plt.plot(data)
      plt.plot(data[:,0],data[:,1])
      plt.show()
      # Post-traitement des données
      #postprocess(data)
      



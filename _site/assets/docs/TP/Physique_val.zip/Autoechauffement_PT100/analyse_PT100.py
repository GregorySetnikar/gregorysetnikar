# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 03:58:19 2025

@author: ens
"""

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres
T_reel = 0
R_0 = 100
a = 3.9083e-3

### Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

R = np.array(df['R'])
i = np.array(df["I"])
T = (R/R_0-1)/a

fig, ax = DAU.make_fig("i (mA)", r"$T$ ($^{\circ C}$)")
DAU.plot(ax, i, T)


i_ref = i[-1]
R_ref = R[-1]

alpha = i[0:-1]/i_ref

R_corr = ((alpha**2-1)*R[0:-1]*R_ref)/(alpha**2*R[0:-1]-R_ref)
T_corr = (R_corr/R_0-1)/a

DAU.plot(ax, i[:-1], T_corr, color='red')



x = R*(i*1e-3)**2

fig2, ax2 = DAU.make_fig("Ri^2 (W)", r"$\Delta T$ ($^{\circ C}$)")
DAU.plot(ax2, x, T)
result_fit = DAU.regression(x=x, y=T, ax=ax2, model='lineaire')

R_th = result_fit['a']
print(f'R_th = {R_th} K/W')





plt.show()
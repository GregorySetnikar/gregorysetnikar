# -*- coding: utf-8 -*-
"""
Created on Wed Mar 26 11:49:12 2025

@author: ens
"""

import python_DataAnalysisUtils_lyon as DAU

DAU.make_template('analysis.py')

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

def inverse(x, a, b, c):
    return a+b/(x+c)

# Paramètres

alpha = np.arctan(1.06/10.32)
alpha_err = alpha*np.sqrt((0.01/1.06)**2 + (0.01/10.32)**2)
g = 9.81
rho = 789


# Reading data
file_path = "data_lower_line.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

x = np.array(df["x"])
# x_err = np.ones(len(x))*0.01*0.01
y = np.array(df["y"])
y_err = np.ones(len(y))*0.02*0.01

y = abs(y - y[-1])*1e-2     # conversion en m et shift
x = x*1e-2          # conversion en m

fig, ax = DAU.make_fig("x", "y")
DAU.plot(ax, x, y, yerr = y_err)

param, error = DAU.monte_carlo_fit(x, y, inverse, [0, 1, 0], plot_ax=ax)

b = param[1]
b_err = error[1]

gamma = alpha*rho*g*b/2
gamma_err = gamma*np.sqrt((alpha_err/alpha)**2 + (b_err/b)**2)

print(gamma)
print(gamma_err)

y = y - param[0]


fig2, ax2 = DAU.make_fig("x", "1/y")
DAU.plot(ax2, x, 1/y, yerr = y_err/y**2)


results_fit = DAU.regression(x=x, y=1/y, yerr=y_err/y**2, ax=ax2, color="blue", xmin=0, xmax=0.023)


a = results_fit["a"]
a_err = results_fit["u_a"]


gamma = alpha*rho*g/(2*a)
gamma_err = gamma*np.sqrt((alpha_err/alpha)**2 + (a_err/a)**2)


print(gamma)
print(gamma_err)

plt.show()

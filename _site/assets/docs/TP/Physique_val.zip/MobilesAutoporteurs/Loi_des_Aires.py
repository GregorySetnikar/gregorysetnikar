#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN
Version du 12/10/2022
"""

# Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt
import scipy.integrate as integrate

# Définition de fonctions pour effectuer une modélisations affine À NE PAS MODIFIER
def modele_affine(X,Y,u_X,u_Y,a_test,b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d'essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l'ordre :
        - la valeur de a optimisée (a_opt),
        - la valeur de b optimisée (b_opt),
        - l'incertitude sur la valeur de a (u_a_opt),
        - l'incertitude sur la valeur de b (u_b_opt),
        - la valeur du chi2 réduit (chi2_opt).
    """
    def affine(x,a,b):
        return a * x + b

    def residu_affine(p_affine,x,y,u_x,u_y):
        a = p_affine[0]
        b = p_affine[1]
        return ( y - affine(x,a,b) ) / np.sqrt ( u_y * u_y + ( a * u_x ) ** 2 )

    opt_affine = opt.least_squares(residu_affine,np.array([a_test, b_test]),args=(X,Y,u_X,u_Y))
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(),opt_affine.jac)
    u_a_opt = np.sqrt( 2. / hessian_affine[0,0])
    u_b_opt = np.sqrt( 2. / hessian_affine[1,1])
    chi2_opt = np.sum( residu_affine(np.array([a_opt,b_opt]),X,Y,u_X,u_Y) ** 2 )/( len(X) - 2 )
    print("Résultats de l'ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt,u_a_opt))
    print("- ordonnée à l'origine = {0:.2e} +/- {1:.1e}".format(b_opt,u_b_opt))
    return np.array([a_opt,b_opt,u_a_opt,u_b_opt,chi2_opt])

# Paramètres À MODIFIER
filename = 'aire.txt' # nom du fichier avec x, y en m
x_c = 38.79e-2 # abscisse du mobile fixe en m
y_c = 52.34e-2 # ordonnée du mobile fixe en m
T = 0.04 # période des impulsions en s
u_x = 0.05e-2 # incertitude sur x en m
u_y = 0.05e-2 # incertitude sur y en m

# Importation des données
data = np.genfromtxt(filename)
x = data[:,0]*1e-2
y = data[:,1]*1e-2
x -= x_c
y -= y_c
r2 = x * x + y * y # carré de la distance au centre
theta = np.arctan2(y, x) # angle que fait le vecteur position par rapport à l'axe des abscisses

# Calcul de l'incertitude sur l'aire
t = np.arange(0, len(x)) * T # tableau des temps
u_t = np.zeros(len(t)) # incertitude sur le temps
A = 0.5 * integrate.cumtrapz(r2, theta) # aire balayée au cours du temps
u_A = np.zeros(len(A)) # incertitude sur l'aire qu'on va calculer par méthode de Monte Carlo (sous hypothèse uniforme)
n_MC = 10000
i = 0
np.random.seed()
while i < n_MC:
    x_MC = np.copy(x) + ( 2. * np.random.random_sample(len(x)) - 1. ) * u_x
    y_MC = np.copy(y) + ( 2. * np.random.random_sample(len(y)) - 1. ) * u_y
    r2_MC = x_MC * x_MC + y_MC * y_MC
    theta_MC = np.arctan2(y_MC, x_MC)
    u_A += ( 0.5 * integrate.cumtrapz(r2_MC, theta_MC) - A ) ** 2
    i += 1
u_A /= n_MC
u_A **= .5

# Effectuer une modélisation de l'aire en fonction du temps
param_affine = modele_affine(t[1:],A,u_t[1:],u_A,1.,0.)
a_affine = param_affine[0] # extraction de la pente (vitesse aérolaire)
u_a_affine = param_affine[2] # extraction de l'incertitude sur la pente (vitesse aérolaire)
b_affine = param_affine[1] # extraction de l'ordonnée à l'origine
u_b_affine = param_affine[3] # extraction de l'incertitude sur l'ordonnée à l'origine
chi2_affine = param_affine[4] # extraction du chi2 réduit
C = 2 * a_affine # constante des aires
u_C = 2 * u_a_affine

# Tracé des données
plt.figure()
plt.errorbar(t[1:],A,u_A,u_t[1:],'o')
plt.plot(t,a_affine * t + b_affine,label=r'$C$=({0:.2f}$\pm$ {1:.2f}) m2/s, $\chi_2=${2:.2f}'.format(C, u_C, chi2_affine))
plt.xlabel(r'$t$ (s)')
plt.ylabel(r'$A$ (m2)')
plt.legend()
plt.show()

# Calcul et tracé des différentes énergies
l0 = 19.5e-2 # longueur à vide du ressort en m À MODIFIER
l= 31.5e-2  # longeur pour une masse m0 en m
m0= 50.152e-3 #masse en kg
k = (m0*9.81)/(l-l0) # raideur du ressort en N/m À MODIFIER

m = 0.69591 # masse du mobile en kg À MODIFIER
r = np.sqrt(r2)
rp = np.diff(r)
Ec = 0.5 * m * ( rp * rp + C * C / r2[:-1] )
Ep = 0.5 * k * ( r[:-1] - l0 ) ** 2
plt.figure()
plt.plot(t[:-1],Ec,'o',label=r'$E_\mathrm{c}$')
plt.plot(t[:-1],Ep,'s',label=r'$E_\mathrm{p}$')
plt.plot(t[:-1],Ec+Ep,'*',label=r'$E_\mathrm{m}$')
plt.xlabel(r'$t$ (s)')
plt.ylabel(r'$E$ (J)')
plt.legend()
plt.show()

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres


### Reading data
file_path = "aire.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

x = np.array(df['x'])
y = np.array(df['y'])




### Deux tubes en série

df_serie = DAU.filter_df(df, 'Type', 'Serie1et2')
Dm = np.array(df_serie['Dm'])
Dm_err = np.array(df_serie['Dm_err'])

Dv = Dm/rho
Dv_err = Dm_err/rho

Delta_P =  np.array(df_serie['DeltaP'])
Delta_P_err =  np.array(df_serie['DeltaP_err'])


fig, ax = DAU.make_fig(r"$\Delta P$ (Pa)", r"$Q_v$ (kg/s)")
results_fit = DAU.regression(x=Delta_P, y=Dv, xerr=Delta_P_err, yerr=Dv_err, ax=ax, color="k")
plt.title('Deux tubes en série (noir), tube 1 seul (rouge), tube 2 seul (bleu)')

R_H = 1/results_fit['a']
R_H_err = R_H*results_fit['u_a']/results_fit['a']


String2print, vals = DAU.format_value_with_uncertainty(R_H, R_H_err)
print(f'Série : R_H = {String2print} m^-3.s.Pa, à comparer avec {R_H_attendu}')
z_score = abs(R_H-R_H_attendu)/R_H_err
print(f'zscore = {z_score}')

### Tube 1 seul

df_serie = DAU.filter_df(df, 'Type', 'Tube1Seul')
Dm = np.array(df_serie['Dm'])
Dm_err = np.array(df_serie['Dm_err'])

Dv = Dm/rho
Dv_err = Dm_err/rho

Delta_P =  np.array(df_serie['DeltaP'])
Delta_P_err =  np.array(df_serie['DeltaP_err'])


results_fit = DAU.regression(x=Delta_P, y=Dv, xerr=Delta_P_err, yerr=Dv_err, ax=ax, color="r")

R_H = 1/results_fit['a']
R_H_err = R_H*results_fit['u_a']/results_fit['a']


String2print, vals = DAU.format_value_with_uncertainty(R_H, R_H_err)
print(f'Série : R_H = {String2print} m^-3.s.Pa, à comparer avec {R_H_1}')
z_score = abs(R_H-R_H_1)/R_H_err
print(f'zscore = {z_score}')


### Tube 2 seul

df_serie = DAU.filter_df(df, 'Type', 'Tube2Seul')
Dm = np.array(df_serie['Dm'])
Dm_err = np.array(df_serie['Dm_err'])

Dv = Dm/rho
Dv_err = Dm_err/rho

Delta_P =  np.array(df_serie['DeltaP'])
Delta_P_err =  np.array(df_serie['DeltaP_err'])


results_fit = DAU.regression(x=Delta_P, y=Dv, xerr=Delta_P_err, yerr=Dv_err, ax=ax, color="b")

R_H = 1/results_fit['a']
R_H_err = R_H*results_fit['u_a']/results_fit['a']


String2print, vals = DAU.format_value_with_uncertainty(R_H, R_H_err)
print(f'Série : R_H = {String2print} m^-3.s.Pa, à comparer avec {R_H_2}')
z_score = abs(R_H-R_H_2)/R_H_err
print(f'zscore = {z_score}')


















plt.show()

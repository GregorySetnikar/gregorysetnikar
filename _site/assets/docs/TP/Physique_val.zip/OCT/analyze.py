# -*- coding: utf-8 -*-
"""
Created on Mon Mar 31 20:19:50 2025

@author: Valentin
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt


### OCT

Ve = np.array([0.5, 0.8, 1.2, 1.6, 2.0, 2.5])
f = np.array([311, 497, 743, 988, 1230, 1533])
f_err = np.array([1, 1, 1, 1, 1, 1])

R = 10.02e3
C = 10.21e-9
R1 = 3.873e3
R2 = 9.925e3
K = 0.0983

K_list = [0.0946/1**2, 0.6144/2.5**2, 1.5798/4**2, 3.5649/6**2, 6.33/8**2]
K = np.mean(K_list)
K_err = np.std(K_list)/2


fig, ax = DAU.make_fig('Ve (V)', 'f (Hz)')
fit_results = DAU.regression(Ve, f, yerr=f_err, ax=ax, color='k')


k = fit_results['a']
k_err = fit_results['u_a']
k_attendu = K*R2/(4*R*C*R1)
k_attendu_err = k_attendu*K_err/K




String2print, vals = DAU.format_value_with_uncertainty(k, k_err)

String2print_attendu, vals = DAU.format_value_with_uncertainty(k_attendu, k_attendu_err)

z_score = abs(k-k_attendu)/np.sqrt(k_err**2+k_attendu_err**2)

print('OCT')
print(f'k = {String2print}, à comparer avec {String2print_attendu}')
print(f'z_score = {z_score}')



### Oscilloscope --- FreqDev=10kHz, f0=100kHz

Ve = np.array([0, 0.5, 1, 0.7, 0.2])
f = np.array([100, 104.7, 109.5, 106.8, 101.9])
f_err = 0.2*np.ones(len(f))


fig2, ax2 = DAU.make_fig('Ve (V)', 'f (kHz)')
fit_results = DAU.regression(Ve, f, yerr=f_err, ax=ax2, color='k')


k = fit_results['a']
k_err = fit_results['u_a']

String2print, vals = DAU.format_value_with_uncertainty(k, k_err)

print('Oscilloscope')
print(f'k = {String2print}')




### Largeur spectrale

AmplitudeFFT = 1e-3*np.array([25, 87, 219, 475, 763, 669, 81, 706, 81, 663, 750, 487, 225, 81, 25])  # mV
AmplitudeFFT_err = 4e-3*np.ones(len(AmplitudeFFT))
f = np.array([92.88, 93.8, 94.81, 95.85, 96.85, 97.8, 98.83, 99.83, 100.84, 101.85, 102.87, 103.8, 104.87, 105.85, 106.85])

Energie = AmplitudeFFT**2
Energie_err = 2*AmplitudeFFT*AmplitudeFFT_err

E_tot = np.sum(Energie)
E_tot_err = np.sqrt(np.sum(Energie_err**2))

ratio = 100*np.cumsum(Energie)/E_tot

f1 = max(f[ratio<=1])
f2 = min(f[ratio>=99])
B = f2-f1


fig3, ax3 = DAU.make_fig('f (kHz)', 'E/E_tot')
DAU.plot(ax3, f, ratio)


kappa = 10e3 # =FreqDev ici
Ai = 0.8
fi = 1e3
fp = 100e3

beta = Ai*kappa/fi


B_attendu = 2*(beta+1)*fi*1e-3

print(f'B = {f2-f1} kHz, à comparer avec B_attendu = {B_attendu} kHz')










































plt.show()


# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 03:57:05 2025

@author: ens
"""


# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres
T = 0


### Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

R = np.array(df['R'])
i = np.array(df["I"])

fig, ax = DAU.make_fig("i (mA)", r"$R(T)$ ($\Omega$)")
DAU.plot(ax, i, R)
















plt.show()


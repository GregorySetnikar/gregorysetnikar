# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 15:03:48 2024

@author: physique
"""


import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def linear(x, a):
    return a*x


## Données 

L = np.array([2.00,1.60,1.40,1.20,1.00,2.39,])
u_L = np.array([0.01,0.01,0.01,0.01,0.01,0.01])

x_1 = np.array([0.22,0.24,0.23,0.25,0.27,0.21]) 
x_2 = np.array([1.79,1.37,1.16,0.95,0.71,2.17])
x = x_2-x_1
u_x = np.array([0.01,0.01,0.01,0.01,0.01,0.01])

ydata = L**2-x**2 # ordonnées pour faire une régression linéaire simple
u_y_valentin = np.sqrt(2)*np.sqrt((L*u_L)**2+(x*u_x)**2)
#u_y_gregory = 

p, pcov = curve_fit(linear, L, ydata, sigma=u_y)
perr = np.sqrt(np.diag(pcov))


fig = plt.figure()
plt.errorbar(x=L, y=ydata, xerr=u_L, yerr=u_y, fmt='o')
plt.plot(L, p*L)
plt.grid()

focale = p[0]/4
u_focale = perr/4


print(f'focale={focale}, erreur={u_focale}')









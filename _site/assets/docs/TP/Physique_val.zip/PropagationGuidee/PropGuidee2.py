# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 04:43:34 2024

@author: ens
"""


import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

# Paramètres

#retard_syst = 330e-6
retard_syst = 278e-6

d = 1.79 # m
d_err = 0.01 #m
tau = 5.48e-3 - retard_syst
tau_err = 0.04e-3 #s
c = d/tau # m/s
c_err = np.sqrt((d_err/d)**2+(tau_err/tau)**2)*c


f = 41.4e3 # Hz
f_err = 0.1e3 #Hz
L = 3.4  # longueur du tube en m
L_err = 0.1 #en m
a = 0.0424 #en m
a_err = 0.0001 #en m

retard = np.array([10.80, 11.38, 10.10, 10.44,  11.26, 10.78, 10.42, 11.3])*1e-3
retard -= retard_syst

retard_err = np.ones(len(retard))*

vg = L/retard
vg_err = np.sqrt((L_err/L)**2+(retard_err/retard)**2)*vg


lambda_g = c**2/(f*vg)
lambda_g_err= np.sqrt(2*(c_err/c)**2+(f_err/f)**2+(vg_err/vg)**2)*lambda_g


mu_n = np.sort(np.pi*a*((f/c)**2-(1/lambda_g)**2)**(0.5))
mu_n_err = 

mu_th = np.sort([1.84, 3.05, 4.2 , 5.32, 6.42, 7.5, 8.58, 3.83, 5.33, 6.71, 8.01, 9.28])

print(mu_n)
print(mu_th)


#Tube fin
L = 2.88 #m
a = 0.01548
retard = np.array([8.64, 9.02,9.40])





################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

#☺DAU.init_umath()


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "calib.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("I (A)", "B (mT)")

# Performing regression with uncertainties and plotting raw data
x = np.array(df["I"])
xerr = np.array(df["I_err"])
y = np.array(df["B"])
yerr = np.array(df["B_err"])
results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Creating a blank figure with x, y labels
fig2, ax2 = DAU.make_fig("B (T)", "$tan(\\theta)$")

# Performing regression with uncertainties and plotting raw data
I = np.array(df["I"])
Ierr = np.array(df["I_err"])

x = results_fit["a"] * I + results_fit["b"] # champ B en mT

theta = np.deg2rad(np.array(df["theta"]))
theta_err = np.deg2rad(np.array(df["theta_err"]))

y = np.tan(theta)
y_err = (1+np.tan(theta)**2)*theta_err

results_fit = DAU.regression(x=x*1e-3, y=y, xerr=None, yerr=y_err, ax=ax2, color="black")#↑, xmax=1.2e-4)

uB_H = 1/(results_fit["a"])
uB_H_err = results_fit["u_a"]/results_fit["a"]**2
String2print, vals = DAU.format_value_with_uncertainty(uB_H, uB_H_err)

print(f'uB_H = {String2print} uT')

ax.legend()
plt.show()

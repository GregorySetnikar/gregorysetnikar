# -*- coding: utf-8 -*-
"""
Created on Fri Mar 28 17:56:55 2025

@author: physique
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

# Reading data
file_path = "profil.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

x = np.array(df["x"])
y = np.array(df["y"])

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("k", "Rk^2")

DAU.plot(ax, x, y)


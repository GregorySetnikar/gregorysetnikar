# -*- coding: utf-8 -*-
"""
Created on Fri Mar 28 22:06:38 2025

@author: Valentin
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt


### Partie qui ne fonctionne pas... 

df_profil, units = DAU.loadfile('profil.txt')
x = np.array(df_profil["x"])
y = np.array(df_profil["y"])


# interpolation pour plus de précision
x_interp = np.linspace(0,max(x), 3*len(x))
y_interp = np.interp(x_interp, x, y)

fig, ax = DAU.make_fig("x", "y")
DAU.plot(ax, x_interp, y_interp)


# xmin = 1250
# xmax = 1270

# x_local_1 = x_interp[x_interp<xmax]
# x_local = x_local_1[x_local_1>xmin]

# y_local = y_interp[x_interp<xmax]
# y_local = y_local[x_local_1>xmin]

# maximum = max(y_local)

# print(x_local[y_local==maximum])

# plt.xlim([xmin, xmax])
# plt.show()


file_path = "data_2.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

R1 = np.array(df["R1"])
R1_err = np.array(df["R1_err"])
R2 = np.array(df["R2"])
R2_err = np.array(df["R2_err"])
D_R1 = np.array(df["dR1"])
D_R1_err = np.array(df["dR1_err"])
D_R2 = np.array(df["dR2"])
D_R2_err = np.array(df["dR2_err"])


y1 = np.ones(len(R1))*190
DAU.plot(ax, R1, y1, color='red')
y2 = np.ones(len(R1))*170
DAU.plot(ax, R2, y2, color='blue')


R1 = R1-R1[0]
R1 = abs(R1[1:])
D_R1 = D_R1[1:] # largeur à mi-hauteur
R1_err = R1_err[1:]
D_R1_err = D_R1_err[1:]

R2 = R2-R2[0]
R2 = abs(R2[1:])
R2_err = R2_err[1:]
D_R2 = D_R2[1:] # largeur à mi-hauteur
D_R2_err = D_R2_err[1:]

k = np.linspace(1, len(R1), len(R1))


# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("k", "Rk^2")

DAU.plot(ax, k, R1**2, yerr = 2*R1*R1_err)
DAU.plot(ax, k, R2**2, yerr = 2*R2*R2_err, color='red')

results_fit = DAU.regression(x=k, y=R1**2, yerr=2*R1*R1_err, ax=ax, color="k")

a = results_fit["a"]
a_err = results_fit["u_a"]

lambda_0 = 589.3e-9
fpx = 478.6/3*30



e = lambda_0*fpx**2/a
e_err = e*a_err/a
print(f"e = {e} +/- {e_err}")


## Finesse du Fabry Pérot

Delta_R1 = R1[2:]-R1[:-2]
Delta_R2 = R2[2:]-R2[:-2]

fig2, ax2 = DAU.make_fig("2*largeur à mi-hauteur (pxl)", "R(i+1)-R(i-1) (pxl)")
results_fit1 = DAU.regression(x=2*D_R1[1:-1], y=Delta_R1, xerr=2*D_R1_err[1:-1], yerr=R1_err[1:-1]*np.sqrt(2), xmax=60, ax=ax2, color="blue", mec="blue")
results_fit2 = DAU.regression(x=2*D_R2[1:-1], y=Delta_R2, xerr=2*D_R2_err[1:-1], yerr=R1_err[1:-1]*np.sqrt(2), xmax=40, ax=ax2, color="red")

F1 = results_fit1["a"]
F1_err = results_fit1["u_a"]
F2 = results_fit2["a"]
F2_err = results_fit2["u_a"]

z_score = abs(F1-F2)/np.sqrt(F1_err**2+F2_err**2)

print(f"F1 = {F1} +/- {F1_err}")
print(f"F2 = {F2} +/- {F2_err}")

print(z_score)



## Doublet 

DRk = R2-R1
 
z = 2*fpx**2/(R1+R2)

fig3, ax3 = DAU.make_fig("2f_px^2 / (R1+R2) (pxl)", "Delta Rk (pxl)")
results_fit = DAU.regression(x=z[1:], y=DRk[1:], yerr=R1_err[1:]*np.sqrt(2), xmax = 4e4, ax=ax3, color="blue")

delta_lambda = abs(lambda_0*results_fit["a"])
delta_lambda_err = delta_lambda*results_fit["u_a"]/results_fit["a"]
print(f"delta_lambda = {delta_lambda} +/- {delta_lambda_err}")

z_score = abs(delta_lambda-0.597e-9)/delta_lambda_err

print(f"z_score = {z_score}")








plt.show()
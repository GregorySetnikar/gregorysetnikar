
################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

# Reading data
file_path = "data_3.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

R1 = np.array(df["R1"])
R2 = np.array(df["R2"])
D_R1 = np.array(df["dR1"])
D_R2 = np.array(df["dR2"])


R1 = R1-R1[0]
R1 = abs(R1[1:])
D_R1 = D_R1[1:] # largeur à mi-hauteur

R2 = R2-R2[0]
R2 = abs(R2[1:])
D_R2 = D_R2[1:] # largeur à mi-hauteur

k = np.linspace(1, len(R1), len(R1))


# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("k", "Rk^2")

DAU.plot(ax, k, R1**2, yerr = 2*R1*D_R1)
DAU.plot(ax, k, R2**2, yerr = 2*R2*D_R2, color='red')

results_fit = DAU.regression(x=k, y=R1**2, yerr=D_R1, ax=ax, color="blue")

a = results_fit["a"]
a_err = results_fit["u_a"]

lambda_0 = 589e-9
fpx = 478.6/3*30

e = lambda_0*fpx**2/a
print(f"e {e}")


Delta_R1 = R1[2:]-R1[:-2]
Delta_R2 = R2[2:]-R2[:-2]

fig2, ax2 = DAU.make_fig("k", "F")
results_fit1 = DAU.regression(x=2*D_R1[1:-1], y=Delta_R1, yerr=D_R1[1:-1]/2, ax=ax2, color="blue")
results_fit2 = DAU.regression(x=2*D_R2[1:-1], y=Delta_R2, yerr=D_R2[1:-1]/2, ax=ax2, color="red")

F1 = results_fit1["a"]
F2 = results_fit2["a"]



# Doublet 

DRk = -R1+R2
 
z = 2*fpx**2/(R1+R2)

fig3, ax3 = DAU.make_fig("z", "Delta Rk")
results_fit = DAU.regression(x=z, y=DRk, yerr=D_R1, ax=ax3, color="blue")

delta_lambda = abs(lambda_0*results_fit["a"])
print(f"delta_lambda = {delta_lambda}")



plt.show()






# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 10:37:44 2024

@author: physique
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Sep  2 15:03:48 2024

@author: physique
"""


import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


#Constantes
f_prime = 5 #en cm
D= 2560 #en mm distance ecran/trou
u_D = 10 #en mm

d = 700 #mm
u_d = 50 #mm

lbda = 543.5e-7# en cm

def linear(x, a, b):
    
    return a*x+b
    
## Données 

b = np.array([183.5,64,40.5,30,24.5,20.8,18.5,16.5]) # en cm
b-= f_prime

b_inv = 1/b
u_b = np.array([10,4,2,1,1,0.5,0.5,0.5])
u_invb = b_inv**2 * u_b


k = np.array([1,2,3,4,5,6,7,8]) 

p, pcov = curve_fit(linear, k, b_inv, sigma=u_invb)
perr = np.sqrt(np.diag(pcov))


fig = plt.figure()
plt.errorbar(x=k, y=b_inv, yerr=u_invb, fmt='o')
plt.plot(k, b_inv)
plt.grid()

a= -1/p[1]
u_a = perr[1]/a**2

rho = 2*np.sqrt(lbda/p[0]) #0.19 théorique
u_rho = rho*perr[0]/p[0]


print(f'a {a} \pm {u_a}')
print(f'rho {rho} \pm {u_rho}')








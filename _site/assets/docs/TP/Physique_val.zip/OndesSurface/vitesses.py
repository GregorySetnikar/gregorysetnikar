# -*- coding: utf-8 -*-
"""
Éditeur de Spyder

Ceci est un script temporaire.
"""

import numpy as np
import matplotlib.pyplot as plt
import python_DataAnalysisUtils_lyon as DAU

def v_phi(k, rho, g, gamma):    
    return np.sqrt(gamma*k/rho+g/k)

def v_g(k, rho, g, gamma):
    return (3*gamma*k/rho+g/k)/(2*v_phi(k, rho, g, gamma))



# Paramètres 

rho = 1e3
gamma = 0.07
g = 9.81


k = np.linspace(400, 1000, 3000)
v_phase = v_phi(k, rho, g, gamma)
v_groupe = v_g(k, rho, g, gamma)

fig, ax = DAU.make_fig('k (/m)', 'v (m/s)')
DAU.plot(ax, x=k, y=v_phase, label='Vitesse de phase')
DAU.plot(ax, x=k, y=v_groupe, label='Vitesse de groupe')
plt.legend()

plt.show()
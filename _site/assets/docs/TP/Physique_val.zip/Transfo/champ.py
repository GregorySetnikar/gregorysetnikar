################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

### Paramètres

omega = 2*np.pi*50


### Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)


### Court-circuit / pertes cuivre

df_CC = DAU.filter_df(df, 'Type', 'CC')
P1 = np.array(df_CC['P1'])
U1 = np.array(df_CC['U1'])
I1 = np.array(df_CC['I1'])
I2 = np.array(df_CC['I2'])

P1_err = np.array(df_CC['P1_err'])
U1_err = np.array(df_CC['U1_err'])
I1_err = np.array(df_CC['I1_err'])
I2_err = np.array(df_CC['I2_err'])


fig2, ax2 = DAU.make_fig("I1^2 (A^2)", "P1 (W)")
results_fit = DAU.regression(x=I1**2, y=P1, xerr=2*I1*I1_err, yerr=P1_err, ax=ax2, color="k")

Req = results_fit['a'] # Req = R1+R2/m^2
Req_err = results_fit['u_a']
String2print, vals = DAU.format_value_with_uncertainty(Req, Req_err)

print(f'Req = R1+R2/m^2 = {String2print} Ohm')


fig, ax = DAU.make_fig("I1 (A)", "U1 (V)")
results_fit_new = DAU.regression(x=I1, y=U1, xerr=I1_err, yerr=U1_err, ax=ax, color="blue")

Leq = np.sqrt((results_fit_new['a']**2-Req**2)/omega**2) # Leq = L1+L2/m^2

print(f'Leq = L1+L2/m^2 = {Leq} H')

fig_m, ax_m = DAU.make_fig("I2 (A)", "I1 (A)")
results_fit = DAU.regression(x=I2, y=I1, xerr=I2_err, yerr=I1_err, ax=ax_m, color="blue")

String2print, vals = DAU.format_value_with_uncertainty(results_fit['a'], results_fit['u_a'])
print(f'Rapport transformation CC : m = {String2print}')



### Circuit ouvert / pertes fer

df_vide = DAU.filter_df(df, 'Type', 'Vide')
P1 = np.array(df_vide['P1'])
U1 = np.array(df_vide['U1'])
I1 = np.array(df_vide['I1'])
U2 = np.array(df_vide['U2'])

P1_err = np.array(df_vide['P1_err'])
U1_err = np.array(df_vide['U1_err'])
I1_err = np.array(df_vide['I1_err'])
U2_err = np.array(df_vide['U2_err'])



fig3, ax3 = DAU.make_fig("U1^2 (V^2)", "P1 (W)")
results_fit = DAU.regression(x=U1**2, y=P1, xerr=2*U1*U1_err, yerr=P1_err, ax=ax3, color="k")

RF = 1/results_fit['a'] 
RF_err = RF*results_fit['u_a']/results_fit['a']
String2print, vals = DAU.format_value_with_uncertainty(RF, RF_err)

print(f'RF = {String2print} Ohm')

fig4, ax4 = DAU.make_fig("U1 (V)", "I1 (A)")
results_fit = DAU.regression(x=U1, y=I1, xerr=U1_err, yerr=I1_err, ax=ax4, color="r")

L = 1/omega*np.sqrt(1/(results_fit['a']**2-1/RF**2))

print(f'L = {L} H')

fig_m2, ax_m2 = DAU.make_fig("U1 (V)", "U2 (V)")
results_fit = DAU.regression(x=U1, y=U2, xerr=U1_err, yerr=U2_err, ax=ax_m2, color="blue")

String2print, vals = DAU.format_value_with_uncertainty(results_fit['a'], results_fit['u_a'])
print(f'Rapport transformation vide : m = {String2print}')

### Rendement


R_list = np.array([101.57, 52.38, 7.89])


fig6, ax6 = DAU.make_fig("U1 (V)", "U2 (V)")
fig7, ax7 = DAU.make_fig("I1 (A)", "I2 (A)")
fig8, ax8 = DAU.make_fig("U1 (V)", "rendement")

for R in R_list:
    
    df_R = DAU.filter_df(df, 'R', R)
    
    P1 = np.array(df_R['P1'])
    U1 = np.array(df_R['U1'])
    I1 = np.array(df_R['I1'])
    P2 = np.array(df_R['P2'])
    I2 = np.array(df_R['I2'])
    U2 = np.array(df_R['U2'])

    P1_err = np.array(df_R['P1_err'])
    P2_err = np.array(df_R['P2_err'])
    U1_err = np.array(df_R['U1_err'])
    I1_err = np.array(df_R['I1_err'])
    U2_err = np.array(df_R['U2_err'])
    I2_err = np.array(df_R['I2_err'])
    
    
    DAU.plot(x=U1, y=U2, ax=ax6, label=f'R={R} Ohm')
    
    DAU.plot(x=I1, y=I2, ax=ax7, label=f'R={R} Ohm')
    
    rendement = P2/P1
    PF = U1**2/RF
    Pcu = Req*0.5**2*I2**2
    rendement_th = P2/(P2+PF+Pcu)
    DAU.plot(x=U1, y=rendement, ax=ax8, label=f'Réel, R={R} Ohm')
    DAU.plot(x=U1, y=rendement_th, ax=ax8, label=f'Théorique, R={R} Ohm')
    





















ax6.legend()
ax7.legend()
ax8.legend()
ax8.set_ylim([0.5, 1])

plt.show()

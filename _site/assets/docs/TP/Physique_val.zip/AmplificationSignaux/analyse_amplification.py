# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 03:58:19 2025

@author: ens
"""

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
#import uncertainties.unumpy as unp
#import uncertainties.umath as umath

#%% Mesure de beta pour le continu

### Reading data
file_path = "data_beta.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

IC = np.array(df["IC"])
IB = np.array(df["IB"])


fig, ax = DAU.make_fig(r"$I_B$ ($\mu$A)", r"$I_B$ ($\mu$ A)")
DAU.plot(ax, IB, IC)
result_fit = DAU.regression(x=IB, y=IC, ax=ax, xmax=60)

beta = result_fit["a"]

print(f'beta = {beta}')


#%% Mesure de h11 dans le modèle des petits signaux

IB = 34.56e-6
RC = 903

file_path = "data_gain_h11.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

iB = np.array(df["iB"])*1e-6
vBE = np.array(df["vBE"])*1e-3
ve = np.array(df["ve_eff"])*1e-3
vs = np.array(df["vs_eff"])

fig2, ax2 = DAU.make_fig(r"$i_B$ (A)", r"$v_{BE}$ (V)")
DAU.plot(ax2, iB, vBE)
result_fit = DAU.regression(x=iB, y=vBE, ax=ax2, xmax=15e-6)

h11 = result_fit["a"]

VT = 1.38e-23*(273.15+20)/(1.6e-19)
h11_attendu = VT/IB

print(f'h11 = {h11} Ohm, à comparer avec {h11_attendu}')


fig3, ax3 = DAU.make_fig(r"$v_e$ (V)", r"$v_s$ (V)")
DAU.plot(ax3, ve, vs)
result_fit = DAU.regression(x=ve, y=vs, ax=ax3, xmax=0.02)

h11_bis = beta*RC/result_fit["a"]

print(h11_bis)


#%% Push Pull - Gain en courant

Zu = 50.3

file_path = "data_push-pull.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

iE = np.array(df["ie_eff"])*1e-3
iS = np.array(df["is_eff"])

fig4, ax4 = DAU.make_fig(r"$i_e$ (A)", r"$i_s$ (A)")
DAU.plot(ax4, iE, iS)
result_fit = DAU.regression(x=iE, y=iS, ax=ax4)

pente = result_fit["a"]
print(pente)










plt.show()
import python_DataAnalysisUtils_lyon as da
import numpy as np
from uncertainties import unumpy
import matplotlib.pyplot as plt
import uncertainties.umath as um
import uncertainties.unumpy as unp
from uncertainties import ufloat

da.init_umath()


# Fonction affine pour le fit avec Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Lecture des données
file_path = "donnees_bruitees.csv"  # Remplacez par le chemin correct si nécessaire
df, units = da.loadfile(file_path)
# df = da.filter_df(df=df, column_name="R", value=33) #pour extraire un sous tableau lorsque que R = 33

fig, ax = da.make_fig("x", "y")  # fabrique une figure vierge de label x,y

x_test = da.np2unp(np.array(df["x"]), np.array(df["xerr"]))
# print(type(x_test))
y_test = da.np2unp(df["y"], df["yerr"])

test = x_test * um.pow(y_test, 4)

print(test)

print(f"test_x {unp.nominal_values(test)} pm {unp.std_devs(test)}")


""" 
# Helper to generate arrays of ufloats safely for each function
def make_ufloats(vals, unc=0.01):
    return [ufloat(v, unc) for v in vals]


# Safe value arrays per function — avoid math domain errors
safe_inputs = {
    "acos": make_ufloats([0.0, 0.5, 1.0]),  # domain: -1 ≤ x ≤ 1
    "acosh": make_ufloats([1.1, 2.0, 3.0]),  # domain: x ≥ 1
    "asin": make_ufloats([-1.0, 0.0, 1.0]),  # domain: -1 ≤ x ≤ 1
    "asinh": make_ufloats([-2.0, 0.0, 2.0]),
    "atan": make_ufloats([-10.0, 0.0, 10.0]),
    "atan2": list(zip(make_ufloats([1.0, 2.0, 3.0]), make_ufloats([1.0, 2.0, 3.0]))),
    "atanh": make_ufloats([-0.9, 0.0, 0.9]),  # domain: -1 < x < 1
    "ceil": make_ufloats([1.1, 2.5, -3.7]),
    "copysign": list(
        zip(make_ufloats([1.0, -2.0, 3.0]), make_ufloats([-1.0, 1.0, -3.0]))
    ),
    "cos": make_ufloats([-3.14, 0.0, 3.14]),
    "cosh": make_ufloats([-2.0, 0.0, 2.0]),
    "degrees": make_ufloats([-3.14, 0.0, 3.14]),
    "erf": make_ufloats([-2.0, 0.0, 2.0]),
    "erfc": make_ufloats([0.1, 1.0, 2.0]),
    "exp": make_ufloats([-1.0, 0.0, 1.0]),
    "expm1": make_ufloats([-1.0, 0.0, 1.0]),
    "fabs": make_ufloats([-3.0, 0.0, 3.0]),
    "floor": make_ufloats([1.9, -2.5, 0.0]),
    "fmod": list(zip(make_ufloats([5.0, 7.5, 9.0]), make_ufloats([2.0, 3.0, 4.0]))),
    "gamma": make_ufloats([1.1, 2.5, 5.0]),  # avoid non-positive integers
    "hypot": list(zip(make_ufloats([3.0, 5.0, 8.0]), make_ufloats([4.0, 12.0, 15.0]))),
    "lgamma": make_ufloats([1.1, 2.5, 5.0]),
    "log": make_ufloats([0.1, 1.0, 10.0]),  # x > 0
    "log10": make_ufloats([0.1, 1.0, 10.0]),
    "log1p": make_ufloats([0.0, 0.5, 1.0]),  # x > -1
    "pow": list(zip(make_ufloats([2.0, 3.0, 4.0]), make_ufloats([2.0, 1.5, 0.5]))),
    "radians": make_ufloats([0.0, 90.0, 180.0]),
    "sin": make_ufloats([-3.14, 0.0, 3.14]),
    "sinh": make_ufloats([-2.0, 0.0, 2.0]),
    "sqrt": make_ufloats([0.0, 1.0, 4.0]),  # x ≥ 0
    "tan": make_ufloats([-1.0, 0.0, 1.0]),
    "tanh": make_ufloats([-2.0, 0.0, 2.0]),
    "trunc": make_ufloats([1.9, -2.1, 0.0]),
}


test_x = um.acos(safe_inputs["acos"])
print(test_x)
test_x = um.acosh(safe_inputs["acosh"])
print(test_x)
test_x = um.asin(safe_inputs["asin"])
print(test_x)
test_x = um.asinh(safe_inputs["asinh"])
print(test_x)
test_x = um.atan(safe_inputs["atan"])
print(test_x)

x = ufloat(1.0, 0.1)
arr = [ufloat(1.0, 0.1), ufloat(0.5, 0.05)]

# Case where both inputs are the same list of ufloats
print(um.atan2(arr, arr))  # ✅ should now work

# Also works:
print(um.atan2(arr, x))  # ✅ list + scalar
print(um.atan2(x, arr))  # ✅ scalar + list
print(um.atan2(x, x))  # ✅ scalar + scalar
print(type(safe_inputs["atan2"]))

test_x = um.atan2(safe_inputs["atan2"], safe_inputs["atan2"])
print(test_x)
test_x = um.atanh(safe_inputs["atanh"])
print(test_x)
test_x = um.ceil(safe_inputs["ceil"])
print(test_x)
test_x = um.copysign(safe_inputs["copysign"], safe_inputs["copysign"])
print(test_x)
test_x = um.cos(safe_inputs["cos"])
print(test_x)
test_x = um.cosh(safe_inputs["cosh"])
print(test_x)
test_x = um.degrees(safe_inputs["degrees"])
print(test_x)
test_x = um.erf(safe_inputs["erf"])
print(test_x)
test_x = um.erfc(safe_inputs["erfc"])
print(test_x)
test_x = um.exp(safe_inputs["exp"])
print(test_x)
test_x = um.expm1(safe_inputs["expm1"])
print(test_x)
test_x = um.fabs(safe_inputs["fabs"])
print(test_x)
test_x = um.floor(safe_inputs["floor"])
print(test_x)
test_x = um.fmod(safe_inputs["fmod"], safe_inputs["fmod"])
print(test_x)
test_x = um.gamma(safe_inputs["gamma"])
print(test_x)
test_x = um.hypot(safe_inputs["hypot"], safe_inputs["hypot"])
print(test_x)
test_x = um.lgamma(safe_inputs["lgamma"])
print(test_x)
test_x = um.log(safe_inputs["log"])
print(test_x)
test_x = um.log10(safe_inputs["log10"])
print(test_x)
test_x = um.log1p(safe_inputs["log1p"])
print(test_x)
test_x = um.pow(safe_inputs["pow"], 4)
print(test_x)
test_x = um.radians(safe_inputs["radians"])
print(test_x)
test_x = um.sin(safe_inputs["sin"])
print(test_x)
test_x = um.sinh(safe_inputs["sinh"])
print(test_x)
test_x = um.sqrt(safe_inputs["sqrt"])
print(test_x)
test_x = um.tan(safe_inputs["tan"])
print(test_x)
test_x = um.tanh(safe_inputs["tanh"])
print(test_x)
test_x = um.trunc(safe_inputs["trunc"])
print(test_x)
print

"""
# print(f"test_x {unumpy.std_devs(test_x)}")

x, xerr = da.unp2np(x_test)
y, yerr = da.unp2np(y_test)
test_x_theo = x * y

# err_theo = np.abs(np.sqrt((xerr / x) ** 2 + (yerr / y) ** 2) * test_x_theo)
# print(f"err_theo{err_theo}")

x_m = 1
y_m = 1
xerr_m = 0.5
yerr_m = 0.5

direct_point = [x_m, y_m]
direct_errors = [xerr_m, yerr_m]


"""
results_fit = da.regression(x=x, y=y, fig=fig, ax=ax, highlight_points=0, label="test")


results_fit = da.regression(
    x=x,
    y=y,
    xerr=xerr,
    yerr=None,
    fig=fig,
    ax=ax,
    label="test2",
)

results_fit = da.regression(
    x=x, y=y, xerr=None, yerr=yerr, fig=fig, ax=ax, highlight_points=0, label="test3"
)
results_fit = da.regression(
    x=x, y=y, xerr=xerr, yerr=yerr, fig=fig, ax=ax, highlight_points=0, label="test4"
)


freq = np.linspace(0, 1000000, 100)
gain = np.linspace(0, 1000000, 100)
gain_err = np.ones(gain.shape) * 100

da.plot_bode(freq=freq, gain=gain, phase=gain, gain_err=gain_err)

"""

#fig2, ax2 = da.make_fig("x", "y")  # fabrique une figure vierge de
fit_monte_carlo, fit_monte_carlo_err = da.monte_carlo_fit(
    x=df["x"],
    y=df["y"],
    func=linear_func,
    p0=[1, 1],
    xerr=df["xerr"],
    # yerr=df["yerr"],
    ax=ax,
    snake=True,
    #color="blue",
    #xmax=,
)  # regression avec curve_fit + plot des données
data_smoothed = da.smooth(
    data=[df["x"], df["y"]], smooth_factor=5
)  # smmoth des données

#da.plot(ax2, data_smoothed[0], data_smoothed[1], color="black", label="data_smoothed")

ax.legend()
plt.show()

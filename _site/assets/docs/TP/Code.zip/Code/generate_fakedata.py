import numpy as np
import pandas as pd


# Fonction de génération des données
def generate_noisy_data(n_points=20, seed=42):
    np.random.seed(seed)
    x = np.linspace(0, 10, n_points)
    true_a, true_b = 485, -751  # Vraie relation y = 2x + 1
    y = true_a * x + true_b

    # Ajout d'un bruit significatif
    xerr = np.random.uniform(0.5, 1.5, size=len(x))  # Incertitude sur x (jusqu'à ±1.5)
    yerr = np.random.uniform(2, 4, size=len(y))  # Incertitude sur y (jusqu'à ±4)

    # Ajout du bruit aux données
    x_noisy = x + np.random.normal(0, xerr)
    y_noisy = y + np.random.normal(0, yerr)

    return x_noisy, y_noisy, xerr, yerr


x, y, xerr, yerr = generate_noisy_data(n_points=100)

# Sauvegarde des données dans un fichier CSV
data = pd.DataFrame({"x": x, "y": y, "xerr": xerr, "yerr": yerr})
file_path = "donnees_bruitees.csv"
data.to_csv(file_path, index=False)

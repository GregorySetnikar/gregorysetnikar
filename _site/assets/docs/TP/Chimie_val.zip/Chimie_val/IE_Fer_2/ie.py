################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("E", "i")

Ecs = 0.245  # V

# Performing regression with uncertainties and plotting raw data
Ia = np.array(df["ia"])
Ic = np.array(df["ic"])
Va = np.array(df["Va"])
Vc = np.array(df["Vc"])

DAU.plot(x=Va, y=Ia, ax=ax, color="black")
DAU.plot(x=Vc, y=Ic, ax=ax, color="red")

# Adding legend and displaying the plot
ax.legend()
plt.show()

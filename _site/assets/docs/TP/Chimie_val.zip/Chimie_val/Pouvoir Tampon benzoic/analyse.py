# -*- coding: utf-8 -*-
"""
Created on Wed Apr  9 18:08:20 2025

@author: Valentin
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

V_tampon = 40   # mL
c_soude = 0.075 # mol/L


V = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15]) #mL
pH = np.array([4.14, 4.18, 4.22, 4.25, 4.29, 4.33, 4.37, 4.4, 4.45, 4.49, 4.53, 4.58, 4.79])

beta = (c_soude*V)/((V+V_tampon)*(pH-pH[0]))


fig, ax = DAU.make_fig('V (mL)', r'$\beta$')
DAU.plot(ax, V, beta)















plt.show()
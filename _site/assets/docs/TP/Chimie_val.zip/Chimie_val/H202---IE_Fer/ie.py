################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "data_ie.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("E", "i")

Ecs = 0.245  # V

# Performing regression with uncertainties and plotting raw data
I = np.array(df["I"])
I_err = np.ones(len(I)) * 0.1

E_a = np.array(df["E_a"]) - Ecs
Ea_err = np.ones(len(E_a)) * 0.01

E_c = np.array(df["E_c"]) - Ecs
Ec_err = np.ones(len(E_c)) * 0.01

DAU.plot(x=E_a, y=I, xerr=Ea_err, yerr=I_err, ax=ax, color="black")
DAU.plot(x=E_c, y=-I, xerr=Ec_err, yerr=I_err, ax=ax, color="red")

# Adding legend and displaying the plot
ax.legend()
plt.show()

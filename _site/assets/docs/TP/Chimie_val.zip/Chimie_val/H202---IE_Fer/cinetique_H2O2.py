# -*- coding: utf-8 -*-
"""
Created on Wed Apr 23 20:11:47 2025

@author: Valentin
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt


# Paramètres
C_0 = 0.1 # concentration en H2O2 en mol/L
V_0 = 50 # volume introduit en H2O2 en mL
V_M = 24.5 # volume molaire du gaz
C_I_0 = 0.5 # concentratin initiale en I- en mol/L


# Reading data
file_path = "data_H202.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

V_I_list = np.array([10, 10, 15, 25])

k_app = []
C_I = C_I_0*V_I_list/(V_0+V_I_list)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("t (min)", "$ln(C)$")

for V_I in V_I_list:
    df_i = DAU.filter_df(df, "V_I", V_I)
    
    t = np.array(df_i["t"])/60
    V_O2 = np.array(df_i["V_O2"]) # volume de dioxygène produit en mL
    
    
    C = C_0*V_0/(V_0+V_I)-2*V_O2/((V_0+V_I)*V_M)
    y = np.log(C)
    
    DAU.plot(ax, x=t, y=y, label=f'V_I = {V_I} mL')
    result_fit = DAU.regression(ax=ax, x=t, y=y, xmin=0.2e3/60, xmax=0.8e3/60)

    k_app.append(-result_fit['a'])

k_app = np.array(k_app)
y = np.log(k_app)

x = np.log(C_I)


fig2, ax2 = DAU.make_fig('ln([I-])', 'ln(kapp)')
DAU.plot(ax2, x=x, y=y)
result_fit = DAU.regression(ax=ax2, x=x, y=y)

k = result_fit['a']

print(k)





plt.legend()
plt.show()
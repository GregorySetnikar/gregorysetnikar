################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


v_h2 = 7e-6  # en m3
v_O2 = 3.75e-6  # en m3

T = 273.13 + 20  # en K

t = 7 * 60  # en s

I = 0.130  # en A

n_O2 = (1e5 * v_O2) / (8.314 * T)
n_h2 = (1e5 * v_h2) / (8.314 * T)

eta_h2 = (2 * n_h2 * 6.02e23 * 1.6e-19) / (I * t)
eta_o2 = (4 * n_O2 * 6.02e23 * 1.6e-19) / (I * t)

print(f"Rendement {eta_h2}")
print(f"Rendement {eta_o2}")

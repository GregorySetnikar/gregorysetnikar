import numpy as np
import matplotlib.pyplot as plt
import math
from scipy.ndimage import gaussian_filter1d


def validate_and_shrink(x, y, xerr, yerr, xmin, xmax):
    # Adjust xmin and xmax if needed
    if xmin is None or xmin < min(x):
        xmin = min(x)
    if xmax is None or xmax > max(x):
        xmax = max(x)

    if xmin >= max(x) or xmax <= min(x):
        print("Erreur sur la plage sélectionnée. Ajustement sur tous les points.")
        xmin, xmax = min(x), max(x)

    # Create mask for valid x values within the selected range
    mask = (x >= xmin) & (x <= xmax)

    # Apply mask to x, y, and error arrays, but only if they're not None
    x_filtered = x[mask]
    y_filtered = y[mask]

    # Handle xerr and yerr if they are not None
    if xerr is not None:
        xerr_filtered = xerr[mask]
    else:
        xerr_filtered = None

    if yerr is not None:
        yerr_filtered = yerr[mask]
    else:
        yerr_filtered = None

    return x_filtered, y_filtered, xerr_filtered, yerr_filtered, xmin, xmax


def format_value_with_uncertainty(value, uncertainty):
    """
    Formate une valeur et son incertitude en écriture scientifique avec deux chiffres significatifs pour l'incertitude.

    Arguments :
        value (float) : la valeur principale.
        uncertainty (float) : l'incertitude associée.

    Retourne :
        str : chaîne de caractères formatée sous la forme "valeur ± incertitude" en notation scientifique.
    """
    if uncertainty <= 0:
        raise ValueError("L'incertitude doit être strictement positive.")

    # Obtenir l'ordre de grandeur de l'incertitude
    uncertainty_order = math.floor(
        math.log10(uncertainty)
    )  # Exposant de la puissance de 10
    scale = 10**uncertainty_order  # Échelle pour ajuster à l'ordre de grandeur

    # Réduire l'incertitude et la valeur à une base entre 1 et 10
    reduced_uncertainty = uncertainty / scale
    reduced_value = value / scale

    # Arrondir l'incertitude à 2 chiffres significatifs
    rounded_uncertainty = round(reduced_uncertainty, 1)

    # Ajuster la valeur principale en fonction de l'incertitude
    rounded_value = round(reduced_value, 1)

    # Génération de la chaîne formatée en notation scientifique
    formatted_result = (
        f"({rounded_value:.1f} ± {rounded_uncertainty:.1f}) × 10^{uncertainty_order}"
    )
    formatted_value = f"{rounded_value:.1f}× 10^{uncertainty_order}"
    return formatted_result, formatted_value


def regression(
    fig,
    ax,
    x,
    y,
    labelx,
    labely,
    xerr=None,
    yerr=None,
    model="affine",
    xmin=None,
    xmax=None,
    show=True,
):
    """
    Modèle "affine" : y = ax + b
    Modèle "lineaire" : y = ax
    """
    x_all, xerr_all, y_all, yerr_all = x, xerr, y, yerr

    # Modification des tableaux pour ne faire l'ajustement que sur la plage de valeurs demandée (x compris entre xmin et xmax)
    x, y, xerr, yerr, xmin, xmax = validate_and_shrink(x, y, xerr, yerr, xmin, xmax)

    # Régression
    if model == "lineaire":
        a = np.sum(x * y) / np.sum(
            x**2
        )  # Application de la formule directe de la méthode des moindres carrés
        b = 0
        xplot = np.array(
            [0, max(x_all)]
        )  # Permettra de tracé la courbe d'ajustement en passant par l'origine
    elif model == "affine":
        a, b = np.polyfit(x, y, 1)
        xplot = np.array([min(x_all), max(x_all)])
    else:
        raise ValueError("Modèle inconnu. Utilisez 'affine' ou 'lineaire'.")

    u_a = u_b = 1
    if xerr is not None or yerr is not None:
        # Monte Carlo pour calculer les incertitudes sur a (et éventuellement b)
        N = 10000
        nbpts = len(x)

        ta, tb = [], []
        for i in range(N):  # Pour chaque jeu de données simulé
            mx = x + xerr * np.random.uniform(
                -1, 1, nbpts
            )  # Génère une liste de x dans son intervalle d'incertitude
            my = y + yerr * np.random.uniform(
                -1, 1, nbpts
            )  # Génère une liste de y dans son intervalle d'incertitude

            if model == "lineaire":
                a_temp = np.sum(mx * my) / np.sum(mx**2)
                ta.append(a_temp)
            elif model == "affine":
                p = np.polyfit(mx, my, 1)
                ta.append(p[0])  # Pente
                tb.append(p[1])  # Ordonnée à l'origine

        u_a, u_b = np.std(ta), np.std(tb)

    if model == "lineaire":
        string2print, value_a = format_value_with_uncertainty(a, u_a)
        print(f"Ajustement entre {xmin} et {xmax} : y = ax")
        print(r"a = " + string2print)
    elif model == "affine":
        string2print_a, value_a = format_value_with_uncertainty(a, u_a)
        string2print_b, value_b = format_value_with_uncertainty(b, u_b)
        print(f"Ajustement entre {xmin} et {xmax} : y = ax + b")
        print(r"a = " + string2print_a)
        print(r"b = " + string2print_b)

    # Calcul du chi²
    y_pred = a * x + b
    # chi2 = np.sum(((y - y_pred) ** 2) / (yerr**2 + (a * xerr) ** 2))
    chi2 = np.sum(
        ((y - y_pred) ** 2) / (yerr**2 + (a * xerr) ** 2)
        if xerr is not None and yerr is not None
        else 1
    )
    print(f"chi2 / (N - p) = {chi2 / (len(x) - (1 if model == 'lineaire' else 2))}")

    # Tracé des données et de l'ajustement
    fig.set_size_inches((8, 7))
    ax.set_xlabel(labelx, fontsize=18)
    ax.set_ylabel(labely, fontsize=18)
    ax.tick_params(axis="both", labelsize=15)

    if show:
        if xerr is not None or yerr is not None:
            ax.errorbar(
                x_all,
                y_all,
                xerr=xerr_all,
                yerr=yerr_all,
                fmt="+",
                mec="k",
                ecolor="k",
                capsize=5,
                label="Mesures",
            )
            # ax.errorbar(x, y, xerr=xerr, yerr=yerr, fmt="x", label="Mesures")
        else:
            ax.plot(
                x_all,
                y_all,
                "x",  # Plot data as x markers
                mec="k",  # Marker edge color
                label="Mesures",  # Label for the data points
            )
    if model == "lineaire":
        ax.plot(xplot, a * xplot + b, label=f"Régression {model} : y = ax")
    elif model == "affine":
        ax.plot(xplot, a * xplot + b, label=f"Régression {model} : y = ax+b")

    ax.legend(fontsize=15)

    if show:
        ax.grid()
        plt.show()

    return a, u_a, b, u_b


def loadfile(filename, globals_scope=None):
    """
    Loads a text file, ignores the first line, and creates variables
    dynamically named after the headers in the first line.

    Parameters:
        filename (str): Path to the text file.
        globals_scope (dict): The globals dictionary where variables will be created.
                              Defaults to the global scope of the caller.

    Returns:
        None
    """
    if globals_scope is None:
        globals_scope = globals()

    with open(filename, "r") as file:
        # Read the first line for column headers
        headers = file.readline().strip().split()

        # Load the rest of the file as a numpy array
        data = np.loadtxt(file)

    # Print the names of the loaded variables
    print(f"Your variable are: {headers}")
    # Create variables dynamically in the provided scope
    for i, header in enumerate(headers):
        globals_scope[header] = data[:, i]


if __name__ == "__main__":
    
    T1 = np.array([21,26,31,36,40.5,45,50,55,59.5])
    T2 = np.array([22,27,31.5,36.5,41,46,51,56,60.5])
    T_bath=np.array([20.4,25.6,30.3,35.4,40.1,45.2,50.0,55.2,60.0])
    DE = np.array([0.331,0.326,0.321,0.315,0.3105,0.3053,0.3004,0.2961,0.2917])
    DE_err =np.array([0.001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001,0.0001])
    
    F= 96485
    R= 8.314
        
    T=273.15+(T1+T2)/2
    T_err = 1 * np.ones(len(T))
    
    x=1/T
    xerr=T_err/T**2
    y=-(F/(R*T))*DE+2*np.log(0.01)
    yerr=np.abs(np.sqrt((xerr/x)**2+(DE_err/DE)**2)*y)

    
    labelx, labely = "1/T", "ln(Ks)"
    fig, ax = plt.subplots()
    a, u_a, b, u_b = regression(
        fig=fig,
        ax=ax,
        x=x,
        y=y,
        xerr=xerr,
        yerr=yerr,
        xmin=None,
        xmax=None,
        labelx=labelx,
        labely=labely,
        model="affine",
        show=True,
    )
    
    
    Delta_r_H = -R*a
    err_Delta_r_H = R*u_a
    
    print(f'Delta_r_H = {Delta_r_H} +/- {err_Delta_r_H}')
    
    Delta_r_S = R*b
    err_Delta_r_S = R*u_b
    
    print(f'Delta_r_S = {Delta_r_S} +/- {err_Delta_r_S}')

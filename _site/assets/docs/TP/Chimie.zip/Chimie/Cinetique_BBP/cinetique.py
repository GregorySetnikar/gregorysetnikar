################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "fin2.txt"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("t", "$ln(\\frac{A_{t0}}{A})$")

t = np.array(df["Temps"]) / 60
A_1 = np.array(df["Soude1M"])
A_2 = np.array(df["Soude0p75M"])
A_3 = np.array(df["Soude0p5M"])
A_4 = np.array(df["Soude_0p25M"])

liste = [A_1, A_2, A_3, A_4]
c = np.array([1, 0.75, 0.5, 0.25]) * 0.755  # mol.L-1

a_list = []
b_list = []
for i in liste:
    y = np.log(i[0] / i)
    results_fit = DAU.regression(x=t, y=y, ax=ax, xmax=1590 / 60)
    a_list.append(results_fit["a"])
    b_list.append(results_fit["b"])


print(f"kapp en min-1  {a_list}")
print(f"Ordonnées à l’origine {b_list}")

fig2, ax2 = DAU.make_fig("log(c)", "$log(k_{app})$")
x = np.log(c)
y = np.log(a_list)

DAU.regression(x=x, y=y, ax=ax2)

# Adding legend and displaying the plot159
ax.legend()
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.ndimage import gaussian_filter1d
import math as math
import time


def detect_delimiter(file_path):
    """
    Détecte automatiquement le délimiteur d'un fichier texte.
    Essaie plusieurs délimiteurs possibles et retourne celui qui fonctionne.

    Parameters:
        file_path (str): Chemin du fichier.

    Returns:
        str: Délimiteur détecté.
    """
    possible_delimiters = ["\t", " ", ",", ";", "|"]

    # Lire les premières lignes pour tester les délimiteurs
    with open(file_path, "r") as f:
        sample_lines = [f.readline() for _ in range(5)]  # Lire les 5 premières lignes

    # Tester chaque délimiteur
    for delimiter in possible_delimiters:
        try:
            # Tester si on peut lire avec ce délimiteur
            sample = [line.split(delimiter) for line in sample_lines]
            # Si le nombre de colonnes est cohérent, retourner ce délimiteur
            if all(len(line) == len(sample[0]) for line in sample):
                print(f"Délimiteur détecté : '{delimiter}'")
                return delimiter
        except Exception as e:
            continue  # Si une erreur se produit, essayer le suivant

    # Si aucun délimiteur valide n'a été trouvé, retourner une valeur par défaut
    print("Délimiteur non détecté, utilisation du délimiteur par défaut '\\t'")
    return "\t"


# Lecture d'un fichier txt et conversion en DataFrame
def loadfile(file_path):
    """
    Lit un fichier txt et le stocke dans un DataFrame.
    Parameters:
        file_path (str): Chemin du fichier.
        delimiter (str): Séparateur dans le fichier (par défaut '\t').
    Returns:
        pd.DataFrame: DataFrame contenant les données.
    """

    delimiter = detect_delimiter(file_path)
    try:
        df = pd.read_csv(file_path, delimiter=delimiter)
        print(f"Fichier chargé avec succès : {file_path}")
        return df
    except Exception as e:
        print(f"Erreur lors de la lecture du fichier : {e}")
        return None


# Masquage des points dans un DataFrame
def mask_points(df, x_col, lower_bound, upper_bound):
    """
    Masque les points en dehors des bornes spécifiées sur x.
    Parameters:
        df (pd.DataFrame): DataFrame contenant les données.
        x_col (str): Nom de la colonne x.
        lower_bound (float): Borne inférieure.
        upper_bound (float): Borne supérieure.
    Returns:
        pd.DataFrame: DataFrame filtré.
    """
    mask = (df[x_col] >= lower_bound) & (df[x_col] <= upper_bound)
    return df[mask]


def format_value_with_uncertainty(value, uncertainty):
    """
    Formate une valeur et son incertitude en écriture scientifique avec deux chiffres significatifs pour l'incertitude.

    Arguments :
        value (float) : la valeur principale.
        uncertainty (float) : l'incertitude associée.

    Retourne :
        str : chaîne de caractères formatée sous la forme "valeur ± incertitude" en notation scientifique.
    """
    if uncertainty == 0:
        formatted_result = f"{value}"
        formatted_value = f"{value}"
        return formatted_result, formatted_value

    if uncertainty <= 0:
        raise ValueError("L'incertitude doit être strictement positive.")

        # uncertainty = np.abs(uncertainty)

    # Obtenir l'ordre de grandeur de l'incertitude
    uncertainty_order = math.floor(
        math.log10(uncertainty)
    )  # Exposant de la puissance de 10
    scale = 10**uncertainty_order  # Échelle pour ajuster à l'ordre de grandeur

    # Réduire l'incertitude et la valeur à une base entre 1 et 10
    reduced_uncertainty = uncertainty / scale
    reduced_value = value / scale

    # Arrondir l'incertitude à 2 chiffres significatifs
    rounded_uncertainty = round(reduced_uncertainty, 1)

    # Ajuster la valeur principale en fonction de l'incertitude
    rounded_value = round(reduced_value, 1)

    # Génération de la chaîne formatée en notation scientifique
    formatted_result = (
        f"({rounded_value:.1f} ± {rounded_uncertainty:.1f}) × 10^{uncertainty_order}"
    )
    formatted_value = f"{rounded_value:.1f}× 10^{uncertainty_order}"
    return formatted_result, formatted_value


# Tracé des données avec incertitudes
def plot(ax, x, y, xerr=None, yerr=None, **kwargs):
    """
    Trace x, y sur une figure donnée avec ou sans incertitudes.
    Parameters:
        ax (matplotlib.axes.Axes): L'axe sur lequel tracer.
        x (array-like): Données en x.
        y (array-like): Données en y.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        **kwargs: Options supplémentaires pour plt.plot.
    """
    if xerr is not None or yerr is not None:
        ax.errorbar(
            x=x,
            y=y,
            xerr=xerr,
            yerr=yerr,
            fmt="+",
            mec="k",
            ecolor="k",
            capsize=5,
            **kwargs,
        )

    else:
        ax.plot(
            x,  # x-axis
            y,  # y-axis
            marker="x",  # Plot data as x markers
            mec="k",
            **kwargs,  # Marker edge color
        )


def smooth(data, smooth_factor):
    return gaussian_filter1d(input=data, sigma=smooth_factor)


def validate_and_shrink(x, y, xerr, yerr, xmin, xmax):
    # Adjust xmin and xmax if needed
    if xmin is None or xmin < min(x):
        xmin = min(x)
    if xmax is None or xmax > max(x):
        xmax = max(x)

    if xmin >= max(x) or xmax <= min(x):
        print("Erreur sur la plage sélectionnée. Ajustement sur tous les points.")
        xmin, xmax = min(x), max(x)

    # Create mask for valid x values within the selected range
    mask = (x >= xmin) & (x <= xmax)

    # Apply mask to x, y, and error arrays, but only if they're not None
    x_filtered = x[mask]
    y_filtered = y[mask]

    # Handle xerr and yerr if they are not None
    if xerr is not None:
        xerr_filtered = xerr[mask]
    else:
        xerr_filtered = None

    if yerr is not None:
        yerr_filtered = yerr[mask]
    else:
        yerr_filtered = None

    return x_filtered, y_filtered, xerr_filtered, yerr_filtered, xmin, xmax


def make_fig(labelx, labely):
    # Tracé des données avec incertitudes

    fig, ax = plt.subplots()
    fig.set_size_inches((8, 7))
    ax.set_xlabel(labelx, fontsize=18)
    ax.set_ylabel(labely, fontsize=18)
    ax.tick_params(axis="both", labelsize=15)
    ax.grid()

    return fig, ax


def regression(
    x, y, xerr=None, yerr=None, ax=None, model="affine", xmin=None, xmax=None, **kwargs
):
    """
    Modèle "affine" : y = ax + b
    Modèle "lineaire" : y = ax
    """

    t0 = time.time()
    # Modification des tableaux pour ne faire l'ajustement que sur la plage de valeurs demandée (x compris entre xmin et xmax)
    x, y, xerr, yerr, xmin, xmax = validate_and_shrink(x, y, xerr, yerr, xmin, xmax)

    # Régression
    if model == "lineaire":
        a = np.sum(x * y) / np.sum(
            x**2
        )  # Application de la formule directe de la méthode des moindres carrés
        b = 0
        xplot = np.array(
            [0, max(x)]
        )  # Permettra de tracé la courbe d'ajustement en passant par l'origine
    elif model == "affine":
        a, b = np.polyfit(x, y, 1)
        xplot = np.array([min(x), max(x)])
    else:
        raise ValueError("Modèle inconnu. Utilisez 'affine' ou 'lineaire'.")

    u_a = u_b = 0
    if xerr is not None or yerr is not None:
        # Monte Carlo pour calculer les incertitudes sur a (et éventuellement b)
        N = 10000
        nbpts = len(x)

        ta, tb = [], []
        for i in range(N):  # Pour chaque jeu de données simulé
            mx = x + xerr * np.random.uniform(
                -1, 1, nbpts
            )  # Génère une liste de x dans son intervalle d'incertitude
            my = y + yerr * np.random.uniform(
                -1, 1, nbpts
            )  # Génère une liste de y dans son intervalle d'incertitude

            if model == "lineaire":
                a_temp = np.sum(mx * my) / np.sum(mx**2)
                ta.append(a_temp)
                u_a = np.std(ta)
            elif model == "affine":
                p = np.polyfit(mx, my, 1)
                ta.append(p[0])  # Pente
                tb.append(p[1])  # Ordonnée à l'origine

                u_a, u_b = np.std(ta), np.std(tb)

    if model == "lineaire":
        string2print, value_a = format_value_with_uncertainty(a, u_a)
        print(f"Ajustement entre {xmin} et {xmax} : y = ax")
        print(r"a = " + string2print)
    elif model == "affine":
        string2print_a, value_a = format_value_with_uncertainty(a, u_a)
        string2print_b, value_b = format_value_with_uncertainty(b, u_b)
        print(f"Ajustement entre {xmin} et {xmax} : y = ax + b")
        print(r"a = " + string2print_a)
        print(r"b = " + string2print_b)

    # Calcul du chi²
    y_pred = a * x + b

    chi2 = np.sum(
        ((y - y_pred) ** 2) / (yerr**2 + (a * xerr) ** 2)
        if xerr is not None and yerr is not None
        else 1
    )
    print(f"chi2 / (N - p) = {chi2 / (len(x) - (1 if model == 'lineaire' else 2))}")

    if ax is not None:
        plot(ax, x, y, xerr=xerr, yerr=yerr, color="black", label="Données brutes")
        if model == "lineaire":
            ax.plot(
                xplot, a * xplot + b, label=f"Régression {model} : y = ax", **kwargs
            )
        elif model == "affine":
            ax.plot(
                xplot, a * xplot + b, label=f"Régression {model} : y = ax+b", **kwargs
            )

        # ax.legend(fontsize=15)

    output = {
        "a": a,
        "b": b,
        "u_a": u_a,  # Incertitude de la pente par Monte Carlo
        "u_b": u_b,  # Incertitude de l'ordonnée à l'origine par Monte Carlo
    }
    t1 = time.time()
    print(f"Temps d'exécution : {t1 - t0:.2f} secondes")
    return output


def monte_carlo_fit(
    x,
    y,
    func,
    p0,
    xerr=None,
    yerr=None,
    n_iter=1000,
    plot_ax=None,
    **kwargs,
):
    """
    Effectue une régression avec une simulation Monte-Carlo et optionnellement trace un snake plot.

    Parameters:
        x (array-like): Données en x.
        y (array-like): Données en y.
        func (callable): Fonction à ajuster.
        p0 (list): Estimations initiales des paramètres.
        xerr (array-like, optional): Incertitudes sur x.
        yerr (array-like, optional): Incertitudes sur y.
        n_iter (int): Nombre de simulations Monte-Carlo.
        plot_ax (matplotlib.axes._axes.Axes, optional): Axe matplotlib pour tracer le snake plot.
        **kwargs: Options supplémentaires pour plt.plot.
    Returns:
        tuple: (paramètres ajustés, incertitudes sur les paramètres).
    """
    t0 = time.time()
    if xerr is None:
        xerr = np.zeros_like(x)
    if yerr is None:
        yerr = np.zeros_like(y)

    # Fit initial
    popt, _ = curve_fit(func, x, y, p0=p0, sigma=yerr, absolute_sigma=True)

    # Monte-Carlo simulations
    param_samples = []
    for _ in range(n_iter):
        # Simuler x et y en tenant compte des erreurs
        x_sim = x + np.random.normal(0, xerr)
        y_sim = y + np.random.normal(0, yerr)

        try:
            popt_sim, _ = curve_fit(
                func, x_sim, y_sim, p0=popt, sigma=yerr, absolute_sigma=True
            )
            param_samples.append(popt_sim)
        except RuntimeError:
            # Si le fit échoue pour une simulation, ignorer cette itération
            continue

    param_samples = np.array(param_samples)
    if param_samples.size == 0:
        raise RuntimeError(
            "Aucune simulation Monte-Carlo n'a réussi. Vérifiez vos données et paramètres initiaux."
        )

    # Moyenne et écart-type des paramètres ajustés
    param_mean = np.mean(param_samples, axis=0)
    param_std = np.std(param_samples, axis=0)

    # Optionnel : tracer le snake plot
    if plot_ax is not None:
        # Calculer la courbe centrale
        y_fit = func(x, *param_mean)

        # Simulation Monte-Carlo pour générer les incertitudes sur y
        y_samples = []
        for _ in range(n_iter):
            params_sample = np.random.normal(param_mean, param_std)
            y_samples.append(func(x, *params_sample))
        y_samples = np.array(y_samples)

        # Calcul des intervalles d'incertitudes
        y_low = np.percentile(y_samples, 16, axis=0)  # 1 sigma inférieur
        y_high = np.percentile(y_samples, 84, axis=0)  # 1 sigma supérieur

        # Tracer la courbe centrale
        plot_ax.plot(x, y_fit, **kwargs)
        # Tracer la bande
        plot_ax.fill_between(x, y_low, y_high, alpha=0.5, **kwargs)

    for i in range(0, len(param_mean)):
        print(
            f"Paramètre {i}: Moyenne = {param_mean[i]:.3f}, Ecart-type = {param_std[i]:.3f}"
        )

    t1 = time.time()
    print(f"Temps d'exécution : {t1 - t0:.2f} secondes")

    return param_mean, param_std


# Calcul du chi2 réduit
def calculate_chi2(x, y, yerr, func, popt):
    """
    Calcule le chi2 réduit pour un ajustement donné.
    Parameters:
        x (array-like): Données x.
        y (array-like): Données y observées.
        yerr (array-like): Incertitudes sur y.
        func (callable): Fonction ajustée.
        popt (array-like): Paramètres optimisés.
    Returns:
        float: Valeur du chi2 réduit.
    """
    residuals = y - func(x, *popt)
    chi2 = np.sum((residuals / yerr) ** 2)
    dof = len(y) - len(popt)  # Degrés de liberté
    return chi2 / dof


# Calcul des Z-scores
def calculate_zscores(x, y, yerr, func, popt):
    """
    Calcule les z-scores des données par rapport au fit.
    Parameters:
        x (array-like): Données x.
        y (array-like): Données y observées.
        yerr (array-like): Incertitudes sur y.
        func (callable): Fonction ajustée.
        popt (array-like): Paramètres optimisés.
    Returns:
        array-like: Z-scores pour chaque point.
    """
    residuals = y - func(x, *popt)
    return residuals / yerr


# Tracé de diagrammes de Bode
def plot_bode(ax_mag, ax_phase, freq, mag, phase):
    """
    Trace un diagramme de Bode.
    Parameters:
        ax_mag (matplotlib.axes.Axes): Axe pour la magnitude.
        ax_phase (matplotlib.axes.Axes): Axe pour la phase.
        freq (array-like): Fréquence.
        mag (array-like): Magnitude en dB.
        phase (array-like): Phase en degrés.
    """
    ax_mag.semilogx(freq, mag, label="Magnitude")
    ax_phase.semilogx(freq, phase, label="Phase")
    ax_mag.set_ylabel("Magnitude (dB)")
    ax_phase.set_ylabel("Phase (°)")
    ax_phase.set_xlabel("Fréquence (Hz)")
    ax_mag.legend()
    ax_phase.legend()


# Tracé de diagramme de Nyquist
def plot_nyquist(ax, real, imag):
    """
    Trace un diagramme de Nyquist.
    Parameters:
        ax (matplotlib.axes.Axes): Axe sur lequel tracer.
        real (array-like): Partie réelle.
        imag (array-like): Partie imaginaire.
    """
    ax.plot(real, imag, label="Nyquist")
    ax.plot(real, -imag, linestyle="--", label="Nyquist (sym)")
    ax.set_xlabel("Re(Z)")
    ax.set_ylabel("Im(Z)")
    ax.legend()

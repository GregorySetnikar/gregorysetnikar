################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy

offset = 0  # 0.002

# Masse en eau de calorimètre
m1 = 303.90
m1_err = 0.01
m1u = DAU.np2unp(m1, m1_err)

U1 = 0.792
U1_err = 0.005
U1u = DAU.np2unp(U1, U1_err)
T1u = DAU.U_to_T(U_temp=U1u, offset=offset)
print(f"T1 {T1u}")

m2 = 322.05
m2_err = 0.01
m2u = DAU.np2unp(m2, m2_err)

U2 = 3.756
U2_err = 0.005
U2u = DAU.np2unp(U2, U2_err)
T2u = DAU.U_to_T(U_temp=U2u, offset=offset)
print(f"T2 = {T2u}")


Uf = 2.07
Uf_err = 0.005
Ufu = DAU.np2unp(Uf, Uf_err)
Tfu = DAU.U_to_T(Ufu)
print(f"Tf {Tfu}")

mu = (m1u * (T1u - Tfu) + m2u * (T2u - Tfu)) / (Tfu - T1u)
print(f"mu {mu}")


# Chaleur Latente de fusion
ce = 4.18  # kJ.K-1.kg-1

# eau
m1 = 339.40
m1_err = 0.01
m1u = DAU.np2unp(m1, m1_err)

U1 = 0.739
U1_err = 0.001
U1u = DAU.np2unp(U1, U1_err)
T1u = DAU.U_to_T(U_temp=U1u, offset=offset, kelvin=True)
print(f"T1 {T1u}")

# glace
m2 = 12.5
m2_err = 0.01
m2u = DAU.np2unp(m2, m2_err)

U2 = 0
U2_err = 0.001
U2u = DAU.np2unp(U2, U2_err)
T2u = DAU.U_to_T(U_temp=U2u, offset=offset, kelvin=True)
print(f"T2 = {T2u}")


Uf = 0.655
Uf_err = 0.01
Ufu = DAU.np2unp(Uf, Uf_err)
Tfu = DAU.U_to_T(U_temp=Ufu, offset=offset, kelvin=True)
print(f"Tf {Tfu}")


Lfus = ce * ((((m1u + mu) / m2u) * (T1u - Tfu)) + T2u - Tfu)
print(f"Lfus {Lfus}")

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "son_eau.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("t (s)", "d (m)")

# Performing regression with uncertainties and plotting raw data

T = [17.5, 6]

v = []

for i in T:
    dff = DAU.filter_df(df, "T", i)
    x = np.array(dff["periode"]) * 1e-6
    y = np.array(dff["d"]) * 1e-2
    xerr = np.ones(len(x)) * 10 * 1e-6
    yerr = np.ones(len(y)) * 0.1 * 1e-2
    results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax)
    v.append(results_fit["a"])


print(v)

# Adding legend and displaying the plot
ax.legend()
plt.show()

# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 04:43:34 2024

@author: ens
"""


import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import ufloat, unumpy
import uncertainties.umath as umath


DAU.init_umath()

# Paramètres

# retard_syst = 330e-6
retard_syst = 278e-6

d = 1.79  # m
d_err = 0.01  # m
ud = DAU.np2unp(d, d_err)

tau = 5.48e-3 - retard_syst
tau_err = 0.04e-3  # s
utau = DAU.np2unp(tau, tau_err)

uc = ud / utau

f = 41.4e3  # Hz
f_err = 0.1e3  # Hz
uf = DAU.np2unp(f, f_err)

L = 3.4  # longueur du tube en m
L_err = 0.1  # en m
uL = DAU.np2unp(L, L_err)

a = 0.0424  # en m
a_err = 0.0001  # en m
ua = DAU.np2unp(a, a_err)


retard = np.array([10.80, 11.38, 10.44, 11.26, 10.78, 10.42, 11.3]) * 1e-3
retard -= retard_syst
retard_err = np.ones(len(retard)) * 0.04e-3
uretard = DAU.np2unp(retard, retard_err)

uvg = uL / uretard

ulambda_g = uc**2 / (uf * uvg)


mu_n = np.sort(np.pi * ua * (((uf / uc) ** 2 - (1 / ulambda_g) ** 2)) ** 0.5)
mu_th = np.sort([1.84, 3.05, 4.2, 5.32, 6.42, 7.5, 8.58, 3.83, 5.33, 6.71, 8.01, 9.28])

print(mu_n)
print(mu_th)

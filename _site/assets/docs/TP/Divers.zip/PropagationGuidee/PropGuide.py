# -*- coding: utf-8 -*-
"""
Created on Fri Dec  6 04:43:34 2024

@author: ens
"""


import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

# Paramètres

d = 1.81 # m
tau = 5.34e-3
c = d/tau # m/s


f = 40e3
L = 3.41  # longueur du tube en m
a = 0.0424

#retard = np.array([10.37, 10.74, 11.16, 11.74, 10.41, 10.77, 11.22, 11.76, 10.08, 10.36, 10.73])*1e-3

retard = np.array([10.10, 10.43, 10.79, 11.30, 11.68, 12.1])*1e-3
retard = np.array([10.42, 10.87, 11.92, 10.76, 11.21, 11.93, 10.45, 10.85, 10.87, 11.31, 10.5, 11.35])*1e-3


vg = L/retard

lambda_g = c**2/(f*vg)

mu_n = np.sort(np.pi*a*((f/c)**2-(1/lambda_g)**2)**(0.5))

mu_th = np.sort([1.84, 3.05, 4.2 , 5.32, 6.42, 7.5, 8.58, 3.83, 5.33, 6.71, 8.01, 9.28])

print(mu_n)
print(mu_th)








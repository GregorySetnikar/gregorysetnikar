#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN

Préparation à l’Agrégation de Physique - ENS Lyon MÉCANIQUE
Version du 12/10/2022
"""

# %% Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt
from copy import deepcopy


# %% Définition de fonctions pour effectuer une modélisations affine À NE PAS MODIFIER
def modele_affine(X, Y, u_X, u_Y, a_test, b_test):
    """
    Effectue une modélisation affine Y = a * X + b, en tenant compte des incertitudes sur X (u_X) et Y (u_Y).
    La fonction utilise la méthode des moindres carrés à partir de paramètres d’essai a_test et b_test.
    La fonction renvoie un tableau qui contient dans l’ordre :
    - la valeur de a optimisée (a_opt),
    - la valeur de b optimisée (b_opt),
    - l’incertitude sur la valeur de a (u_a_opt),
    - l’incertitude sur la valeur de b (u_b_opt),
    - la valeur du chi2 réduit (chi2_opt).
    """

    def affine(x, a, b):
        return a * x + b

    def residu_affine(p_affine, x, y, u_x, u_y):
        a = p_affine[0]
        b = p_affine[1]
        return (y - affine(x, a, b)) / np.sqrt(u_y * u_y + (a * u_x) ** 2)

    opt_affine = opt.least_squares(
        residu_affine, np.array([a_test, b_test]), args=(X, Y, u_X, u_Y)
    )
    a_opt = opt_affine.x[0]
    b_opt = opt_affine.x[1]
    hessian_affine = np.matmul(opt_affine.jac.transpose(), opt_affine.jac)
    u_a_opt = np.sqrt(2.0 / hessian_affine[0, 0])
    u_b_opt = np.sqrt(2.0 / hessian_affine[1, 1])
    chi2_opt = np.sum(residu_affine(np.array([a_opt, b_opt]), X, Y, u_X, u_Y) ** 2) / (
        len(X) - 2
    )
    print("Résultats de l’ajustement :")
    print("- pente = {0:.2e} +/- {1:.1e}".format(a_opt, u_a_opt))
    print("- ordonnée à l’origine = {0:.2e} +/- {1:.1e}".format(b_opt, u_b_opt))
    return np.array([a_opt, b_opt, u_a_opt, u_b_opt, chi2_opt])


def distance(A, B):
    return np.sqrt((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2)


def plus_proche_voisin(A, X, Y):
    B = []
    if A == [X[0], Y[0]]:
        B = [X[1], Y[1]]
    else:
        B = [X[0], Y[0]]
    for i in range(len(X)):
        if distance(A, [X[i], Y[i]]) < distance(A, B) and distance(A, [X[i], Y[i]]) > 0:
            B = [X[i], Y[i]]
    return B


# %% Paramètres À MODIFIER
filename1 = "full.txt"  # nom du fichier avec x, y en m (mobile 1)
filename2 = "full.txt"  # nom du fichier avec x, y en m (mobile 2)
T = 0.04  # période des impulsions en s
u_x = 0.001  # incertitude sur x en m
u_y = 0.001  # incertitude sur y en m
m1 = 0.97952  # masse du mobile 1 en kg
m2 = 0.97894  # masse du mobile 2 en kg

# %% Importation des données
data1 = np.genfromtxt(filename1)
data2 = np.genfromtxt(filename2)

x1 = np.array((0.001 * data1[:, 1])).tolist()
y1 = np.array((-0.001 * data1[:, 2])).tolist()

x2 = (0.001 * data2[:, 1]).tolist()
y2 = (-0.001 * data2[:, 2]).tolist()

# Pointage des positions initiales des mobiles
x01 = x1[-1]
y01 = y1[-1]
x02 = x2[-1]
y02 = y2[1]

x1_sort = [x01]
y1_sort = [y01]
x2_sort = [x02]
y2_sort = [y02]

x1.remove(x01)
y1.remove(y01)
x2.remove(x02)
y2.remove(y02)

for i in range(len(x1)):
    a1 = plus_proche_voisin([x1_sort[-1], y1_sort[-1]], x1, y1)[0]
    b1 = plus_proche_voisin([x1_sort[-1], y1_sort[-1]], x1, y1)[1]
    x1_sort.append(a1)
    x1.remove(a1)
    y1_sort.append(b1)
    y1.remove(b1)

    a2 = plus_proche_voisin([x2_sort[-1], y2_sort[-1]], x2, y2)[0]
    b2 = plus_proche_voisin([x2_sort[-1], y2_sort[-1]], x2, y2)[1]
    x2_sort.append(a2)
    x2.remove(a2)
    y2_sort.append(b2)
    y2.remove(b2)

# Pour corriger manuellement une erreur de plus proche voisin si l’angle de rebond est trop aigu
# y2bis = deepcopy(y2_sort)
# x2bis = deepcopy(x2_sort)
# aa = y2_sort[20]
# y2_sort.remove(aa)
# y2_sort.insert(22, aa)
# bb = x2_sort[20]
# x2_sort.remove(bb)
# x2_sort.insert(22, bb)

# %% Calcul des vitesses
vx1 = np.diff(x1_sort) / T
vx2 = np.diff(x2_sort) / T
vy1 = np.diff(y1_sort) / T
vy2 = np.diff(y2_sort) / T
t = [i * T for i in range(len(vx1))]

u_vx1 = np.sqrt(2 * u_x**2) / T
u_vy1 = np.sqrt(2 * u_y**2) / T

u_vx2 = np.sqrt(2 * u_x**2) / T
u_vy2 = np.sqrt(2 * u_y**2) / T

# %% Tracé des données
plt.figure()
plt.errorbar(
    x1_sort,
    y1_sort,
    [u_x for i in range(len(x1_sort))],
    [u_x for i in range(len(x1_sort))],
    capsize=0.5,
    elinewidth=2,
    label="mobile 1",
)
plt.errorbar(
    x2_sort,
    y2_sort,
    [u_x for i in range(len(x1_sort))],
    [u_x for i in range(len(x1_sort))],
    capsize=0.5,
    elinewidth=2,
    label="mobile 2",
)

plt.xlabel(r"$x$ (m)")
plt.ylabel(r"$y$ (m)")
plt.legend()


plt.figure()
plt.errorbar(t, vx1, u_vx1, capsize=0.5, elinewidth=2)
plt.errorbar(t, vy1, u_vy1, capsize=0.5, elinewidth=2)
plt.xlabel(r"t$ (s)")
plt.ylabel(r"$v$ (m/s)")
plt.legend()


# %% Energies en fonction du temps
Ec1 = 0.5 * m1 * (vx1**2 + vy1**2)
Ec2 = 0.5 * m2 * (vx2**2 + vy2**2)

u_Ec1 = m1 * np.sqrt(u_vx1**2 * vx1**2 + u_vy1**2 * vy1**2)
u_Ec2 = m2 * np.sqrt(u_vx2**2 * vx2**2 + u_vy2**2 * vy2**2)

plt.figure()
plt.errorbar(t, Ec1, u_Ec1, label="Ec1")
plt.errorbar(t, Ec2, u_Ec2, label="Ec2")
plt.errorbar(t, Ec1 + Ec2, u_Ec2, label="Ec_tot")
plt.xlabel(r"$t$ (s)")
plt.ylabel(r"$E$ (J)")
plt.legend()
plt.show()

# %% Centre d’inertie
x_i = (m1 * np.array(x1_sort) + m2 * np.array(x2_sort)) / (m1 + m2)
y_i = (m1 * np.array(y1_sort) + m2 * np.array(y2_sort)) / (m1 + m2)

u_xi = 1 / (m1 + m2) * np.sqrt(m1**2 * u_x**2 + m2**2 * u_x**2)
u_yi = 1

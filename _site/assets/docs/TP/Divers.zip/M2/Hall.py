# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 04:59:23 2024

@author: ens
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import PythonLyonUtils as PLU


def affine(x,a,b):
    return a * x +b


m1 = 1.107 # masse 1 en kg
m2 = 1.10825 # masse 2 en kg

filename1 = "data_J.txt"

data = np.genfromtxt(filename1)
L1 = (data[:, 0])
L2 = (data[:, 1])
f1 = (data[:, 2])
f2 = (data[:, 3])

x1=L1**2
x2=L2**2

y1 = m1*9.81*L1/(2*np.pi*f1)**2
y2 = m2*9.81*L2/(2*np.pi*f2)**2

p, pcov = curve_fit(affine, x1,y1)
p2, pcov2 = curve_fit(affine, x2,y2)
up = np.sqrt(np.diag(pcov))

fit1 = affine(x1,p[0],p[1])
fit2 = affine(x2,p[0],p[1])


#plt.figure()
#plt.scatter(x1, y1)
#plt.plot(x1,fit1)
#plt.scatter(x2, y2)
#plt.plot(x2,fit2)
##plt.plot(i_H*B, linear(i_H*B, p), 'k')
#plt.grid()
#plt.show()
#plt.xlabel('x')
#plt.ylabel('y')
print(f"J01 = {p[1]}")
print(f"J02 = {p2[1]}")

J2 = p2[1]
J1 = p[1]

#######

filename1 = "data_Jc.txt"

data = np.genfromtxt(filename1)
L = (data[:, 0])
f = (data[:, 1])

y = (J2+m2*L**2)*(2*np.pi*f)**2

p, pcov = curve_fit(affine, L, y)

C = p[1]
print(f"C = {C}")

#plt.figure()
#plt.scatter(L, y)
#plt.plot(L, affine(L, p[0], p[1]), 'k')
#plt.grid()
#plt.show()


### Energie


filename_batt = "battements.txt"

data = np.genfromtxt(filename_batt)
freq = (data[:, 0])
FFT = (data[:, 1])
Temps = (data[:, 2])
V1 = (data[:, 3])
V2 = (data[:, 5])


plt.figure()
plt.plot(Temps, V1, 'k')
plt.plot(Temps, V2, 'b')

plt.grid()
plt.show()














# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 05:03:14 2024

@author: ens
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import PythonLyonUtils as PLU


def affine(x,a,b):
    return a * x +b

def smooth(y, box_pts):
    box = np.ones(box_pts)/box_pts
    y_smooth = np.convolve(y, box, mode="same")
    return y_smooth

a1 = 0.142
b1 = -76.743E-3
a2 = 0.188
b2 = 0.121

J1 = 0.0730
J2 = 0.0709
M = 1.107
L = 0.514
C = 0.34

filename_batt = "sym_test.txt"

data = np.genfromtxt(filename_batt)

Temps = (data[:, 0])
V1 = smooth((data[:, 1]), 3)
V2 = smooth((data[:, 3]), 3)

dt = Temps[1]-Temps[0]

theta_1 = 2*np.pi/180*(V1-b1)/a1
theta_2 = 2*np.pi/180*(V2-b2)/a2

theta_1 -= np.mean(theta_1)
theta_2 -= np.mean(theta_2)

theta_point_1 = np.diff(theta_1)/dt
theta_point_2 = np.diff(theta_2)/dt

E1 = 1/2*(J1+M*L**2)*theta_point_1**2
Ep1 =  M*9.81*L*(1-np.cos(theta_1[:-1]))
E2 = 1/2*(J2+M*L**2)*theta_point_2**2 
Ep2 = M*9.81*L*(1-np.cos(theta_2[:-1]))
Ec = 1/2*C*(theta_1[:-1]-theta_2[:-1])**2
Etot = E1 + Ep1 + E2 + Ep2 + Ec

plt.figure()
plt.plot(Temps, theta_1, 'k')
plt.plot(Temps, theta_2, 'b')
plt.grid()
plt.show()

plt.figure()
plt.plot(Temps[:-1], E1, label='E1')
plt.plot(Temps[:-1], E2, label='E2')
plt.plot(Temps[:-1], Ep1, label='Ep1')
plt.plot(Temps[:-1], Ep2, label='Ep2')
plt.plot(Temps[:-1], Ec, label='Ec')
plt.plot(Temps[:-1], Etot)
plt.show()
plt.legend()

plt.figure()
plt.semilogy(Temps[:-1], Etot)
plt.grid()
plt.show()
plt.legend()

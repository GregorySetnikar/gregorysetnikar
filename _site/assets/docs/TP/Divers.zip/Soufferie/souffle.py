# Importing required packages
import python_DataAnalysisUtils_lyon as da
import numpy as np
import matplotlib.pyplot as plt

# Reading data
file_path = "souffle_data.csv"  # Replace with the correct file path
df, units = da.loadfile(file_path)

# print(f"df {df}")

# Sphère
if False:
    df = da.filter_df(df, "Forme", "Sphère_2")

    V = df["Vitesse"]  # en m.s-1
    V_err = df["Vitesse_erreur"]  # en m.s-1

    F_mv = df["Force"]  # en mV
    F_err = df["Force_erreur"]  # en mV
    F = 160 * F_mv
    F_err = np.sqrt((F_err / F_mv) ** 2 + (8 / 160) ** 2) * F

    # print(f"F {F} pm {F_err}")
    x = V**2
    # print(f"x {x} xlength {x.shape}")
    xerr = 2 * V_err * V

    y = F
    # print(f"y {y} ylength {y.shape}")
    yerr = F_err
    # Creating a blank figure with x, y labels
    fig, ax = da.make_fig("$v^2$", "F")

    # Performing regression with uncertainties and plotting raw data
    results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

    rho = 1.19
    rho_err = 0.02
    S = np.pi * (3.86e-2 / 2) ** 2
    S_err = 2 * (0.02e-2) * S

    cx = 2 * results_fit["a"] * 1e-3 / (rho * S)
    cx_err = cx * np.sqrt(
        (S_err / S) ** 2
        + (rho_err / rho) ** 2
        + (results_fit["u_a"] / results_fit["a"]) ** 2
    )

    string, val = da.format_value_with_uncertainty(cx, cx_err)

    print(f" cx = {string}")


# Cone
if False:

    df = da.filter_df(df, "Forme", "Cone")

    V = df["Vitesse"]  # en m.s-1
    V_err = df["Vitesse_erreur"]  # en m.s-1

    F_mv = df["Force"]  # en mV
    F_err = df["Force_erreur"]  # en mV
    F = 160 * F_mv
    F_err = np.sqrt((F_err / F_mv) ** 2 + (8 / 160) ** 2) * F

    # print(f"F {F} pm {F_err}")
    x = V**2
    # print(f"x {x} xlength {x.shape}")
    xerr = 2 * V_err * V

    y = F
    # print(f"y {y} ylength {y.shape}")
    yerr = F_err
    # Creating a blank figure with x, y labels
    fig, ax = da.make_fig("$v^2$", "F")

    # Performing regression with uncertainties and plotting raw data
    results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

    d = 3.83e-2
    L = 7.1e-2

    C_theo = 0.012 + 0.048 * (d / L) + 0.997 * (d / L) ** 2

    rho = 1.19
    rho_err = 0.02
    S = np.pi * (d / 2) ** 2
    S_err = 2 * (0.02e-2) * S

    cx = 2 * results_fit["a"] * 1e-3 / (rho * S)
    cx_err = cx * np.sqrt(
        (S_err / S) ** 2
        + (rho_err / rho) ** 2
        + (results_fit["u_a"] / results_fit["a"]) ** 2
    )

    string, val = da.format_value_with_uncertainty(cx, cx_err)

    print(f"C_theo {C_theo}")
    print(f" cx = {string}")

if True:

    df = da.filter_df(df, "Forme", "Profile")

    V = df["Vitesse"]  # en m.s-1
    V_err = df["Vitesse_erreur"]  # en m.s-1

    F_mv = df["Force"]  # en mV
    F_err = df["Force_erreur"]  # en mV
    F = 160 * F_mv
    F_err = np.sqrt((F_err / F_mv) ** 2 + (8 / 160) ** 2) * F

    # print(f"F {F} pm {F_err}")
    x = V**2
    # print(f"x {x} xlength {x.shape}")
    xerr = 2 * V_err * V

    y = F
    # print(f"y {y} ylength {y.shape}")
    yerr = F_err
    # Creating a blank figure with x, y labels
    fig, ax = da.make_fig("$v^2$", "F")

    # Performing regression with uncertainties and plotting raw data
    results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

    d = 3.83e-2
    L = 10.7e-2

    C_theo = 0.012 + 0.048 * (d / L) + 0.997 * (d / L) ** 2

    rho = 1.19
    rho_err = 0.02
    S = np.pi * (d / 2) ** 2
    S_err = 2 * (0.02e-2) * S

    cx = 2 * results_fit["a"] * 1e-3 / (rho * S)
    cx_err = cx * np.sqrt(
        (S_err / S) ** 2
        + (rho_err / rho) ** 2
        + (results_fit["u_a"] / results_fit["a"]) ** 2
    )

    string, val = da.format_value_with_uncertainty(cx, cx_err)

    print(f"C_theo {C_theo}")
    print(f" cx = {string}")

plt.show()

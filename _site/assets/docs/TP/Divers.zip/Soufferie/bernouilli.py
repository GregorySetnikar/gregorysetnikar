################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "bernouilli.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

v = np.array(df["v"])
verr = np.array(df["verr"])

h = np.array(df["h"]) - np.array(df["h"])[0]
herr = np.array(df["herr"])


# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("$v^2/2 (m/s)^2$", "$\Delta P (en Pa)$")

# Performing regression with uncertainties and plotting raw data

x = (v * v) / 2
xerr = verr * v

P = 0.835e3 * 9.81 * h * 1e-3
Perr = 0.835e3 * 9.81 * herr * 1e-3

results_fit = DAU.regression(x=x, y=P, xerr=xerr, yerr=Perr, ax=ax, color="blue")

print(f"rho {results_fit["a"]} pm {results_fit["u_a"]}")

# Adding legend and displaying the plot
ax.legend()
plt.show()

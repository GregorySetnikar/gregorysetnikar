# Importing required packages
import python_DataAnalysisUtils_lyon as da
import numpy as np
import matplotlib.pyplot as plt


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "poiseuille.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

h0 = df["h0"]  # en cm
tau = df["tau"]  # en s
mf = df["mf"]  # en g
m0 = df["m0"]  # en g

m = mf - m0

h0_err = np.ones(h0.shape) * 0.1
tau_err = np.ones(tau.shape) * 0.1
m_err = np.ones(m.shape) * 0.2

L = 33  # en cm
H = 31  # en cm

heau = (H - (L - h0)) * 10 ** (-2)

Qm = m / tau

x = heau
y = Qm
xerr = np.ones(x.shape) * 0.2
yerr = np.ones(y.shape) * 0.1
# Creating a blank figure with x, y labels
fig, ax = da.make_fig("x", "y")

# Performing regression with uncertainties and plotting raw data
results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

D = 1.74e-3  # en m
g = 9.81
Ltube = 1.52  # en m

eta = (np.pi + D**4 * g) / (128 * Ltube * results_fit["a"])
print(eta)

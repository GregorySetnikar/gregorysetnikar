#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Benjamin GUISELIN

Préparation à l’Agrégation de Physique - ENS Lyon MÉCANIQUE
Version du 12/10/2022
"""

# %% Importation des librairies À NE PAS MODIFIER
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as opt
from copy import deepcopy


filename1 = "Masse1.txt"  # nom du fichier avec x, y en m (mobile 1)
filename2 = "Masse2.txt"  # nom du fichier avec x, y en m (mobile 2)
T = 0.04  # période des impulsions en s
u_x = 0.001  # incertitude sur x en m
u_y = 0.001  # incertitude sur y en m
m1 = 0.6967  # masse du mobile 1 en kg
m2 = 0.6970  # masse du mobile 2 en kg

# %% Importation des données
data1 = np.genfromtxt(filename1)
data2 = np.genfromtxt(filename2)
x1 = (0.001 * data1[:, 4]).tolist()
y1 = (-0.001 * data1[:, 5]).tolist()
x2 = (0.001 * data2[:, 4]).tolist()
y2 = (-0.001 * data2[:, 5]).tolist()

x1 = np.flip(x1)
y1 = np.flip(y1)

vx1 = np.diff(x1) / T
vy1 = np.diff(y1) / T
vx2 = np.diff(x2) / T
vy2 = np.diff(y2) / T

t = [i * T for i in range(len(vx1))]

fig, ax = plt.subplots()
ax.plot(x1, y1)
ax.plot(x2, y2)
ax.grid()
# plt.show()


# %% Energies en fonction du temps
Ec1 = 0.5 * m1 * (vx1**2 + vy1**2)
Ec2 = 0.5 * m2 * (vx2**2 + vy2**2)

# u_Ec1 = m1 * np.sqrt(u_vx1**2 * vx1**2 + u_vy1**2 * vy1**2)
# u_Ec2 = m2 * np.sqrt(u_vx2**2 * vx2**2 + u_vy2**2 * vy2**2)

fig2, ax2 = plt.subplots()
# plt.errorbar(t, Ec1, u_Ec1)
# plt.errorbar(t, Ec2, u_Ec2)
ax2.plot(t, Ec1, label="Ec1")
ax2.plot(t, Ec2, label="Ec2")
ax2.plot(t, Ec2 + Ec1, label="Etot")
ax2.set_xlabel(r"$t$ (s)")
plt.ylabel(r"$E$ (J)")
plt.legend()

# %% Centre d’inertie
x_i = (m1 * np.array(x1) + m2 * np.array(x2)) / (m1 + m2)
y_i = (m1 * np.array(y1) + m2 * np.array(y2)) / (m1 + m2)

# u_xi = 1 / (m1 + m2) * np.sqrt(m1**2 * u_x**2 + m2**2 * u_x**2)
# u_yi = 1

ax.plot(x_i, y_i)

plt.show()

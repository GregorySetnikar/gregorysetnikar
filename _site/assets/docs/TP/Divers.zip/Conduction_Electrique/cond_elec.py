################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Reading data
file_path = "data_cond_elec.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

T = df["Température"]
T_err = np.ones(len(T)) * 0.1

R = df["R"]
R_err = np.ones(len(R)) * 0.001
uR = DAU.np2unp(R, R_err)


L = 1710e-2  # m
L_err = 5e-2  #  m
uL = DAU.np2unp(L, L_err)

d = 0.8e-3
d_err = 0.01e-3
ud = DAU.np2unp(d, d_err)

S = np.pi * (d / 2) ** 2


urho = (uR * S) / uL
rho, rho_err = DAU.unp2np(urho)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("T (en °C)", "$\\rho$ (en $\Omega.m)$")

# Performing regression with uncertainties and plotting raw data
results_fit = DAU.regression(x=T, y=rho, xerr=T_err, yerr=rho_err, ax=ax, color="blue")

ax.legend()
plt.show()

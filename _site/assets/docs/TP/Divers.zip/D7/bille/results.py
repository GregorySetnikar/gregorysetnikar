import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt

# Reading data


diametre = np.array([1.5, 2.05, 4.02, 5.99, 8.05, 10.98])
N = len(diametre)

# Creating a blank figure with x, y labels
fig, ax = da.make_fig("x", "y")


for i in range(1, 7):

    file_path = f"./bille/data_{i}.txt"  # Replace with the correct file path
    df, units = da.loadfile(file_path)
    df = df.dropna()

    Temps = df["Temps"]
    y = df["Mouvement"]

    # Performing regression with uncertainties and plotting raw data
    results_fit = da.regression(x=Temps, y=y, ax=ax, color="blue")

plt.show()

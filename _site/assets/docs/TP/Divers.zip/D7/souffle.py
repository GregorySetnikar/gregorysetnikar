# Importing required packages
import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt

# Reading data
file_path = "souffle.txt"  # Replace with the correct file path
df, units = da.loadfile(file_path)

print(f"df {df}")

V = df["Vitesse"]  # en m.s-1
V_err = df["Vitesse_erreur"]  # en m.s-1

F = df["Force"]  # en mV
F_err = df["Force_erreur"]  # en mV

x = V**2
# print(f"x {x} xlength {x.shape}")
xerr = 2 * V_err * V

y = F
# print(f"y {y} ylength {y.shape}")
yerr = F_err
# Creating a blank figure with x, y labels
fig, ax = da.make_fig("x", "y")

# Performing regression with uncertainties and plotting raw data
results_fit = da.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

plt.show()

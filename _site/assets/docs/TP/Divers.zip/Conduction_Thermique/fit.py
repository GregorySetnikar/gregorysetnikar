import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt


def func(t, omega, A0, A1, phi):

    U = A0 + A1 * np.cos(omega * t + phi)
    return U


list_f = [10, 14]

df, units = DAU.loadfile("all_data.csv")

A = []
phi = []
for f in list_f:
    freq = f * 1e-3  # Hz
    omega = 2 * np.pi * freq
    df_filtered = DAU.filter_df(df=df, column_name="f", value=f)
    t = df_filtered["Temps"]
    A1_i = []
    phi_i = []
    omega_l = []
    list_y = ["EA1", "EA2", "EA3", "EA4", "EA5", "EA6"]
    for i in list_y:

        fig, ax = DAU.make_fig("t", "U")
        y = df_filtered[i]

        DAU.plot(ax, t, y)

        data_liss = DAU.smooth(data=y, smooth_factor=10)
        DAU.plot(ax, t, data_liss, color="blue")

        fit_monte_carlo, fit_monte_carlo_err = DAU.monte_carlo_fit(
            x=t,
            y=data_liss,
            func=func,
            p0=[omega, 0.26, 0.26, 1.5],
            plot_ax=ax,
            linewidth=7,
        )

        A1_i.append(fit_monte_carlo[1])
        phi_i.append(fit_monte_carlo[2])
        omega_l.append(fit_monte_carlo[0])
    # plt.show()

    A.append(A1_i)
    phi.append(phi_i)

rho = 8.96e6
c = 0.385


# A = np.array([28.84e-3, 12.33e-3, 6.045e-3, 2.549e-3, 1.295e-3])


fig2, ax2 = DAU.make_fig("x*$\sqrt(\omega)$ (m)", r"ln(A)")

for i in range(0, len(A)):

    omega = 2 * np.pi * np.array(list_f[i])
    indice_capteur = np.linspace(1, 5, 5)
    y = np.log(A[i])
    x = 0.05 * indice_capteur * np.sqrt(omega)

    result_fit = DAU.regression(ax=ax2, x=x, y=y)

    delta = 1 / result_fit["a"]
    kappa = delta**2 * omega / 2

    lambda_th = rho * kappa * c

    print(lambda_th)

    plt.show()

# -*- coding: utf-8 -*-
"""
Created on Wed May  7 14:48:17 2025

@author: Valentin
"""

import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt

f = 10e-3
omega = 2 * np.pi * f
rho = 8.96e6
c = 0.385

indice_capteur = np.linspace(1, 5, 5)

A = np.array([28.84e-3, 12.33e-3, 6.045e-3, 2.549e-3, 1.295e-3])

y = np.log(A)
x = 0.05 * indice_capteur

fig, ax = DAU.make_fig(r"x (m)", r"ln(A)")
result_fit = DAU.regression(ax=ax, x=x, y=y)

delta = 1 / result_fit["a"]
kappa = delta**2 * omega / 2

lambda_th = rho * kappa * c

print(lambda_th)

plt.show()

################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy

L0 = 60.8  # en cm

# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

lambda_2 = np.abs((L0 - df["L1"]) - (L0 - df["L2"])) * 1e-2  # en m
lambda_2_err = np.ones(len(lambda_2)) * 0.3e-2

ul = DAU.np2unp(lambda_2, lambda_2_err)

f = 600  # en Hz
f_err = 0.1
uf = DAU.np2unp(f, f_err)

uc2 = (2 * ul * uf) ** 2

c2, c2_err = DAU.unp2np(uc2)

T = df["T"] + 273.15
T_err = np.ones(len(T)) * 0.1


# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("T (en K)", "$c^2$ (en m/s)$^2$")

# Performing regression with uncertainties and plotting raw data
x = T
y = c2
xerr = T_err
yerr = c2_err
results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")

# Adding legend and displaying the plot
ax.legend()
plt.show()

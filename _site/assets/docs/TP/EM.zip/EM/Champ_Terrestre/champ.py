################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
import uncertainties.unumpy as unp
import uncertainties.umath as umath

DAU.init_umath()


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "calib.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("I", "B")

# Performing regression with uncertainties and plotting raw data
x = np.array(df["I"])
xerr = np.array(df["I_err"])
y = np.array(df["B"])
yerr = np.array(df["B_err"])
results_fit = DAU.regression(x=x, y=y, xerr=xerr, yerr=yerr, ax=ax, color="blue")


# Reading data
file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Creating a blank figure with x, y labels
fig2, ax2 = DAU.make_fig("B", "$tan(\\theta)$")

# Performing regression with uncertainties and plotting raw data
I = np.array(df["I"])
Ierr = np.array(df["I_err"])

x = results_fit["a"] * I + results_fit["b"]

theta = np.deg2rad(np.array(df["theta"]))
theta_err = np.deg2rad(np.array(df["theta_err"]))
u_theta = DAU.np2unp(theta, theta_err)

tan_utheta = umath.tan(u_theta)

y, yerr = DAU.unp2np(tan_utheta)

results_fit = DAU.regression(
    x=x, y=y, xerr=None, yerr=yerr, ax=ax2, color="black"
)  # , xmax=0.09)

u_a = DAU.np2unp(results_fit["a"], results_fit["u_a"]) * 1e-3

uB_H = 1 / u_a
print(uB_H)

ax.legend()
plt.show()

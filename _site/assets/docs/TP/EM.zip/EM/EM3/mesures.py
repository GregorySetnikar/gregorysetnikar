# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 14:47:42 2024

@author: ens
"""

import data_analysis as da
import numpy as np
import matplotlib.pyplot as plt


'''
# Tracé des données avec incertitudes
fig, ax = plt.subplots()
fig.set_size_inches((8, 7))
ax.set_xlabel("x", fontsize=18)
ax.set_ylabel("y", fontsize=18)
ax.tick_params(axis="both", labelsize=15)
ax.grid()


# Mesures nombre de spires
u1 = np.array([9.8,19.1,28.6,36.8,45.8,55.7,70.5,84.8,109.0,128.6,155.5,192.4,224.8])
u2 = np.array([4.8,9.5,14.3,18.4,22.9,27.9,35.3,42.5,54.7,64.5,78.1,96.7,112.3])

u1_err = 0.05*np.ones(len(u1))
u2_err = 0.05*np.ones(len(u2))


da.plot(
    ax,
    u1,
    u2,
    xerr=u1_err,
    yerr=u2_err,
    color="black",
    label="Données brutes",
)



results_fit = da.regression(
    x=u1, y=u2, xerr=u1_err, yerr=u2_err, ax=ax, color="blue", model="lineaire"
)



ax.legend()
plt.show()
'''

'''
# Tracé des données avec incertitudes
fig, ax = plt.subplots()
fig.set_size_inches((8, 7))
ax.set_xlabel("i1 (en A)", fontsize=18)
ax.set_ylabel("i2 (en A)", fontsize=18)
ax.tick_params(axis="both", labelsize=15)
ax.grid()

# Mesures nombre de spires
i1 = np.array([4.01,3.62,3.23,2.60,2.23,1.85,1.495,1.188,0.721,0.321]) #en A
i2 = np.array([7.75,7,6.34,5.02,4.3,3.59,2.87,2.28,1.82,0.61]) #en A

i1_err = 0.05*np.ones(len(i1))
i2_err = 0.05*np.ones(len(i2))


da.plot(
    ax,
    i1,
    i2,
    xerr=i1_err,
    yerr=i2_err,
    color="black",
    label="Données brutes",
)



results_fit = da.regression(
    x=i1, y=i2, xerr=i1_err, yerr=i2_err, ax=ax, color="blue", model="lineaire"
)



ax.legend()
plt.show()
'''



# Tracé des données avec incertitudes
fig, ax = plt.subplots(2,2)
fig.set_size_inches((8, 7))
ax[0,0].set_xlabel("I1**2 (en A**2)", fontsize=18)
ax[0,0].set_ylabel("P1 (en W)", fontsize=18)
ax[0,0].tick_params(axis="both", labelsize=15)
ax[0,0].grid()

ax[0,1].set_xlabel("I1 (en A)", fontsize=18)
ax[0,1].set_ylabel("U1 (en V)", fontsize=18)
ax[0,1].tick_params(axis="both", labelsize=15)
ax[0,1].grid()

# Mesures court-circuit
u1= np.array([8.6,19.0,28.0,40.9,51.5,62.8,73.2,84.9,99.6,112.9,125.7,144.4,159.1,172.4]) #en V
i1 = np.array([0.209,0.461,0.675,0.986,1.24,1.516,1.764,2.04,2.39,2.72,3.03,3.48,3.83,4.15]) #en A
p1 = np.array([0.3,1.5,3.1,6.4,9.9,14.7,19.6,25.7,35.6,45,55.1,74,89,103]) #en W

u1_err = 0.1*np.ones(len(u1))
i1_err = 0.01*np.ones(len(i1))
p1_err = 0.5 *np.ones(len(p1))

icarre = i1**2
icarre_err = 2*i1_err * i1

da.plot(
    ax[0,0],
    icarre,
    p1,
    xerr=icarre_err,
    yerr=p1_err,
    color="black",
    label="Données brutes",
)
da.plot(
    ax[0,1],
    i1,
    u1,
    xerr=i1_err,
    yerr=u1_err,
    color="black",
    label="Données brutes",
)


fit1 = da.regression(
    x=icarre, y=p1, xerr=icarre_err, yerr=p1_err, ax=ax[0,0], color="blue", model="lineaire"
)

fit2 = da.regression(
    x=i1, y=u1, xerr=i1_err, yerr=u1_err, ax=ax[0,1], color="blue", model="lineaire"
)

r = fit1["a"]
r_err = fit1["u_a"]

omega = 2*np.pi*50
Z1 = fit2["a"]

l = np.sqrt((Z1**2-r**2)/omega**2)

print(f"Z1 {Z1}")


ax[0,0].legend()
ax[0,1].legend()

#a2 = fit2["a"]
#da_l = 1/omega*a2*(a2**2-1/rf**2)**(-3/2)
#dx_l = 1/(omega*rf**2)*(a2**2-x**2)**(-3/2)

#L_err = np.sqrt((da_l*fit2["u_a"])**2+(dx_l*x_err)**2)

#print(f"rf = {rf} +/- {rf_err} ohm et L= {L} H")

#BOUCLE OUVERTE

ax[1,0].set_xlabel("U1**2 (en V**2)", fontsize=18)
ax[1,0].set_ylabel("P1 (en W)", fontsize=18)
ax[1,0].tick_params(axis="both", labelsize=15)
ax[1,0].grid()

ax[1,1].set_xlabel("I1 (en A)", fontsize=18)
ax[1,1].set_ylabel("U1 (en V)", fontsize=18)
ax[1,1].tick_params(axis="both", labelsize=15)
ax[1,1].grid()


# Mesures nombre de spires
u1= np.array([10,23.4,41.5,60.1,76.7,94.8,110.7,129.2,148,174.4,190.5,207.5,224.5,253.3]) #en V
i1 = np.array([0.015,0.025,0.035,0.045,0.053,0.062,0.071,0.083,0.096,0.120,0.14,0.169,0.209,0.34]) #en A
p1 = np.array([0,0.2,0.6,1.1,1.6,2.3,3,4,5,6.8,8.3,9.8,11.7,16.6]) #en W

u1_err = 0.1*np.ones(len(u1))
i1_err = 0.01*np.ones(len(i1))
p1_err = 0.5 *np.ones(len(p1))

ucarre = u1**2
ucarre_err = 2*u1_err * u1

da.plot(
    ax[1,0],
    ucarre,
    p1,
    xerr=ucarre_err,
    yerr=p1_err,
    color="black",
    label="Données brutes",
)
da.plot(
    ax[1,1],
    i1,
    u1,
    xerr=i1_err,
    yerr=u1_err,
    color="black",
    label="Données brutes",
)


fit1 = da.regression(
    x=ucarre, y=p1, xerr=ucarre_err, yerr=p1_err, ax=ax[1,0], color="blue", model="lineaire"
)

fit2 = da.regression(
    x=i1, y=u1, xerr=i1_err, yerr=u1_err, ax=ax[1,1], xmin=0,xmax=0.1, color="blue", model="lineaire"
)

Zf = fit2["a"]

rf = 1/fit1["a"]
rf_err = fit1["u_a"]/fit1["a"]**2

print(f"Zf {Zf}")

L = 1/omega * np.sqrt(1/((1/Zf**2)-(1/rf**2)))


"""
a2 = fit2["a"]
da_l = 1/omega*a2*(a2**2-1/rf**2)**(-3/2)
dx_l = 1/(omega*rf**2)*(a2**2-x**2)**(-3/2)

L_err = np.sqrt((da_l*fit2["u_a"])**2+(dx_l*x_err)**2)
"""


L_err=0
print(f"rf = {rf} +/- {rf_err} ohm et L= {L} +/- {L_err} H")



ax[1,0].legend()
ax[1,1].legend()
plt.show()



### 
#RENDEMENT

filename = 'data.csv'
data = da.loadfile(filename)

fig2, ax2 = plt.subplots()
fig2.set_size_inches((8, 7))
ax2.set_xlabel("x", fontsize=18)
ax2.set_ylabel("y", fontsize=18)
ax2.tick_params(axis="both", labelsize=15)
ax2.grid()

da.plot(
        ax2,
        data["P1(W)"],
        data["P2(W)"],
        color="black",
        label="Données brutes",
    )

fit5 = da.regression(
    x=data["P1(W)"], y=data["P2(W)"], ax=ax2, color="blue", model="lineaire"
)
ax2.legend()
fig2.show()

x = data["P2(W)"] + data["u1(V)"]**2/rf + r*data["i2(A)"]

fig3, ax3 = plt.subplots()
fig3.set_size_inches((8, 7))
ax3.set_xlabel("x", fontsize=18)
ax3.set_ylabel("y", fontsize=18)
ax3.tick_params(axis="both", labelsize=15)
ax3.grid()


da.plot(
        ax3,
        x,
        data["P1(W)"],
        color="black",
        label="Données brutes",
    )


fit55 = da.regression(
    x=x, y=data["P1(W)"], ax=ax3, color="blue", model="lineaire"
)

ax3.legend()
fig3.show()








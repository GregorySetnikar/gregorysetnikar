################################################
# Generated with make_template()
################################################

# Importing required packages
import python_DataAnalysisUtils_lyon as DAU
import numpy as np
import matplotlib.pyplot as plt
from uncertainties import unumpy


# Function definition for linear fit with Monte Carlo
def linear_func(x, a, b):
    return a * x + b


# Reading data
file_path = "calib.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)
# Uncomment the following line to filter the DataFrame when R = 33
# df = DAU.filter_df(df=df, column_name="R", value=33)

# Creating a blank figure with x, y labels
fig, ax = DAU.make_fig("H", "B")

list_current = ["A", "B", "C", "D"]
I_calib = np.array([1.000, 1.446, 1.851, 2.281])
I_calib_err = np.ones(len(I_calib)) * 0.005
a = []
u_a = []

for i in I_calib:
    df2 = DAU.filter_df(df, "I", i)
    B = np.array(df2["B"])
    Berr = np.array(df2["B_err"])
    H = np.array(df2["H"]) * 1e-2
    Herr = np.array(df2["H_err"]) * 1e-2

    results_fit = DAU.regression(x=H, y=B, xerr=Herr, yerr=Berr, ax=ax)
    a.append(results_fit["a"])
    u_a.append(results_fit["u_a"])


a = np.array(a)
u_a = np.array(u_a)
ax.legend()


fig2, ax2 = DAU.make_fig("I", "a")
fit_I = DAU.regression(
    x=I_calib, xerr=I_calib_err, y=a, yerr=u_a, ax=ax2, color="green"
)


file_path = "data.csv"  # Replace with the correct file path
df, units = DAU.loadfile(file_path)

df = DAU.filter_df(df, "Aimant", "B")

g = 9.81

F = df["m"] * g
Ferr = df["m_err"] * g

I = df["I"]
I_err = df["I_err"]

gradB = np.abs(fit_I["a"] * I + fit_I["b"])


fig3, ax3 = DAU.make_fig("gradB", "F")
fit_M = DAU.regression(x=gradB, xerr=None, y=F, yerr=Ferr, ax=ax3, color="black")

print(f"M {fit_M["a"]} pm {fit_M["u_a"]}")

# aimant 1
if False:
    R = 5e-3
    R_err = 0.02e-3
    h = 5e-3
    h_err = 0.02e-3

# aimant 2
if True:
    R = 7.5e-3
    R_err = 0.02e-3
    h = 5e-3
    h_err = 0.02e-3

V = np.pi * R**2 * h
V_err = np.sqrt(4 * (R_err / R) ** 2 + (h_err / h) ** 2)

m = fit_M["a"] / V
m_err = np.sqrt((fit_M["u_a"] / fit_M["a"]) ** 2 + (V_err / V) ** 2)


print(f"m {m} pm {m_err}")


plt.show()

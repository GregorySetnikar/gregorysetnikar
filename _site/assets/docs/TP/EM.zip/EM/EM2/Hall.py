# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 04:59:23 2024

@author: ens
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


def linear(x,a):
    return a * x


e = 0.02            #distance entrefer
u_H_0 = 0.2186      # tension hall sans champ B
i_H = 0.05          # courant dans le module à effet Hall


i = np.array([1.001,2.031,3.052,4.055,4.984,6.025,7.08,8.02]) # en A
u_H_1 = np.array([0.25028,0.2828,0.3149,0.3444,0.3647,0.3819,0.3950,0.4045]) #en V
u_H_2 = np.array([0.1813,0.1513,0.1226,0.0985,0.0823,0.0672,0.0570,0.0500]) #en V

u_H_1-=u_H_0
u_H_2-=u_H_0

u_H = (u_H_1-u_H_2)/2

ui_H = 0.001        # incertitude sur i_H 
uuH = 0.001         # incertitude sur uH
uB = 0.01           # incertitude sur B

a = -0.000437
b = 0.00287
c = 0.0587
d = 0.0109
B = a*i**3+b*i**2+c*i+d         # B en T

ux = i_H*B*np.sqrt((ui_H/i_H)**2+(uB/B)**2)
uuH = uuH*np.ones(8)

p, pcov = curve_fit(linear, i_H*B[0:3], u_H[0:3], sigma=uuH[0:3])
up = np.sqrt(np.diag(pcov))

plt.figure()
plt.errorbar(i_H*B, u_H, yerr=uuH, xerr=ux)
plt.plot(i_H*B, linear(i_H*B, p), 'k')
plt.grid()
plt.show()
plt.xlabel('i_H*B')
plt.ylabel('u_H (V)')

l_z = 1e-3
R_H = l_z*p
q = 1.6e-19

n = 1/(R_H*q)
un = up[0]/(l_z*q*p[0]**2)






